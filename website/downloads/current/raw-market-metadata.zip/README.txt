Current cohort: 565 contracts, one per real-world event family; 200 Sports, 200 Politics and 165 Economics.
markets/<market_id>.json contains the unchanged saved Gamma response for each selected market.
