# Shared data for EDA and all model notebooks

565 markets / event families: 200 Sports, 200 Politics, 165 Economics.
155,177 account trade records and 75,061 hourly price observations.
All five analyses read the same data/eda/20260916_v2/markets.parquet table.
Each notebook selects its predictors and performs its own model preparation.

Extract the whole ZIP into a new folder, preserving its directory structure.
With Python 3.11, install the environment:

    python -m pip install -r requirements.txt

Open notebooks/02_eda.ipynb in a Jupyter-compatible editor and run its cells.
This simplified notebook displays tables and plots inline without exporting files.
The same folder contains 03_clustering.ipynb, 04_pca.ipynb, 05_naive_bayes.ipynb,
and 06_decision_trees.ipynb. No API calls or extra data downloads are required.

To rebuild the shared tables from the included frozen inputs:

    python -B src/prepare_analysis_data.py

The builder includes the required input-reading and feature-calculation helpers.
It checks the saved source hashes and approved roster before preparing data.
The audit's source_snapshots/audit_eda_tables.py is a frozen historical source
file, used only to verify its original recorded hash; it is not imported.
No local src/archive/ directory or separate table-loader module is required.
Existing data manifests retain their original generation provenance. FILES.json
records the hashes of the current distributed source, notebooks, and inputs.
Rebuilding writes a new preparation manifest; the eight prepared table/schema/
dictionary outputs were verified byte-identical before this release.

Collection source: src/collect_market_sample.py provides inventory and collect
commands; inspect --help first. It uses prepare_sampling_plan.py and
validate_market_sample.py. The saved roster and corrected captures reflect
completed human review. Collection does not itself establish eligibility or
historical event-menu completeness. Replaying all historical review/replacement
decisions requires earlier working states, which are not included here.
prepare_sampling_plan.py retains a guard against overwriting the approved roster.

The bundle includes current typed tables and CSV exports, their schema/dictionary,
frozen source captures and decisions, and the original discovery inventory/draw
needed for the sample-flow chart. Dates in source paths preserve provenance.
Research drafts, local workflow logs, tests, and retired helper modules are omitted.
