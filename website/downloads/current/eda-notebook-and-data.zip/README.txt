# Shared data for EDA and all model notebooks

565 markets / event families: 200 Sports, 200 Politics, 165 Economics.
155,177 account trade records and 75,061 hourly price observations.

All five analyses use the same current market table, including the derived
wallet-activity, certainty, movement, favorite, large-purchase and trend fields.
The 565 market observations are shared; notebooks select their own columns and
perform method-specific preparation. CSV files export the same prepared tables.

## Run the notebooks

Extract the whole ZIP into a new folder. Keep the directory structure.
Use Python 3.11 and open a terminal in that folder:

    python -m pip install -r requirements.txt
    python -B src/create_eda_notebook.py

This executes all notebook cells, saves the executed notebook to
notebooks/02_cohort_eda.ipynb, and writes plots and plotted-data CSVs under
figures/. Alternatively, open that notebook in a Jupyter-compatible editor
using the same Python environment and run all cells. Plotting code is in the
notebook; there are no required downloads or API calls during execution.

The same extraction includes notebooks/03_clustering.ipynb through
notebooks/06_decision_trees.ipynb. Open them in a Jupyter-compatible editor using
that environment. All use data/eda/20260916_v2/markets.parquet. A separate model
data archive is not required.

To rebuild the shared tables from the included saved inputs:

    python -B src/build_eda_tables.py

This is the single feature-building implementation for EDA and the later models.

To independently validate the supplied tables against their saved inputs:

    python -B src/validate_eda_tables.py

The validator writes validation.json inside this extracted copy. It checks
source hashes, identifiers, joins, time windows, calculations and every saved
trade/price row. A successful run does not certify all external event facts or
reconcile account activity to exchange turnover.

## Included inputs

- Current typed Parquet tables and CSV exports, schema, dictionary and manifests.
- All frozen table-manifest inputs, including the effective raw captures.
- The accepted boundary/family decisions and current option-count evidence.
- The original discovery inventory/draw used to calculate Figure 1's pool and
  replacement counts. These are necessary sampling inputs, not older EDA cohorts.
- Current collection, sampling, boundary review, final-selection validation,
  cleaning, option-count and trade-check implementation plus imported helpers.

FILES.json records each bundled file's hash. The notebook and validation commands
above are the supported offline entrypoints. Collection/selection/activation
scripts document the implemented workflow; replaying the entire historical
selection process requires its earlier review states, which are not included.
Human-reviewed decisions are supplied as inputs, not silently regenerated.
The three-example trade diagnostic references an earlier diagnostic ledger;
the current full-sample trade audit is audit_trade_sides.py.

Only the current prepared-table version is included. Historical research
checkpoints, superseded figures and failed collection attempts are omitted.
Dates in active capture paths preserve provenance. All observations and
existing research source files are copied unchanged.
