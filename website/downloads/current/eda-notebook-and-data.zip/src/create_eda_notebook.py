"""Execute the existing EDA notebook, which owns analysis and figure code.

The former generator kept a second copy of plotting code; it is archived in
 docs/writing/site_edits/20260917_notebook_figures. Edit notebook cells directly.
This entrypoint preserves those edits and refreshes their outputs.
"""
from pathlib import Path
import nbformat
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / 'notebooks/02_cohort_eda.ipynb'


def main():
    notebook = nbformat.read(PATH, as_version=4)
    # Never retain old outputs when an execution stops before the last cell.
    for cell in notebook.cells:
        if cell.cell_type == 'code':
            cell.outputs = []
            cell.execution_count = None
    client = NotebookClient(notebook, timeout=180, kernel_name='python3',
                            resources={'metadata': {'path': str(ROOT)}})
    client.execute()
    # Publish a new executed notebook only after the entire run succeeds.
    nbformat.write(notebook, PATH)
    print(f'Executed {len(notebook.cells)} notebook cells: {PATH.name}')


if __name__ == '__main__':
    main()
