# Model inputs for the current website

This compact download contains the saved 565-market table used by clustering,
PCA, Naive Bayes, and Decision Trees, including the favorite-probability,
large-purchase, and price-trend features added in October.

1. Download or clone the GitHub repository.
2. Extract this ZIP into its root, preserving data/eda/20260916_v2/.
3. Use Python 3.11: python -m pip install -r requirements.txt
4. Open notebooks/03_clustering.ipynb through notebooks/06_decision_trees.ipynb.

Naive Bayes and Decision Trees each select 547 eligible labeled markets from
these 565 rows, then use the existing 437/110 training/testing split. Actual
outcomes remain available for evaluation; they are not input predictors.

The feature builder is src/build_eda_tables.py. Rebuilding the full typed tables
also requires the saved capture/audit inputs in the larger EDA notebook/data
archive. This compact download suffices to run the four model notebooks.
The older EDA archive predates the additional model features; extract this ZIP
after it when using both. FILES.json records the included hashes. No API requests
are needed to run the model notebooks on this saved table.
