Current prepared trades table: 155,177 rows. The CSV is unchanged from the current EDA output. data_dictionary.md defines its fields.
