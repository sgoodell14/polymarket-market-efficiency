# EDA field dictionary

Generated from the explicit builder schema. Parquet preserves types; CSV imports must use this schema.

Nulls are empty CSV cells, never a numeric zero. Times are UTC; probabilities use 0-1 units, activity uses observed price*shares.

`information_class` separates observed pre-cutoff values, derived summaries, sampling/audit annotations, later metadata, provenance and settled outcomes.

## markets

| Field | Type | Null allowed | Meaning | Source / information class |
|---|---|---|---|---|
| `market_id` | text | False | Unique contract ID, preserved as text. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `condition_id` | text | False | Contract condition ID. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `topic` | text | False | Audited topic: Sports, Politics or Economics. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `question` | text | False | Contract question. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `slug` | text | False | Saved contract URL slug. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `event_id` | text | False | Parent API event ID; different from the real-world family. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `event_family_id` | text | False | Audited grouping of contracts about the same real-world event. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `outcome_0_token_id` | text | False | Token whose probability and result define this forecast. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `outcome_1_token_id` | text | False | Other token in the same binary contract. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `outcome_0_name` | text | False | Canonical display name for token index 0; not always Yes. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `outcome_1_name` | text | False | Canonical display name for token index 1. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `event_month` | text | False | Calendar month of the reviewed event boundary, YYYY-MM. | active_candidates + reviewed register + effective market metadata / audited_metadata |
| `event_time_utc` | utc_datetime | False | Reviewed event boundary, preserving supplied subsecond precision. | register + active_candidates / audited_metadata |
| `reviewed_cutoff_utc` | utc_datetime | False | Reviewed boundary minus 24 hours before integer-second conversion. | register + active_candidates / audited_metadata |
| `original_event_time_utc` | utc_datetime | False | Original discovery anchor, retained for provenance. | register + active_candidates / audited_metadata |
| `listing_time_utc` | utc_datetime | False | Saved market listing time. | register + active_candidates / audited_metadata |
| `closed_time_utc` | utc_datetime | False | Saved closing time, known after the forecast. | register + active_candidates / known_after_event |
| `forecast_cutoff_utc` | utc_datetime | False | Effective integer-second collection cutoff: floor(event time)-86400. | effective result.json / pre_cutoff_observation |
| `window_start_utc` | utc_datetime | False | Later of listing time rounded up to seconds and cutoff minus seven days. | effective result.json / pre_cutoff_observation |
| `forecast_observation_utc` | utc_datetime | False | Timestamp of the selected observed cutoff probability. | effective result.json / pre_cutoff_observation |
| `window_hours` | number | False | Actual collection exposure in hours; not assumed to be seven days. | effective result + reviewed boundary / pre_cutoff_observation |
| `forecast_probability` | number | False | Observed probability of outcome 0 at/before cutoff. | effective result + reviewed boundary / pre_cutoff_observation |
| `cutoff_floor_difference_seconds` | number | False | Reviewed cutoff minus integer-second cutoff, in [0,1). | effective result + reviewed boundary / pre_cutoff_observation |
| `forecast_age_seconds` | integer | False | Effective cutoff minus selected price-observation timestamp. | effective result + audit register / audit_annotation |
| `family_market_count` | integer | False | Number of retained contracts sharing this real-world family. | effective result + audit register / audit_annotation |
| `outcome_0_result` | integer | False | Audited settled outcome: 0 or 1. An outcome, never a pre-cutoff predictor. | audit register + settled metadata / known_after_event |
| `forecast_price_source` | text | False | hourly or one_minute_fallback; finer snapshots are not mixed into the hourly path. | audit register + effective result / audit_annotation |
| `evidence_status` | text | False | Current accepted evidence status; supersedes provisional capture flags. | audit register + effective result / audit_annotation |
| `boundary_type` | text | False | Meaning of the accepted event-time boundary. | audit register + effective result / audit_annotation |
| `time_precision` | text | False | Precision stated by the event-time audit. | audit register + effective result / audit_annotation |
| `event_source_urls` | text | False | External evidence links recorded by the audit, separated as in source. | audit register + effective result / audit_annotation |
| `timing_sensitivity_status` | text | False | reviewed_scenarios or not_evaluated_in_review. | audit register + effective result / audit_annotation |
| `timing_sensitivity_range_pp` | number | True | Observed range over retained timing scenarios, in percentage points; not a confidence interval. | audit register / audit_annotation |
| `short_window` | boolean | False | Collection window is shorter than 168 hours. | active_candidates + reviewed register + result / audit_annotation |
| `original_anchor_differs` | boolean | False | Original discovery anchor differs from accepted event time. | active_candidates + reviewed register + result / audit_annotation |
| `sampling_month_differs` | boolean | False | Audited event month differs from the original sampling stratum. | active_candidates + reviewed register + result / audit_annotation |
| `is_replacement` | boolean | False | Market was selected from the saved replacement reserve. | active_candidates + reviewed register + result / audit_annotation |
| `collection_pilot` | boolean | False | Market belongs to the nested collection pilot. | active_candidates + reviewed register + result / audit_annotation |
| `sampling_month` | text | False | Original month stratum; not overwritten after event-time corrections. | active_candidates / sampling_provenance |
| `sampling_probability_status` | text | False | recorded_original_design or unavailable_replacement_probability. | active_candidates / sampling_provenance |
| `replaces_market_id` | text | True | Prior market occupying this sampling slot; null for original selections. | active_candidates / sampling_provenance |
| `event_inclusion_probability` | number | True | Saved original-design probability; not a final inverse-probability weight. | active_candidates / sampling_provenance |
| `reported_lifetime_volume` | number | True | Reported lifetime metadata volume; unavailable for some markets and not a historical window feature. | active_candidates / metadata_at_collection |
| `reported_volume_status` | text | False | available_lifetime_metadata or missing_lifetime_metadata. | active_candidates / metadata_at_collection |
| `event_structure` | text | False | Audited structure of the parent choice group. | active_market_options / audit_annotation |
| `option_count_status` | text | False | Historical reconstruction, historical_count_unverified, or not_applicable_nonexclusive_bundle. | active_market_options / audit_annotation |
| `option_count_at_cutoff` | integer | True | Reconstructed count if justified; null for unknown/nonexclusive groups. | active_market_options / audit_annotation |
| `listed_alternative_count_snapshot` | integer | True | Descriptive count in the later event response; not backdated to the forecast. | active_market_options / metadata_at_collection |
| `alternatives_mutually_exclusive` | boolean | False | Whether the choice-group alternatives are mutually exclusive. | active_market_options / audit_annotation |
| `contemporaneous_menu_verified` | boolean | False | Whether a contemporaneous historical menu was directly verified; false throughout this version. | active_market_options / audit_annotation |
| `trade_row_count` | integer | False | All returned rows, retaining ambiguous repeats. | effective trade and price windows / derived_pre_cutoff |
| `transaction_count` | integer | False | Distinct transaction hashes represented in this market's window. | effective trade and price windows / derived_pre_cutoff |
| `observed_wallet_count` | integer | False | Distinct observed wallet addresses; not necessarily distinct people. | effective trade and price windows / derived_pre_cutoff |
| `exact_duplicate_excess` | integer | False | Repeated exact rows beyond one per signature. | effective trade and price windows / derived_pre_cutoff |
| `exact_duplicate_group_count` | integer | False | Number of exact signatures occurring more than once. | effective trade and price windows / derived_pre_cutoff |
| `sensitivity_trade_row_count` | integer | False | One row per exact signature, for sensitivity analysis only. | effective trade and price windows / derived_pre_cutoff |
| `price_point_count` | integer | False | Observed hourly first-token prices; excludes finer cutoff recovery. | effective trade and price windows / derived_pre_cutoff |
| `price_interval_count` | integer | False | Number of adjacent observed hourly pairs. | effective trade and price windows / derived_pre_cutoff |
| `price_gaps_over_90_minutes` | integer | False | Count of adjacent observed intervals exceeding 5400 seconds. | effective trade and price windows / derived_pre_cutoff |
| `price_gaps_over_6_hours` | integer | False | Count of adjacent observed intervals exceeding 21600 seconds. | effective trade and price windows / derived_pre_cutoff |
| `gross_account_activity` | number | False | Sum(price*size) over all returned account rows; not reconciled exchange turnover. | effective trade window / derived_pre_cutoff |
| `sensitivity_account_activity` | number | False | Same sum after keeping the first row per exact signature. | effective trade window / derived_pre_cutoff |
| `account_activity_per_observed_day` | number | False | Gross account activity divided by actual window hours/24; not an extrapolated weekly total. | effective trade window / derived_pre_cutoff |
| `mean_trade_row_size` | number | True | Mean shares per returned account row; null when no rows were returned. | effective trade window / derived_pre_cutoff |
| `mean_trade_row_notional` | number | True | Mean price*size per returned account row. | effective trade window / derived_pre_cutoff |
| `top_wallet_activity_share` | number | True | Largest wallet sum(price*size) / gross account activity, in [0,1]. | effective trade window / derived_pre_cutoff |
| `top_five_wallet_activity_share` | number | True | Combined five largest wallet activity shares; all wallets if fewer than five. | effective trade window / derived_pre_cutoff |
| `wallet_activity_hhi` | number | True | Sum of squared wallet activity shares, in (0,1]; null with no denominator. | effective trade window / derived_pre_cutoff |
| `sensitivity_top_wallet_share` | number | True | Top-wallet share in the exact-signature sensitivity view. | effective trade window / derived_pre_cutoff |
| `sensitivity_wallet_hhi` | number | True | Wallet HHI in the exact-signature sensitivity view. | effective trade window / derived_pre_cutoff |
| `duplicate_activity_difference_pct` | number | True | 100*(all-row activity - sensitivity activity)/all-row activity; null for zero activity. | effective trade window / derived_pre_cutoff |
| `zero_returned_trades` | boolean | False | No API trade rows in the bounded pre-cutoff window; does not mean no lifetime trading. | effective trade window / derived_pre_cutoff |
| `trade_collection_status` | text | False | Saved API window completion status. | effective windows + result / audit_annotation |
| `trade_summary_status` | text | False | observed_rows or no_returned_trades; explains missing row means/concentration. | effective windows + result / audit_annotation |
| `price_path_status` | text | False | observed_hourly_path, single_hourly_observation, or no_hourly_observations; cutoff snapshot availability is separate. | effective windows + result / audit_annotation |
| `max_price_gap_hours` | number | True | Longest adjacent observed interval; null when fewer than two points exist. | effective hourly price window / derived_pre_cutoff |
| `median_price_gap_seconds` | number | True | Median elapsed seconds between observed points. | effective hourly price window / derived_pre_cutoff |
| `leading_price_gap_hours` | number | True | Time from window start to first hourly observation; null for an empty series. | effective hourly price window / derived_pre_cutoff |
| `trailing_price_gap_hours` | number | True | Time from last hourly observation to cutoff, separately from selected snapshot age. | effective hourly price window / derived_pre_cutoff |
| `max_observed_price_step_pp` | number | True | Largest absolute adjacent probability difference in percentage points; may span a gap. | effective hourly price window / derived_pre_cutoff |
| `flat_hourly_series` | boolean | True | All observed probabilities equal, with at least two points; null if no path. | effective hourly price window / derived_pre_cutoff |
| `observed_steps_ge_20pp` | integer | True | Number of adjacent observed price changes at least 20 percentage points; null if no path. | effective hourly price window / derived_pre_cutoff |
| `source_capture_id` | text | False | Market ID plus SHA-256 of its effective result.json; identifies the frozen capture. | effective capture / provenance |
| `source_capture_path` | text | False | Project-relative path to effective result.json. | active coverage + register / provenance |
| `source_metadata_file` | text | False | Project-relative saved market metadata path. | active coverage + register / provenance |
| `source_trade_file` | text | False | Project-relative effective trade-array path. | active coverage + register / provenance |
| `source_price_file` | text | False | Project-relative effective hourly price-array path. | active coverage + register / provenance |
| `source_register_file` | text | False | Project-relative current audit register; join by market_id. | active coverage + register / provenance |
| `captured_at_utc` | utc_datetime | False | Collection timestamp; later than forecast, not a predictor. | effective result / provenance |

## trades

| Field | Type | Null allowed | Meaning | Source / information class |
|---|---|---|---|---|
| `source_capture_id` | text | False | Market ID plus SHA-256 of its effective result.json; identifies the frozen capture. | effective capture / provenance |
| `trade_row_id` | text | False | Stable source-row identity; not a unique fill ID. | effective trades + token metadata / pre_cutoff_observation |
| `market_id` | text | False | Parent contract ID. | effective trades + token metadata / pre_cutoff_observation |
| `condition_id` | text | False | Condition ID used for the market join. | effective trades + token metadata / pre_cutoff_observation |
| `token_id` | text | False | Traded token ID, kept as text. | effective trades + token metadata / pre_cutoff_observation |
| `wallet_address` | text | False | Lowercase wallet address; profile names are not identifiers. | effective trades + token metadata / pre_cutoff_observation |
| `transaction_hash` | text | False | Lowercase transaction hash; may contain many distinct returned records. | effective trades + token metadata / pre_cutoff_observation |
| `side` | text | False | Returned BUY or SELL, without an inferred maker/taker role. | effective trades + token metadata / pre_cutoff_observation |
| `outcome_label_raw` | text | False | Original returned label, preserved including punctuation differences. | effective trades + token metadata / pre_cutoff_observation |
| `outcome_label` | text | False | Canonical token-index label from saved market metadata. | effective trades + token metadata / pre_cutoff_observation |
| `exact_signature_id` | text | False | SHA-256 of market ID and complete original row; candidate grouping, not fill identity. | effective trades + token metadata / pre_cutoff_observation |
| `trade_time_utc` | utc_datetime | False | UTC time of the returned trade record, with second precision. | trade timestamp / pre_cutoff_observation |
| `timestamp_epoch_seconds` | integer | False | Original integer Unix timestamp. | effective trades / derived_pre_cutoff |
| `outcome_index` | integer | False | 0 or 1; validated against the asset/token ID. | effective trades / derived_pre_cutoff |
| `first_outcome_direction` | integer | False | +1 for BUY 0 or SELL 1; -1 for SELL 0 or BUY 1. Semantic direction, not inferred net demand. | effective trades / derived_pre_cutoff |
| `duplicate_group_size` | integer | False | Number of identical full rows in this market capture. | effective trades / derived_pre_cutoff |
| `duplicate_occurrence` | integer | False | One-based occurrence in original source order; defines the sensitivity view. | effective trades / derived_pre_cutoff |
| `price` | number | False | Token-native trade price, in [0,1]. | effective trades / pre_cutoff_observation |
| `size` | number | False | Returned number of outcome shares. | effective trades / pre_cutoff_observation |
| `row_notional` | number | False | Unrounded price times size in dollar-equivalent consideration. | effective trades / pre_cutoff_observation |
| `outcome_label_changed` | boolean | False | Canonical label differs from preserved original text. | effective trades + token metadata / audit_annotation |
| `duplicate_candidate` | boolean | False | The exact signature has more than one source occurrence. | effective trades + token metadata / audit_annotation |
| `duplicate_excess` | boolean | False | Occurrence beyond the first exact-signature row. | effective trades + token metadata / audit_annotation |
| `in_exact_signature_sensitivity` | boolean | False | Keep this row in the separately named sensitivity view. | effective trades + token metadata / audit_annotation |
| `source_file` | text | False | Project-relative effective source-array path. | effective capture / provenance |
| `source_file_sha256` | text | False | SHA-256 of the compressed source file; also recorded in manifest.json. | effective capture / provenance |
| `source_row_index` | integer | False | Zero-based index in the original effective source array, before sorting. | effective capture / provenance |

## price_history

| Field | Type | Null allowed | Meaning | Source / information class |
|---|---|---|---|---|
| `source_capture_id` | text | False | Market ID plus SHA-256 of its effective result.json; identifies the frozen capture. | effective capture / provenance |
| `price_row_id` | text | False | Stable identity of the observed source price row. | effective hourly price window / pre_cutoff_observation |
| `market_id` | text | False | Parent contract ID. | effective hourly price window / pre_cutoff_observation |
| `token_id` | text | False | First outcome token; no synthetic complement series. | effective hourly price window / pre_cutoff_observation |
| `interval_status` | text | False | first_observation, adjacent_within_90_minutes, or gap_over_90_minutes. | effective hourly price window / pre_cutoff_observation |
| `observation_time_utc` | utc_datetime | False | UTC time of the actual returned hourly observation. | price t field / pre_cutoff_observation |
| `timestamp_epoch_seconds` | integer | False | Original integer Unix observation timestamp. | price t field / pre_cutoff_observation |
| `probability` | number | False | Observed first-outcome probability, in [0,1]. | hourly history + effective cutoff / pre_cutoff_observation |
| `hours_before_cutoff` | number | False | Elapsed hours from this observation to effective forecast cutoff. | hourly history + effective cutoff / pre_cutoff_observation |
| `elapsed_seconds_since_previous` | integer | True | Actual gap to preceding observed point; null for first point. | adjacent observed timestamps / derived_pre_cutoff |
| `observed_change_pp` | number | True | 100*(current probability - previous observed probability); null for first point. | adjacent observed prices / derived_pre_cutoff |
| `gap_over_90_minutes` | boolean | True | Actual observed interval exceeds 5400 seconds; null for first point. | adjacent observed timestamps / derived_pre_cutoff |
| `gap_over_6_hours` | boolean | True | Actual observed interval exceeds 21600 seconds; null for first point. | adjacent observed timestamps / derived_pre_cutoff |
| `source_file` | text | False | Project-relative effective source-array path. | effective capture / provenance |
| `source_file_sha256` | text | False | SHA-256 of the compressed source file; also recorded in manifest.json. | effective capture / provenance |
| `source_row_index` | integer | False | Zero-based index in the original effective source array, before sorting. | effective capture / provenance |
