"""Reconcile all 600 documented reviews with effective captures, offline.

This does not select replacements, erase captures, or certify a modeling table.
The working roster retains excluded/held rows so every original slot is tracked.
"""
import csv
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone

from audit_cohort import stamp
from cohort_state import validate_membership
from full_audit_evidence import RUN, inputs, load
from prepare_sampling_plan import OUTPUT, ROOT, write_csv
from validate_replacement_windows import SUPPORTED_STATUSES, timing_review, validate_spec


EARLIER_SIX = {'706054', '2685007', '1005413', '1301502', '2126401', '991023'}


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def array(value):
    return json.loads(value) if isinstance(value, str) else value


def write_changed_csv(path, rows):
    """Leave an unchanged evidence queue open in another reviewer untouched."""
    normalized = [{k: '' if v is None else str(v) for k, v in row.items()} for row in rows]
    if path.exists() and read(path) == normalized:
        return
    write_csv(path, rows)


def assess(row, spec, capture, metadata):
    """Keep external evidence, API integrity, and collection gates separate."""
    reasons = []
    if spec['rules_sha256'] != hashlib.sha256(row['rules'].encode()).hexdigest():
        raise ValueError('Reviewed rules changed: ' + row['market_id'])
    if spec['status'] == 'exclude':
        return 'excluded', [spec['reason']]
    if spec['status'] not in SUPPORTED_STATUSES:
        return 'evidence_hold', [spec.get('reason', spec['status'])]
    reasons.extend(validate_spec(row, spec))
    supported, timing_status = timing_review(spec)
    if not supported:
        reasons.append(timing_status)
    if not spec.get('event_family_id'):
        reasons.append('event_family_missing')
    if reasons:
        return 'evidence_hold', reasons
    if not capture:
        return 'collection_hold', ['no_capture']
    expected_cutoff = int(stamp(spec['anchor']).timestamp()) - 86400
    if capture.get('cutoff_timestamp') != expected_cutoff:
        reasons.append('capture_uses_different_cutoff')
    if capture.get('metadata_status') != 'retrieved':
        reasons.append('metadata_not_retrieved')
    if capture.get('price_status') != 'available':
        reasons.append('cutoff_price_unavailable')
    age = capture.get('forecast_price_age_seconds')
    if not isinstance(age, (int, float)) or not 0 <= age <= 21600:
        reasons.append('cutoff_price_freshness_failed')
    if capture.get('trade_status') != 'api_window_exhausted':
        reasons.append('trade_window_not_exhausted')
    tokens, prices = array(metadata.get('clobTokenIds', [])), array(metadata.get('outcomePrices', []))
    if (str(metadata.get('id')) != row['market_id'] or metadata.get('conditionId') != row['condition_id']
            or not tokens or tokens[0] != row['first_token_id']):
        reasons.append('market_condition_token_mapping_failed')
    if not prices or float(prices[0]) not in (0, 1) or str(int(float(prices[0]))) != row['final_outcome']:
        reasons.append('saved_label_does_not_match_first_token_resolution')
    return ('collection_hold' if reasons else 'checks_passed'), reasons


def main():
    active, reviewed_inputs, decisions = read(OUTPUT / 'active_candidates.csv'), inputs(), load()
    mids = {r['market_id'] for r in active}
    membership = validate_membership(active)
    family_unique = bool(membership and membership.get('one_contract_per_event_family'))
    family_replacements = set((membership or {}).get('replacement_ids', []))
    assert mids == set(reviewed_inputs) == set(decisions)
    index = json.loads((OUTPUT / 'corrections/active_corrections.json').read_text())
    latest_ten = {r['market_id'] for r in read(OUTPUT / 'replacements_10_20260915/selected_replacements.csv')}
    twelve_batch = OUTPUT / 'replacements_12_20260915'
    latest_twelve = ({r['market_id'] for r in read(twelve_batch / 'selected_replacements.csv')}
                     if (twelve_batch / 'applied.json').exists() else set())
    previous_58 = set(json.loads((OUTPUT / 'validation_20260915/market_decisions.json').read_text(encoding='utf-8')))
    followup = OUTPUT / 'followup_20260915'
    queue = {r['market_id']: r for r in read(followup / 'validation_queue_updated.csv')}
    eligibility = {r['market_id']: r for r in read(followup / 'current_eligibility_register.csv')}
    groups = defaultdict(list)
    for mid in mids:
        assert decisions[mid].get('event_family_id'), mid
        groups[decisions[mid]['event_family_id']].append(mid)
    coverage, register = [], []
    for row in active:
        mid = row['market_id']
        spec = decisions[mid]
        base = OUTPUT / 'corrections' / index[mid] if mid in index else OUTPUT
        path = base / 'pilot_collection' / mid / 'result.json'
        capture = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
        mp = path.with_name('market.json.gz')
        metadata = json.loads(gzip.decompress(mp.read_bytes())) if mp.exists() else {}
        status, reasons = assess(reviewed_inputs[mid], spec, capture, metadata)
        time_ok = spec['status'] in SUPPORTED_STATUSES and timing_review(spec)[0]
        family = spec['event_family_id']
        origin = ('family_unique_replacement' if mid in family_replacements else
                  'full_audit_twelve_replacements' if mid in latest_twelve else
                  'latest_ten_replacements' if mid in latest_ten else
                  'previous_58_replacements' if mid in previous_58 else 'existing_cohort')
        reviewed_cutoff = (stamp(spec['anchor']) - timedelta(hours=24)).isoformat() if spec.get('anchor') else ''
        effective_anchor = capture.get('anchor', '')
        record = dict(market_id=mid, topic=row['topic'], question=row['question'], origin=origin,
            earlier_six_followup=mid in EARLIER_SIX, replaces_market_id=row.get('replaces_market_id', ''),
            audit_status=status, evidence_status=spec['status'], pending_reason='; '.join(reasons),
            scope_status=spec.get('scope_status', ''), participation_status=spec.get('participation_status', ''),
            event_time_supported=time_ok, boundary_type=spec.get('boundary_type', ''),
            local_time=spec.get('local_time', ''), time_zone=spec.get('time_zone', ''),
            time_precision=spec.get('time_precision', ''), reviewed_anchor_utc=spec.get('anchor', ''),
            reviewed_cutoff_utc=reviewed_cutoff, original_anchor_utc=reviewed_inputs[mid]['anchor'],
            effective_capture_anchor_utc=effective_anchor, capture_path=str(path.relative_to(OUTPUT)) if capture else '',
            capture_matches_reviewed_cutoff=bool(capture and spec.get('anchor') and capture.get('cutoff_timestamp') == int(stamp(spec['anchor']).timestamp())-86400),
            event_family_id=family, family_market_count=len(groups[family]),
            related_contracts_present=len(groups[family]) > 1,
            saved_first_token_outcome=row['final_outcome'], expected_outcome=spec.get('expected_final_outcome', ''),
            outcome_check_status=spec.get('outcome_check_status', ''),
            forecast_probability=capture.get('forecast_probability', ''),
            forecast_price_age_seconds=capture.get('forecast_price_age_seconds', ''),
            price_status=capture.get('price_status', 'not_collected_pending_event_time'),
            trade_status=capture.get('trade_status', 'not_collected_pending_event_time'),
            trade_rows=capture.get('trade_rows', ''), observed_wallets=capture.get('observed_wallets', ''),
            shorter_than_seven_days=capture.get('shorter_than_seven_days', ''),
            exact_duplicate_trade_candidates=capture.get('exact_duplicate_candidates', ''),
            target_wording_flag=spec.get('retain_target_wording_flag', False),
            evidence_carried_forward_from=spec.get('evidence_carried_forward_from', ''),
            rules_sha256=spec['rules_sha256'], evidence=spec['evidence'],
            source_urls=';'.join(spec['source_urls']), forecast_ready=status == 'checks_passed',
            timing_uncertainty=spec.get('timing_uncertainty', ''),
            timing_sensitivity_range_pp=(spec.get('timing_sensitivity') or {}).get('range_pp', ''),
            timing_sensitivity_review=bool(spec.get('timing_sensitivity')),
            evidence_review_record=spec.get('review_record', ''),
            analytical_inclusion=status == 'checks_passed', modeling_ready=False)
        register.append(record)
        current_capture = dict(capture) if capture else dict(market_id=mid, topic=row['topic'], question=row['question'],
            metadata_status='saved_inventory_rules_only', price_status='not_collected_pending_event_time',
            trade_status='not_collected_pending_event_time')
        current_capture.update(capture_path=record['capture_path'], analytical_audit_status=status,
            event_time_verified=time_ok and spec['status'] == 'verified_boundary',
            event_time_supported=time_ok, event_time_precision=spec.get('time_precision', ''),
            event_family_id=family, modeling_ready=False,
            verified_capture_window=status == 'checks_passed', analytical_pending_reason=record['pending_reason'])
        coverage.append(current_capture)
        row.update(validation_status=status, event_family_id=family)
        q = queue.setdefault(mid, dict(market_id=mid, topic=row['topic'], question=row['question']))
        q.update(review_status=status, review_notes=spec['evidence'], event_family_id=family,
            verified_event_time_utc=spec.get('anchor', '') if time_ok else '',
            event_time_source_url=record['source_urls'], pending_reason=record['pending_reason'])
        e = eligibility.setdefault(mid, dict(market_id=mid, topic=row['topic'], question=row['question']))
        e.update(scope_status=record['scope_status'], current_anchor=spec.get('anchor', ''),
            proposed_event_family_id=family, full_audit_status=status,
            prior_verified_event_time_utc=q['verified_event_time_utc'], prior_event_time_source_url=q['event_time_source_url'],
            additional_review_note=spec['evidence'], next_validation=record['pending_reason'] or 'Analysis design and feature-table construction.',
            membership_action='exclude_pending_reserve_batch' if status == 'excluded' else 'retain_tracking_row')
    # Preserve pre-refresh tracking views once. Raw capture files are never edited.
    before = RUN / 'before_refresh'
    before.mkdir(exist_ok=True)
    for name in ('active_candidates.csv', 'active_cohort_coverage.csv', 'validation_queue.csv', 'approved_review_summary.json'):
        if (OUTPUT / name).exists() and not (before / name).exists():
            (before / name).write_bytes((OUTPUT / name).read_bytes())
    write_csv(RUN / 'cohort_audit_register.csv', register)
    pending_path = RUN / ('pending_evidence_current.csv' if latest_twelve else 'pending_evidence.csv')
    write_changed_csv(pending_path, [r for r in register if r['audit_status'] in ('evidence_hold', 'collection_hold')])
    if not any(r['audit_status'] in ('evidence_hold', 'collection_hold') for r in register):
        with pending_path.open('w', encoding='utf-8', newline='') as stream:
            csv.DictWriter(stream, fieldnames=list(register[0])).writeheader()
    write_csv(RUN / 'pending_exclusions.csv', [r for r in register if r['audit_status'] == 'excluded'])
    if not any(r['audit_status'] == 'excluded' for r in register):
        # write_csv deliberately skips empty inputs; clear the superseded queue.
        with (RUN / 'pending_exclusions.csv').open('w', encoding='utf-8', newline='') as stream:
            csv.DictWriter(stream, fieldnames=list(register[0])).writeheader()
    write_csv(RUN / 'checked_forecasts.csv', [r for r in register if r['audit_status'] == 'checks_passed'])
    write_csv(RUN / 'replacement_followups.csv', [r for r in register if r['origin']=='latest_ten_replacements' or r['earlier_six_followup']])
    family_rows = [dict(event_family_id=k, market_count=len(v), market_ids=';'.join(sorted(v)),
        grouping_rule=('One contract per audited real-world event family.' if family_unique else
                       'Same underlying match, election (including rounds), or economic release; distinct contracts retained.')) for k,v in sorted(groups.items())]
    write_csv(RUN / 'event_families.csv', family_rows)
    write_csv(OUTPUT / 'active_candidates.csv', active)
    write_csv(OUTPUT / 'active_cohort_coverage.csv', coverage)
    pilot_ids = {r['market_id'] for r in read(OUTPUT / 'active_pilot_candidates.csv')}
    write_csv(OUTPUT / 'active_pilot_candidates.csv', [r for r in active if r['market_id'] in pilot_ids])
    write_csv(OUTPUT / 'active_pilot_coverage.csv', [r for r in coverage if r['market_id'] in pilot_ids])
    for target in (RUN / 'validation_queue.csv', followup / 'validation_queue_updated.csv', OUTPUT / 'validation_queue.csv'):
        write_csv(target, [queue[r['market_id']] for r in active])
    write_csv(followup / 'current_eligibility_register.csv', [eligibility[r['market_id']] for r in active])
    summary = dict(updated_at_utc=datetime.now(timezone.utc).isoformat(), reviewed=len(active), tracking_rows=len(active),
        original_reviewed=600, omitted_without_replacement=len(membership['omitted_market_ids']) if membership else 0,
        status_counts=dict(Counter(r['audit_status'] for r in register)),
        evidence_status_counts=dict(Counter(r['evidence_status'] for r in register)),
        topics={t:dict(Counter(r['audit_status'] for r in register if r['topic']==t)) for t in ('Sports','Politics','Economics')},
        captures_present=sum(bool(r['capture_path']) for r in register), families=len(groups),
        shared_families=sum(len(v)>1 for v in groups.values()),
        checked_forecast_families=len({r['event_family_id'] for r in register if r['audit_status']=='checks_passed'}),
        latest_ten_status=dict(Counter(r['audit_status'] for r in register if r['origin']=='latest_ten_replacements')),
        latest_twelve_status=dict(Counter(r['audit_status'] for r in register if r['origin']=='full_audit_twelve_replacements')),
        pending_evidence_file=pending_path.name,
        earlier_six_status=dict(Counter(r['audit_status'] for r in register if r['earlier_six_followup'])),
        family_unique=family_unique, family_replacements=len(family_replacements),
        modeling_ready=False, membership_changed=bool(latest_twelve) or family_unique)
    (RUN / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    prior = json.loads((OUTPUT / 'approved_review_summary.json').read_text())
    prior.update(current_validation_report='full_audit_20260915/report.md', full_audit_summary=summary,
        replacement_validation_pending=sum(r['audit_status'] != 'checks_passed' for r in register if r['origin']!='existing_cohort'),
        replacement_collection_pending=len(active)-summary['captures_present'],
        confirmed_exclusions_pending_batch=summary['status_counts'].get('excluded', 0), active_correction_count=len(index))
    (OUTPUT / 'approved_review_summary.json').write_text(json.dumps(prior, indent=2), encoding='utf-8')
    write_report(summary, register)
    print(json.dumps(summary, indent=2))


def write_report(summary, rows):
    counts = summary['status_counts']
    total = summary['tracking_rows']
    omitted = summary.get('omitted_without_replacement', 0)
    lines = ['# Full cohort audit', '',
        f"**{counts.get('checks_passed', 0)} / {total} active markets pass the current evidence and collection checks.**", '',
        (f"The historical 600-slot study became 589 contracts after eleven omissions. The later family-unique revision retained 496 representatives and added {summary.get('family_replacements',0)} validated in-window reserves, producing {total} contracts. Historical evidence and captures remain preserved."
         if summary.get('family_unique') else f"All 600 pre-adoption candidates were reviewed. The user approved omitting {omitted} records without replacements; their original evidence and captures are preserved."), '',
        '| Topic | Active | Checks passed | Evidence hold | Collection hold | Exclude |',
        '|---|---:|---:|---:|---:|---:|']
    for topic,c in summary['topics'].items():
        lines.append(f"| {topic} | {sum(c.values())} | {c.get('checks_passed',0)} | {c.get('evidence_hold',0)} | {c.get('collection_hold',0)} | {c.get('excluded',0)} |")
    lines += ['', '## What passed means', '',
        'The named contract is in scope, participation and saved outcome are supported, and the documented event boundary follows the approved timing policy. The market was listed and open at its forecast cutoff. Its capture uses that cutoff, its most recent returned cutoff observation is no more than six hours old, the trade API exhausted the requested window, and market/condition/token/settlement mappings agree.', '',
        'Forecasts use the best-supported boundary minus 24 hours. Exact actual-start minutes are not required. Source precision, inference and uncertainty remain explicit; accepted review boundaries are distinguished from earlier verified boundaries. Timing sensitivity is recorded separately and does not choose the anchor based on forecast accuracy.', '',
        f"All {summary['captures_present']} effective captures are linked in the register. Recollected histories cover up to seven days before the corrected cutoff; earlier captures remain intact.", '',
        '## Completed evidence follow-up and omissions', '',
        'The earlier independent review supported 94 inclusions, one wrong-contest exclusion and ten unresolved records. Those eleven omitted identities remain excluded. The later family-replacement decision authorizes filling vacant slots with other eligible in-window events. Unresolved records are not relabeled as proven ineligible. The resulting sample conditions on evidence availability and is not an unchanged random sample of all markets.', '',
        '- [Family replacement ledger and current decision](../family_replacements_20260916/report.md)',
        '- [Adoption summary and omitted IDs](../adopt105_20260916/report.md)',
        '- [Omission ledger](../adopt105_20260916/omissions.csv)',
        '- [Original research report](evidence_followup/20260915T230630Z/report.md)',
        '- [94 adopted decisions](../adopt105_20260916/accepted_decisions.json)', '',
        '## Related markets and analysis limits', '',
        f"The {total} contracts map to {summary['families']} event families; {summary['shared_families']} families contain multiple sampled contracts. Keep related contracts together in train/test splits and account for them in uncertainty estimates.", '',
        'The register marks passing forecasts as analytical_inclusion=true and forecast_ready=true. modeling_ready remains false until analysis features and evaluation design are constructed. API exhaustion does not prove blockchain completeness. Identical-looking trade rows remain flagged rather than silently deleted; full wallet histories and historical order books have not been collected.', '',
        '## Remaining evidence', '',
        f"Active evidence holds: {counts.get('evidence_hold',0)}. Active collection holds: {counts.get('collection_hold',0)}. The original pending_evidence.csv is historical; use the current queue below. Omitted unresolved records remain in the omission archive for possible later research.", '',
        '## Files', '',
        '- [Active audit register](cohort_audit_register.csv)',
        '- [Forecasts passing checks](checked_forecasts.csv)',
        f"- [Current evidence and collection queue]({summary['pending_evidence_file']})",
        '- [Event families](event_families.csv)',
        '- [Detailed evidence JSON](market_decisions.json)',
        '- [Collection integrity report](../full_collection_report.md)', '',
        '## Reproduce', '', '```powershell', 'python -B src/refresh_full_audit.py',
        'python -B src/report_collection.py', '```', '',
        'Both commands are offline and enforce the exact approved roster in cohort_membership.json. Original sampling commands must not overwrite this audited cohort.', '']
    (RUN / 'report.md').write_text('\n'.join(lines), encoding='utf-8')


if __name__ == '__main__':
    main()
