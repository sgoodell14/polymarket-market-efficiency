"""Record reviewed evidence separately from immutable contracts and API captures.

Writing evidence does not activate a new collection window. The collection and
report steps must validate it against listing time, resolution and price coverage.
"""
import hashlib
import json
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from fetch_audit_sources import RUN


def inputs():
    return {r['market_id']: r for topic in ('sports', 'politics', 'economics')
            for r in json.loads((RUN / (topic + '_review_inputs.json')).read_text(encoding='utf-8'))}


def load():
    path = RUN / 'market_decisions.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}


def save(decisions):
    (RUN / 'market_decisions.json').write_text(json.dumps(decisions, indent=2, ensure_ascii=False), encoding='utf-8')


def boundary(rows, mid, local, zone, family, urls, evidence, expected=None,
             boundary_type='official_release_timestamp', **extra):
    mid = str(mid)
    dt = datetime.fromisoformat(local).replace(tzinfo=ZoneInfo(zone))
    return dict(market_id=mid, status='verified_boundary', local_time=local,
                time_zone=zone, anchor=dt.astimezone(timezone.utc).isoformat(),
                boundary_type=boundary_type, time_precision='minute',
                source_urls=urls, evidence=evidence, event_family_id=family,
                scope_status='in_scope', participation_status='event_occurred',
                expected_final_outcome=None if expected is None else str(int(expected)),
                outcome_check_status='not_yet_independently_checked' if expected is None else
                    ('matches_saved_label' if str(int(expected)) == rows[mid]['final_outcome'] else 'label_mismatch'),
                rules_sha256=hashlib.sha256(rows[mid]['rules'].encode()).hexdigest(),
                reviewed_at_utc=datetime.now(timezone.utc).isoformat(), **extra)


def exclusion(rows, mid, reason, urls, evidence):
    mid = str(mid)
    return dict(market_id=mid, status='exclude', scope_status='ineligible', reason=reason,
                source_urls=urls, evidence=evidence,
                rules_sha256=hashlib.sha256(rows[mid]['rules'].encode()).hexdigest(),
                reviewed_at_utc=datetime.now(timezone.utc).isoformat())


def hold(rows, mid, status, reason, urls, evidence, family, expected=None, **extra):
    """Record a reviewed contract with a specific unresolved evidence gate.

    A hold never invents an event anchor and cannot activate a collection window.
    Source URLs can support a partial finding; they do not imply full verification.
    """
    mid = str(mid)
    if status in ('verified_boundary', 'exclude'):
        raise ValueError('Use boundary() or exclusion() for a final decision')
    return dict(market_id=mid, status=status, reason=reason,
                scope_status='in_scope_pending_verification',
                source_urls=urls, evidence=evidence, event_family_id=family,
                expected_final_outcome=None if expected is None else str(int(expected)),
                outcome_check_status='not_yet_independently_checked' if expected is None else
                    ('matches_saved_label' if str(int(expected)) == rows[mid]['final_outcome'] else 'label_mismatch'),
                rules_sha256=hashlib.sha256(rows[mid]['rules'].encode()).hexdigest(),
                reviewed_at_utc=datetime.now(timezone.utc).isoformat(), **extra)
