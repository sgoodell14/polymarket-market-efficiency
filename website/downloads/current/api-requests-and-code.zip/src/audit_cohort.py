"""Inventory public closed markets by topic and month; cache exact HTTP bodies.

This audit is separate from the fixed pilot and does not overwrite its data.
Run with --run data/cohort_audit/<name>. Reusing a run resumes cached requests.
"""
import argparse
import gzip
import hashlib
import json
import time
import threading
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

GAMMA = "https://gamma-api.polymarket.com"
TAGS = {"sports": 1, "politics": 2, "economy": 100328, "economics": 225}
NETWORK_SLOTS = threading.BoundedSemaphore(8)


def stamp(value):
    if not value:
        return None
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return result.replace(tzinfo=timezone.utc) if result.tzinfo is None else result
    except (ValueError, TypeError):
        return None


def fetch(folder, name, base, path, **params):
    folder.mkdir(parents=True, exist_ok=True)
    url = base + path + "?" + urllib.parse.urlencode(params, doseq=True)
    datafile, metafile = folder / (name + ".json.gz"), folder / (name + ".request.json")
    if datafile.exists() and metafile.exists():
        meta = json.loads(metafile.read_text(encoding="utf-8"))
        body = gzip.decompress(datafile.read_bytes())
        if meta["url"] != url or hashlib.sha256(body).hexdigest() != meta["sha256"]:
            raise ValueError(f"Cache mismatch: {datafile}")
        return json.loads(body)
    request = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (compatible; MarketEfficiencyResearch/0.1)",
        "Accept": "application/json"})
    for attempt in range(4):
        try:
            with NETWORK_SLOTS:
                with urllib.request.urlopen(request, timeout=40) as response:
                    body, status = response.read(), response.status
            payload = json.loads(body)
            datafile.write_bytes(gzip.compress(body))
            metafile.write_text(json.dumps({"url": url, "status": status,
                "fetched_at_utc": datetime.now(timezone.utc).isoformat(),
                "sha256": hashlib.sha256(body).hexdigest()}, indent=2), encoding="utf-8")
            return payload
        except (urllib.error.URLError, TimeoutError) as error:
            if attempt == 3 or (isinstance(error, urllib.error.HTTPError)
                               and error.code not in (429, 500, 502, 503, 504)):
                raise
            time.sleep(2 ** attempt)


def months(start, end):
    current = stamp(start)
    stop = stamp(end)
    while current < stop:
        following = current.replace(year=current.year + (current.month == 12),
                                    month=current.month % 12 + 1, day=1)
        yield current, min(following, stop)
        current = following


def inventory_month(run, slug, lower, upper, depth=0, sports_cursor=False):
    period = lower.strftime("%Y-%m") if depth == 0 else lower.strftime("%Y%m%dT%H%M%S") + "_" + upper.strftime("%Y%m%dT%H%M%S")
    group = ("sports_moneyline_keyset" if sports_cursor else "sports_moneyline") if slug == "sports" else slug
    folder = run / "inventory" / group / period
    folder.mkdir(parents=True, exist_ok=True)
    cursor, seen_cursors, markets, pages = None, set(), {}, 0
    while True:
        # The legacy endpoint caps offsets at 2000. Partition the time interval
        # instead of treating that cap as the end of the available records.
        if slug == "sports" and not sports_cursor and pages == 21:
            if depth >= 15:
                raise ValueError("Sports interval remains too dense after partitioning")
            middle = lower + (upper - lower) / 2
            combined = {}
            intervals = [(lower, middle), (middle, upper)]
            if depth < 3:
                with ThreadPoolExecutor(max_workers=2) as pool:
                    parts = list(pool.map(lambda bounds: inventory_month(run, slug, *bounds, depth + 1), intervals))
            else:
                parts = [inventory_month(run, slug, first, last, depth + 1) for first, last in intervals]
            for _, subset, _ in parts:
                combined.update(subset)
            summary = {"slug": slug, "month": lower.strftime("%Y-%m"),
                       "count": len(combined), "pagination_complete": True, "partitioned": True}
            (folder / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
            if depth == 0:
                print("DONE", json.dumps(summary), flush=True)
            return slug, combined, summary
        params = dict(tag_id=TAGS[slug], closed="true", include_tag="true", limit=100,
                      order="id", ascending="true", end_date_min=lower.isoformat(),
                      end_date_max=upper.isoformat())
        if slug == "sports":
            params["sports_market_types"] = ["moneyline"]
            if not sports_cursor:
                params["offset"] = pages * 100
        if cursor and (slug != "sports" or sports_cursor):
            params["after_cursor"] = cursor
        payload = fetch(folder, f"page_{pages:05}", GAMMA,
                        "/markets" if slug == "sports" and not sports_cursor else "/markets/keyset", **params)
        if slug == "sports" and not sports_cursor and isinstance(payload, list):
            payload = {"markets": payload, "next_cursor": str(pages + 1) if len(payload) == 100 else None}
        if not isinstance(payload, dict) or not isinstance(payload.get("markets"), list):
            raise ValueError(f"Unexpected response for {slug} {lower}")
        for market in payload["markets"]:
            if slug == "sports" and market.get("sportsMarketType") != "moneyline":
                raise ValueError("Server did not honor the moneyline filter")
            end = stamp(market.get("endDate"))
            if end and lower <= end < upper:
                markets[str(market["id"])] = market
        pages += 1
        if pages % 25 == 0:
            print(f"PROGRESS {slug} {lower:%Y-%m}: {pages} pages, {len(markets)} markets", flush=True)
        cursor = payload.get("next_cursor")
        if not cursor:
            break
        if cursor in seen_cursors:
            raise ValueError(f"Repeated cursor for {slug} {lower}")
        seen_cursors.add(cursor)
    summary = {"slug": slug, "month": lower.strftime("%Y-%m"), "pages": pages,
               "count": len(markets), "pagination_complete": True}
    (folder / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    if depth == 0:
        print("DONE", json.dumps(summary), flush=True)
    return slug, markets, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--start", default="2025-09-01T00:00:00Z")
    parser.add_argument("--end", default="2026-09-01T00:00:00Z")
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--tags", nargs="+", choices=list(TAGS), default=list(TAGS))
    args = parser.parse_args()
    args.run.mkdir(parents=True, exist_ok=True)
    settings = {"start_inclusive": args.start, "end_exclusive": args.end,
                "time_field": "endDate (scheduled market end, not resolution date)",
                "tag_ids": {slug: TAGS[slug] for slug in args.tags}, "closed": True, "minimum_volume": None,
                "economics_topic": "Union of economy and economics exact tags",
                "sports_scope": "Individual game outcomes: sports_market_types=moneyline",
                "created_at_utc": datetime.now(timezone.utc).isoformat()}
    (args.run / "selection.json").write_text(json.dumps(settings, indent=2), encoding="utf-8")
    by_tag, summaries, errors = {slug: {} for slug in args.tags}, [], []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        tasks = {pool.submit(inventory_month, args.run, slug, lower, upper,
                             sports_cursor=slug == "sports" and not (args.run / "inventory" / "sports_moneyline" / lower.strftime("%Y-%m") / "summary.json").exists()): (slug, lower)
                 for lower, upper in months(args.start, args.end) for slug in args.tags}
        for task in as_completed(tasks):
            try:
                slug, markets, summary = task.result()
                by_tag[slug].update(markets)
                summaries.append(summary)
            except Exception as error:
                slug, lower = tasks[task]
                errors.append({"slug": slug, "month": str(lower), "error": str(error)})
                print("ERROR", errors[-1], flush=True)
    for slug, markets in by_tag.items():
        (args.run / (slug + "_markets.json.gz")).write_bytes(
            gzip.compress(json.dumps(list(markets.values())).encode()))
    result = {"counts": {k: len(v) for k, v in by_tag.items()},
              "months": summaries, "errors": errors,
              "pagination_complete": not errors}
    (args.run / "inventory_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("FINAL", json.dumps(result["counts"]), "errors", len(errors), flush=True)
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
