"""Bounded public-data collection for the pilot or full sample, with coverage evidence.

Event times remain provisional. No output is labeled a validated forecasting row.
"""
import argparse
import csv
import gzip
import json
import math
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from audit_cohort import fetch, stamp
from prepare_sampling_plan import OUTPUT, active_candidates, write_csv

PAGE_SIZE = 1000
MAX_TRADE_REQUESTS = 50


def collect_trades(folder, condition, lower, upper, request=fetch, budget=MAX_TRADE_REQUESTS):
    """Bisect saturated inclusive-second windows; never infer completeness at cap.

    Request a one-second lower overlap, then filter locally. This tolerates
    either inclusive or exclusive API lower-bound semantics without losing
    same-second fills. Parent responses are replaced by disjoint child leaves.
    """
    calls = 0
    failures = []

    def window(lo, hi):
        nonlocal calls
        if calls >= budget:
            failures.append("request_budget_reached")
            return [], False
        calls += 1
        try:
            rows = request(folder, f"trades_{lo}_{hi}", "https://data-api.polymarket.com", "/trades",
                           market=condition, takerOnly="false", start=lo - 1, end=hi,
                           limit=PAGE_SIZE, offset=0)
            if not isinstance(rows, list):
                raise ValueError("Unexpected trade response")
            if any(t.get("conditionId") != condition or not isinstance(t.get("timestamp"), int)
                   or not lo - 1 <= t["timestamp"] <= hi for t in rows):
                raise ValueError("Trade market/time filter not honored")
            accepted = [t for t in rows if lo <= t["timestamp"] <= hi]
            if len(rows) < PAGE_SIZE:
                return accepted, True
            if lo == hi:
                failures.append("single_second_saturated")
                return accepted, False
            if calls >= budget:
                failures.append("request_budget_reached")
                return accepted, False
            mid = (lo + hi) // 2
            left, left_ok = window(lo, mid)
            right, right_ok = window(mid + 1, hi)
            if left_ok and right_ok:
                return left + right, True
            # Retain the parent sample when a child was incomplete. Do not
            # combine it with overlapping children or silently deduplicate fills.
            return accepted, False
        except Exception as error:
            failures.append(type(error).__name__ + ": " + str(error))
            return [], False

    rows, exhausted = window(lower, upper)
    return rows, exhausted, calls, sorted(set(failures))


def price_summary(history, lower, cutoff):
    valid = sorted([p for p in history if isinstance(p.get("t"), (int, float))
                    and lower <= p["t"] <= cutoff and isinstance(p.get("p"), (int, float))
                    and 0 <= p["p"] <= 1], key=lambda p: p["t"])
    recent = [p for p in valid if cutoff - p["t"] <= 21600]
    return valid, {"price_status": "available" if recent else "no_price_within_6h",
                   "price_points": len(valid), "forecast_probability": recent[-1]["p"] if recent else "",
                   "forecast_price_age_seconds": cutoff - recent[-1]["t"] if recent else "",
                   "max_price_gap_seconds": max([b["t"] - a["t"] for a, b in zip(valid, valid[1:])], default=0),
                   "price_first_timestamp": valid[0]["t"] if valid else "",
                   "price_last_timestamp": valid[-1]["t"] if valid else ""}


def cutoff_fallback_summary(hourly_stats, history, lower, cutoff):
    """Recover only the cutoff snapshot; leave hourly feature-series stats intact."""
    valid, fallback = price_summary(history, lower, cutoff)
    result = dict(hourly_stats, hourly_price_status=hourly_stats["price_status"],
                  cutoff_fallback_points=len(valid))
    if hourly_stats["price_status"] != "available" and fallback["price_status"] == "available":
        for key in ("price_status", "forecast_probability", "forecast_price_age_seconds"):
            result[key] = fallback[key]
        result.update(cutoff_price_source="one_minute_fallback",
                      cutoff_price_timestamp=cutoff - fallback["forecast_price_age_seconds"])
    return result


def collect_one(row, output_root=None, trade_budget=MAX_TRADE_REQUESTS):
    folder = (output_root or OUTPUT) / "pilot_collection" / row["market_id"]
    folder.mkdir(parents=True, exist_ok=True)
    result_path = folder / "result.json"
    started = time.perf_counter()
    cutoff = int(stamp(row["anchor"]).timestamp()) - 86400
    lower = max(cutoff - 7 * 86400, math.ceil(stamp(row["start_date"]).timestamp()))
    if lower > cutoff:
        raise ValueError("Market was not listed at the requested cutoff")
    if result_path.exists():
        cached = json.loads(result_path.read_text(encoding="utf-8"))
        if (cached["market_id"] != row["market_id"] or cached["anchor"] != row["anchor"]
                or cached["cutoff_timestamp"] != cutoff or cached["window_start_timestamp"] != lower):
            raise ValueError("Collection inputs changed; use a new collection run/version")
        return cached
    result = dict(topic=row["topic"], market_id=row["market_id"], question=row["question"],
                  event_ids=row["event_ids"], anchor=row["anchor"], anchor_source=row["anchor_source"],
                  event_time_verified=False, cutoff_timestamp=cutoff, window_start_timestamp=lower,
                  window_hours=max(0, cutoff - lower) / 3600,
                  shorter_than_seven_days=lower > cutoff - 7 * 86400,
                  full_trade_history_verified=False, modeling_ready=False)
    try:
        market = fetch(folder, "market", "https://gamma-api.polymarket.com", "/markets/" + row["market_id"])
        if str(market.get("id")) != row["market_id"] or market.get("conditionId") != row["condition_id"]:
            raise ValueError("Metadata identifier mismatch")
        result["metadata_status"] = "retrieved"
        result["rules_text_present"] = bool(market.get("description"))
        from screen_cohort import screen
        fresh = screen(market, row["topic"])
        # The detail endpoint can omit event.startTime; that is not evidence
        # that a scheduled event changed. Keep the inventory anchor for this run.
        result["detail_anchor_source"] = fresh["anchor_source"]
        result["detail_anchor_differs"] = fresh["anchor"] != row["anchor"]
    except Exception as error:
        result["metadata_status"] = "error: " + str(error)
    try:
        payload = fetch(folder, "prices_hourly", "https://clob.polymarket.com", "/prices-history",
                        market=row["first_token_id"], startTs=lower - 1, endTs=cutoff, fidelity=60)
        valid, stats = price_summary(payload["history"], lower, cutoff)
        result.update(stats)
        (folder / "prices_window.json.gz").write_bytes(gzip.compress(json.dumps(valid).encode()))
        if stats["price_status"] != "available":
            try:
                fallback_lower = max(lower, cutoff - 21600)
                fallback = fetch(folder, "cutoff_price_fallback", "https://clob.polymarket.com", "/prices-history",
                                 market=row["first_token_id"], startTs=fallback_lower - 1, endTs=cutoff, fidelity=1)
                result.update(cutoff_fallback_summary(stats, fallback["history"], fallback_lower, cutoff))
            except Exception as error:
                result["cutoff_fallback_error"] = str(error)
    except Exception as error:
        result.update(price_status="error: " + str(error), price_points=0)
    trades, exhausted, calls, errors = collect_trades(folder, row["condition_id"], lower, cutoff, budget=trade_budget)
    (folder / "trades_window.json.gz").write_bytes(gzip.compress(json.dumps(trades).encode()))
    # Exact duplicates remain in the captured data: transactionHash is not a
    # unique fill ID. Do not turn these diagnostics into volume/concentration yet.
    signatures = [json.dumps(t, sort_keys=True, separators=(",", ":")) for t in trades]
    result.update(trade_status="api_window_exhausted" if exhausted else "incomplete", trade_request_budget=trade_budget,
                  trade_requests=calls, trade_rows=len(trades), trade_errors="; ".join(errors),
                  observed_wallets=len({t["proxyWallet"] for t in trades if t.get("proxyWallet")}),
                  exact_duplicate_candidates=len(signatures) - len(set(signatures)),
                  earliest_trade_timestamp=min([t["timestamp"] for t in trades], default=""),
                  latest_trade_timestamp=max([t["timestamp"] for t in trades], default=""),
                  elapsed_seconds=round(time.perf_counter() - started, 3),
                  captured_at_utc=datetime.now(timezone.utc).isoformat())
    result["saved_payload_bytes"] = sum(p.stat().st_size for p in folder.glob("*.gz"))
    result_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(row["topic"], row["market_id"], result["price_status"], result["trade_status"], len(trades), flush=True)
    return result


def collect_effective(row):
    """Use the latest approved capture without relabeling original histories."""
    index_path = OUTPUT / "corrections/active_corrections.json"
    index = json.loads(index_path.read_text(encoding="utf-8")) if index_path.exists() else {}
    if row["market_id"] not in index:
        return collect_one(row)
    root = OUTPUT / "corrections" / index[row["market_id"]]
    manifest = json.loads((root / "correction.json").read_text(encoding="utf-8"))
    revised = dict(row, anchor=stamp(manifest["corrected_anchor_utc"]).isoformat())
    return collect_one(revised, output_root=root)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--scope", choices=("pilot", "full"), default="pilot",
                        help="Collect the current nested pilot or the approved active cohort.")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    source = "active_candidates.csv" if args.scope == "full" else "active_pilot_candidates.csv"
    prefix = "active_cohort" if args.scope == "full" else "active_pilot"
    with (OUTPUT / source).open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    from cohort_state import validate_membership
    if args.scope == 'full':
        validate_membership(rows)
    else:
        with (OUTPUT / 'active_candidates.csv').open(encoding='utf-8', newline='') as handle:
            full = list(csv.DictReader(handle))
        validate_membership(full)
        if len(rows) != len({r['market_id'] for r in rows}) or not {r['market_id'] for r in rows} <= {r['market_id'] for r in full}:
            raise ValueError('Pilot IDs must be unique and nested in the active cohort')
    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(collect_effective, rows))
    write_csv(OUTPUT / (prefix + "_coverage.csv"), results)
    summary = {"scope": args.scope, "markets": len(results),
               "invocation_wall_seconds": round(time.perf_counter() - started, 3),
               "sum_market_collection_seconds": round(sum(r["elapsed_seconds"] for r in results), 3),
               "compressed_payload_bytes": sum(r["saved_payload_bytes"] for r in results),
               "trade_requests": sum(r["trade_requests"] for r in results),
               "trade_rows": sum(r["trade_rows"] for r in results),
               "price_points": sum(r["price_points"] for r in results),
               "topics": {},
               "limitations": ["Forecast cutoffs use provisional metadata, not verified actual event times.",
                               "API window exhaustion means all queried leaves returned below limit; not independent ledger reconciliation.",
                               "Initial collection uses 50 trade requests/market; targeted recoveries record their increased budget separately. Incomplete windows remain flagged.",
                               "Wallet identities/duplicate fills need review before activity features; no full wallet histories or orders collected."]}
    for topic in sorted({r["topic"] for r in results}):
        subset = [r for r in results if r["topic"] == topic]
        summary["topics"][topic] = dict(markets=len(subset), prices=dict(Counter(r["price_status"] for r in subset)),
            trades=dict(Counter(r["trade_status"] for r in subset)),
            trade_rows=sum(r["trade_rows"] for r in subset), price_points=sum(r["price_points"] for r in subset),
            shortened_windows=sum(r["shorter_than_seven_days"] for r in subset),
            explicit_anchor_fields=sum(r["anchor_source"] != "endDate_proxy" for r in subset),
            compressed_payload_bytes=sum(r["saved_payload_bytes"] for r in subset))
    if args.scope == "pilot":
        summary["pilot_markets"] = len(results)
    (OUTPUT / (prefix + "_summary.json")).write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
