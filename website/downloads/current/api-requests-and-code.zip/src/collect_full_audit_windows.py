"""Plan/recollect only supported full-audit windows; preserve previous captures."""
import argparse
import json
from concurrent.futures import ThreadPoolExecutor

from audit_cohort import stamp
from full_audit_evidence import RUN, inputs, load
from prepare_sampling_plan import OUTPUT, write_csv
from validate_replacement_windows import SUPPORTED_STATUSES, collect, timing_review, validate_spec


def plan():
    rows, decisions = inputs(), load()
    index = json.loads((OUTPUT / 'corrections/active_corrections.json').read_text())
    jobs, records = [], []
    for mid, spec in decisions.items():
        record = dict(market_id=mid, topic=rows[mid]['topic'], question=rows[mid]['question'])
        if spec['status'] not in SUPPORTED_STATUSES:
            records.append(dict(record, status='held', reasons=spec['status']))
            continue
        reasons = validate_spec(rows[mid], spec)
        verified, status = timing_review(spec)
        if not verified:
            reasons.append(status)
        if spec.get('outcome_check_status') not in ('matches_saved_label', 'matches_saved_resolution', 'independently_confirmed'):
            # Existing evidence uses several precise outcome status descriptions.
            if spec.get('expected_final_outcome') is None:
                reasons.append('external_outcome_check_pending')
        if reasons:
            records.append(dict(record, status='held', reasons=';'.join(reasons)))
            continue
        base = OUTPUT / 'corrections' / index[mid] if mid in index else OUTPUT
        path = base / 'pilot_collection' / mid / 'result.json'
        capture = json.loads(path.read_text()) if path.exists() else {}
        cutoff = int(stamp(spec['anchor']).timestamp()) - 86400
        if capture.get('cutoff_timestamp') == cutoff and capture.get('price_status') == 'available' and capture.get('trade_status') == 'api_window_exhausted':
            records.append(dict(record, status='existing_capture_matches_verified_cutoff', cutoff_timestamp=cutoff))
        else:
            records.append(dict(record, status='recollection_required', cutoff_timestamp=cutoff))
            jobs.append((dict(rows[mid], event_family_id=spec.get('event_family_id', '')), spec))
    write_csv(RUN / 'collection_plan.csv', records)
    return jobs, records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--collect', action='store_true')
    args = parser.parse_args()
    jobs, records = plan()
    from collections import Counter
    print(json.dumps(dict(Counter(r['status'] for r in records))), flush=True)
    if not args.collect:
        return
    index_path = OUTPUT / 'corrections/active_corrections.json'
    snapshot = RUN / 'before/active_corrections.json'
    if not snapshot.exists():
        snapshot.write_bytes(index_path.read_bytes())
    results_path = RUN / 'collection_results.json'
    results = json.loads(results_path.read_text()) if results_path.exists() else {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        for result in pool.map(collect, jobs):
            results[result['market_id']] = result
            if result['applied']:
                index = json.loads(index_path.read_text())
                index[result['market_id']] = result['capture']
                index_path.write_text(json.dumps(index, indent=2), encoding='utf-8')
            results_path.write_text(json.dumps(results, indent=2), encoding='utf-8')
            print(json.dumps(result), flush=True)
    write_csv(RUN / 'collection_results.csv', list(results.values()))


if __name__ == '__main__':
    main()
