"""Cache public external evidence, including URL, retrieval time and body hash."""
import gzip
import hashlib
import json
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from prepare_sampling_plan import OUTPUT

RUN = OUTPUT / "full_audit_20260915"


def fetch(url):
    folder = RUN / "sources"
    folder.mkdir(exist_ok=True)
    key = hashlib.sha256(url.encode()).hexdigest()[:24]
    meta_path = folder / (key + ".json")
    body_path = folder / (key + ".body.gz")
    if body_path.exists() and meta_path.exists():
        return json.loads(meta_path.read_text())
    meta = dict(url=url,retrieved_at_utc=datetime.now(timezone.utc).isoformat(),key=key)
    try:
        request=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 (compatible; academic public-data audit)"})
        with urllib.request.urlopen(request, timeout=35) as response:
            body=response.read()
            meta.update(status="retrieved",http_status=response.status,final_url=response.url,
                content_type=response.headers.get("Content-Type"),sha256=hashlib.sha256(body).hexdigest(),bytes=len(body))
        body_path.write_bytes(gzip.compress(body))
    except Exception as error:
        meta.update(status="error",error=str(error))
    meta_path.write_text(json.dumps(meta,indent=2),encoding="utf-8")
    return meta


def cached(url):
    key=hashlib.sha256(url.encode()).hexdigest()[:24]
    return gzip.decompress((RUN/"sources"/(key+".body.gz")).read_bytes())


if __name__ == "__main__":
    urls=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    with ThreadPoolExecutor(max_workers=4) as pool:
        for result in pool.map(fetch,urls):
            print(json.dumps(result),flush=True)
