"""Collect source-backed replacement windows without certifying the full cohort.

Evidence is reviewed in market_decisions.json. Raw captures are immutable per
anchor/evidence version; successful captures alone enter the correction index.
"""
import csv
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from audit_cohort import stamp
from collect_sample_pilot import collect_one
from prepare_sampling_plan import OUTPUT, write_csv

RUN = OUTPUT / "validation_20260915"
SUPPORTED_STATUSES = {"verified_boundary", "accepted_review_boundary"}
APPROXIMATE_POLICY = "user_approved_approximate_24h_20260915"


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def validate_spec(row, spec):
    """Reject inconsistent evidence before issuing requests or changing the index."""
    anchor = stamp(spec["anchor"])
    cutoff = anchor - timedelta(hours=24)
    reasons = []
    if not spec.get("source_urls") or not spec.get("evidence"):
        reasons.append("missing_boundary_evidence")
    local = datetime.fromisoformat(spec["local_time"]).replace(tzinfo=ZoneInfo(spec["time_zone"]))
    if local.astimezone(timezone.utc) != anchor:
        reasons.append("local_utc_conversion_mismatch")
    if not stamp("2025-09-01T00:00:00Z") <= anchor < stamp("2026-09-01T00:00:00Z"):
        reasons.append("actual_event_outside_study_window")
    if stamp(row["start_date"]) > cutoff:
        reasons.append("listed_after_verified_cutoff")
    if stamp(row["closed_time"]) <= cutoff:
        reasons.append("closed_before_verified_cutoff")
    if str(spec.get("expected_final_outcome")) != row["final_outcome"]:
        reasons.append("external_outcome_disagrees_with_saved_label")
    return reasons


def timing_review(spec):
    """A publication timestamp is not proof of the earliest public announcement."""
    if spec.get("status") == "accepted_review_boundary":
        supported = (spec.get("timing_policy") == APPROXIMATE_POLICY
                     and spec.get("research_disposition") == "SUPPORTED_FOR_INCLUSION"
                     and bool(spec.get("review_record")) and bool(spec.get("time_precision"))
                     and bool(spec.get("source_urls")) and bool(spec.get("evidence")))
        return supported, "review_boundary_accepted_with_recorded_precision" if supported else "review_acceptance_incomplete"
    if spec["boundary_type"] == "official_statement_publication_timestamp":
        return False, "earlier_press_conference_not_reconciled"
    if spec.get("possible_release_interval_utc"):
        return False, "first_public_release_bounded_not_exact"
    return True, "source_supported_boundary"


def collect(job):
    row, spec = job
    mid = row["market_id"]
    anchor = stamp(spec["anchor"])
    cutoff = anchor - timedelta(hours=24)
    reasons = validate_spec(row, spec)
    if reasons:
        return dict(market_id=mid, applied=False, validation_status=";".join(reasons))
    digest = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:10]
    name = "validated_" + mid + "_" + digest
    base = OUTPUT / "corrections" / name
    # Keep failed captures as evidence, but do not reuse a cached failure forever.
    initial_name, attempt = name, 0
    while (base / "pilot_collection" / mid / "result.json").exists():
        previous = json.loads((base / "pilot_collection" / mid / "result.json").read_text(encoding="utf-8"))
        if (previous.get("metadata_status") == "retrieved" and previous.get("price_status") == "available"
                and previous.get("trade_status") == "api_window_exhausted"):
            break
        attempt += 1
        name = initial_name + "_retry" + str(attempt)
        base = OUTPUT / "corrections" / name
    revised = dict(row, anchor=anchor.isoformat(), anchor_source=spec["boundary_type"])
    result = collect_one(revised, output_root=base, trade_budget=250)
    ready = (result["metadata_status"] == "retrieved" and result["price_status"] == "available"
             and result["trade_status"] == "api_window_exhausted")
    verified, timing_status = timing_review(spec)
    exact_gate = verified and spec.get("status") != "accepted_review_boundary"
    result.update(event_time_verified=exact_gate, event_time_supported=verified, timing_review_status=timing_status, boundary_type=spec["boundary_type"],
        event_time_source_url=spec["source_urls"][0], event_family_id=row.get("event_family_id", ""),
        event_time_precision=spec["time_precision"], participation_status=spec["participation_status"],
        outcome_check_status=spec["outcome_check_status"], modeling_ready=False,
        event_time_evidence=spec["evidence"])
    path = base / "pilot_collection" / mid / "result.json"
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    manifest = dict(market_id=mid, original_anchor_utc=row["anchor"], corrected_anchor_utc=spec["anchor"],
        corrected_cutoff_utc=cutoff.isoformat(), boundary_type=spec["boundary_type"],
        event_family_id=row.get("event_family_id", ""), source_urls=spec["source_urls"],
        evidence=spec["evidence"], evidence_type="independently_researched_event_sources",
        original_capture_preserved=True, event_time_verified=exact_gate, event_time_supported=verified,
        time_precision=spec["time_precision"], timing_review_status=timing_status,
        status=("replacement_verified_window_collected" if verified else "replacement_provisional_window_collected") if ready else "collection_incomplete")
    (base / "correction.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return dict(market_id=mid, applied=ready, capture=name, anchor=spec["anchor"],
        validation_status=("verified_window_collected" if verified else "provisional_window_collected") if ready else "collection_incomplete",
        event_time_verified=exact_gate, event_time_supported=verified, timing_review_status=timing_status,
        price_status=result["price_status"], trade_status=result["trade_status"],
        trade_rows=result["trade_rows"], forecast_price_age_seconds=result.get("forecast_price_age_seconds", ""))


def main():
    decisions = json.loads((RUN / "market_decisions.json").read_text(encoding="utf-8"))
    active = {r["market_id"]: r for r in read(OUTPUT / "active_candidates.csv")}
    jobs = [(active[mid], spec) for mid, spec in decisions.items()
            if mid in active and spec["status"] == "verified_boundary"]
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(collect, jobs))
    index_path = OUTPUT / "corrections/active_corrections.json"
    index = json.loads(index_path.read_text())
    for r in results:
        if r["applied"]:
            index[r["market_id"]] = r["capture"]
    index_path.write_text(json.dumps(index, indent=2), encoding="utf-8")
    write_csv(RUN / "collection_results.csv", results)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
