"""Retry the three capped trade windows and diagnose seven missing cutoff prices.

Preserve initial captures. Reuse their exact cached responses for trade retries.
Do not replace markets, change anchors, widen staleness, or use post-cutoff prices.
"""
import csv
import gzip
import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from audit_cohort import fetch
from collect_sample_pilot import collect_one, price_summary
from prepare_sampling_plan import OUTPUT, write_csv

TRADE_IDS = ("553810", "906972", "601699")
PRICE_IDS = ("1773899", "2818289", "1937871", "1429620", "525019", "1600958", "1011748")
BUDGET = 250


def recover_trade(row):
    mid = row["market_id"]
    original = OUTPUT / "pilot_collection" / mid
    folder_name = mid + "_trade_budget250"
    root = OUTPUT / "corrections" / folder_name
    target = root / "pilot_collection" / mid
    target.mkdir(parents=True, exist_ok=True)
    # Only request caches: do not copy result.json or filtered derived windows.
    for source in original.glob("*.request.json"):
        payload = source.with_name(source.name.replace(".request.json", ".json.gz"))
        for item in (source, payload):
            if not (target / item.name).exists():
                shutil.copy2(item, target / item.name)
    result = collect_one(row, output_root=root, trade_budget=BUDGET)
    manifest = {"market_id": mid, "original_anchor_utc": row["anchor"],
                "corrected_anchor_utc": row["anchor"], "correction_type": "trade_collection_budget_extension",
                "original_capture_preserved": True, "anchor_changed": False,
                "initial_trade_budget": 50, "trade_request_budget": BUDGET,
                "status": result["trade_status"],
                "note": "Additional time-window queries recover a previously capped history; event audit status is unchanged."}
    (root / "correction.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return mid, folder_name, result


def diagnose_price(row):
    mid = row["market_id"]
    original = json.loads((OUTPUT / "pilot_collection" / mid / "result.json").read_text())
    lower = max(original["window_start_timestamp"], original["cutoff_timestamp"] - 21600)
    cutoff = original["cutoff_timestamp"]
    folder = OUTPUT / "recovery" / "price_diagnostics" / mid
    stats = []
    for fidelity in (60, 1):
        payload = fetch(folder, "cutoff_fidelity_" + str(fidelity), "https://clob.polymarket.com", "/prices-history",
                        market=row["first_token_id"], startTs=lower - 1, endTs=cutoff, fidelity=fidelity)
        valid, result = price_summary(payload["history"], lower, cutoff)
        stats.append(dict(market_id=mid, topic=row["topic"], question=row["question"], fidelity_minutes=fidelity,
                          anchor=row["anchor"], anchor_source=row["anchor_source"],
                          lower_timestamp=lower, cutoff_timestamp=cutoff, **result))
        assert all(lower <= p["t"] <= cutoff for p in valid)
    print("PRICE DIAGNOSTIC", mid, [(r["fidelity_minutes"], r["price_status"]) for r in stats], flush=True)
    return stats


def main():
    with (OUTPUT / "active_candidates.csv").open(encoding="utf-8", newline="") as handle:
        candidates = {r["market_id"]: r for r in csv.DictReader(handle)}
    with ThreadPoolExecutor(max_workers=3) as pool:
        recovered = list(pool.map(recover_trade, [candidates[mid] for mid in TRADE_IDS]))
    index_path = OUTPUT / "corrections/active_corrections.json"
    index = json.loads(index_path.read_text())
    for mid, folder, result in recovered:
        if result["trade_status"] == "api_window_exhausted":
            index[mid] = folder
    index_path.write_text(json.dumps(index, indent=2), encoding="utf-8")
    with ThreadPoolExecutor(max_workers=3) as pool:
        diagnostics = [r for rows in pool.map(diagnose_price, [candidates[mid] for mid in PRICE_IDS]) for r in rows]
    write_csv(OUTPUT / "recovery/price_diagnostics.csv", diagnostics)
    summary = {"checked_at_utc": datetime.now(timezone.utc).isoformat(),
               "trades": [{k: r[k] for k in ("market_id", "trade_rows", "trade_requests", "trade_status", "trade_errors")} for _, _, r in recovered],
               "price_diagnostics_only": True, "price_anchors_changed": False, "markets_replaced": 0,
               "note": "Price diagnostic responses do not automatically replace the original forecasting series or resolve anchor eligibility."}
    (OUTPUT / "recovery/summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
