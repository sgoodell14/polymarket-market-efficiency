"""Screen the cohort inventory and optionally audit prices/trades on a fixed sample.

Eligibility is a metadata screen, not verification of event times or full histories.
"""
import argparse
import csv
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import timedelta
from pathlib import Path

from audit_cohort import fetch, stamp
from clean_data import resolved_outcome
from prove_data import json_list


def read_markets(run, slug):
    return json.loads(gzip.decompress((run / (slug + "_markets.json.gz")).read_bytes()))


def screen(m, topic):
    tags = {t["slug"].lower() for t in m.get("tags", [])}
    mention = "mention-markets" in tags
    if topic == "Sports":
        subtype = "game_winner"
    elif mention:
        subtype = "mentions"
    elif topic == "Politics":
        subtype = "elections" if tags & {"elections", "global-elections", "world-elections", "primaries", "primary-elections"} else "other"
    else:
        subtype = "macro_policy" if tags & {"macro-indicators", "inflation", "cpi", "gdp", "unemployment", "jobs-report", "fed-rates", "global-rates", "fomc", "cpi-release"} else "other"
    outcomes, tokens = json_list(m.get("outcomes")), json_list(m.get("clobTokenIds"))
    resolution, final, _ = resolved_outcome(m)
    basic = bool(resolution is not None and len(outcomes) == len(tokens) == 2 and m.get("conditionId"))
    events = m.get("events", [])
    explicit = []
    if stamp(m.get("gameStartTime")):
        explicit.append((stamp(m["gameStartTime"]), "gameStartTime"))
    for event in events:
        if stamp(event.get("startTime")):
            explicit.append((stamp(event["startTime"]), "event.startTime"))
    conflict = bool(explicit and max(t[0] for t in explicit) - min(t[0] for t in explicit) > timedelta(hours=1))
    anchor, source = explicit[0] if explicit else (stamp(m.get("endDate")), "endDate_proxy")
    start, closed = stamp(m.get("startDate")), stamp(m.get("closedTime"))
    row = {"topic": topic, "subtype": subtype, "is_mention": mention, "market_id": str(m["id"]),
           "question": m["question"], "slug": m.get("slug"),
           "condition_id": m.get("conditionId"), "first_token_id": str(tokens[0]) if tokens else "",
           "event_ids": ";".join(str(e["id"]) for e in events),
           "tag_slugs": ";".join(sorted(tags)), "start_date": m.get("startDate"),
           "end_date": m.get("endDate"), "closed_time": m.get("closedTime"),
           "anchor": anchor.isoformat() if anchor else "", "anchor_source": source,
           "anchor_conflict": conflict, "binary_resolved": basic, "final_outcome": final,
           "reported_volume": m.get("volumeNum", m.get("volume")),
           "closed_before_anchor": bool(closed and anchor and closed < anchor)}
    for hours in (1, 24, 168):
        row[f"candidate_{hours}h"] = bool(basic and anchor and start and closed and
            start <= anchor - timedelta(hours=hours) and closed >= anchor - timedelta(hours=hours) and not conflict)
    return row


def write_csv(path, rows):
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def select_sample(rows):
    groups = {"Sports": lambda r: r["topic"] == "Sports",
              "Politics_elections": lambda r: r["topic"] == "Politics" and r["subtype"] == "elections",
              "Economics_macro_policy": lambda r: r["topic"] == "Economics" and r["subtype"] == "macro_policy"}
    sample = []
    for group, predicate in groups.items():
        candidates = [r for r in rows if predicate(r) and r["candidate_1h"]]
        # Stable shuffled ordering, then round-robin months, at most one market
        # per event. This is a coverage audit, not a representative outcome study.
        buckets = defaultdict(list)
        for row in sorted(candidates, key=lambda r: hashlib.sha256(("cohort-audit-v1:" + r["market_id"]).encode()).hexdigest()):
            buckets[row["end_date"][:7]].append(row)
        chosen, seen = [], set()
        while len(chosen) < 30:
            grew = False
            for month in sorted(buckets):
                while buckets[month]:
                    row = buckets[month].pop(0)
                    event_keys = set(row["event_ids"].split(";")) - {""} or {"market:" + row["market_id"]}
                    if not seen.intersection(event_keys):
                        seen.update(event_keys)
                        chosen.append(dict(row, audit_group=group))
                        grew = True
                        break
                if len(chosen) == 30:
                    break
            if not grew:
                break
        sample.extend(chosen)
    return sample


def audit_one(run, row):
    folder = run / "coverage" / row["market_id"]
    result = dict(row)
    anchor = stamp(row["anchor"])
    for hours in (1, 24):
        key = f"price_{hours}h"
        result[key + "_status"] = "not_eligible"
        result[key] = ""
        result[key + "_age_seconds"] = ""
        if not row[f"candidate_{hours}h"]:
            continue
        target = int((anchor - timedelta(hours=hours)).timestamp())
        # At most one hour stale for a 1h forecast, six hours for a 24h forecast.
        tolerance = 3600 if hours == 1 else 21600
        try:
            payload = fetch(folder, key, "https://clob.polymarket.com", "/prices-history",
                            market=row["first_token_id"], startTs=target - tolerance,
                            endTs=target, fidelity=1)
            history = payload.get("history", [])
            valid = [p for p in history if target - tolerance <= p.get("t", 0) <= target
                     and p.get("t", 0) >= stamp(row["start_date"]).timestamp()
                     and isinstance(p.get("p"), (float, int)) and 0 <= p["p"] <= 1]
            if valid:
                point = max(valid, key=lambda p: p["t"])
                result[key + "_status"] = "available"
                result[key] = point["p"]
                result[key + "_age_seconds"] = target - point["t"]
            else:
                result[key + "_status"] = "no_prior_price"
        except Exception as error:
            result[key + "_status"] = "request_error: " + str(error)
    # This probe establishes retrievability only. It does not assert that the
    # endpoint honors a historical cutoff or that trade coverage is complete.
    try:
        trades = fetch(folder, "trades_probe", "https://data-api.polymarket.com", "/trades",
                       market=row["condition_id"], takerOnly="false", limit=5, offset=0)
        result["trade_probe_rows"] = len(trades) if isinstance(trades, list) else 0
        result["trade_probe_joined"] = sum(t.get("conditionId") == row["condition_id"] for t in trades) if isinstance(trades, list) else 0
        result["trade_probe_status"] = "rows_returned" if isinstance(trades, list) and trades else "empty_or_unexpected"
    except Exception as error:
        result["trade_probe_rows"] = result["trade_probe_joined"] = 0
        result["trade_probe_status"] = "request_error: " + str(error)
    print("AUDIT", row["audit_group"], row["market_id"], result["price_1h_status"], result["price_24h_status"], result["trade_probe_status"], flush=True)
    return result


def write_report(run, summary, audit_counts):
    def table(selected):
        lines = ["| Group | Markets | Event IDs | 1h candidates | 24h candidates | 24h with explicit event time |",
                 "|---|---:|---:|---:|---:|---:|"]
        for label, row in selected:
            values = [row[k] for k in ["markets", "event_ids", "candidate_1h", "candidate_24h", "explicit_time_candidate_24h"]]
            lines.append("| " + label + " | " + " | ".join(f"{v:,}" for v in values) + " |")
        return "\n".join(lines)

    counts = summary["counts"]
    lookup = {(r["period"], r["topic"], r["subtype"]): r for r in counts}
    core = [("Sports: moneyline-type candidates", "Sports", "game_winner"),
            ("Politics: elections", "Politics", "elections"),
            ("Economics: macro/policy", "Economics", "macro_policy")]
    lines = ["# Market cohort audit - September 14, 2026", "",
        "## Scope and status", "",
        f"Inventory pagination complete: **{summary['inventory_complete']}**. Mentions are excluded from the current cohort and saved separately for possible later work.", "",
        "The 12-month discovery window is September 1, 2025 through August 31, 2026, selected using scheduled `endDate`. The six-month window is March 1 through August 31, 2026. These are scheduled-end windows, not claims about actual event or resolution dates. Sports discovery uses the `moneyline` type; Politics uses its topic tag; Economics is the union of `economy` and `economics` tags. No minimum volume is imposed.", "",
        "## Initial shortlist: 12 months", "",
        table([(label, lookup['12_months', topic, subtype]) for label, topic, subtype in core]), "",
        "## Initial shortlist: six months", "",
        table([(label, lookup['6_months', topic, subtype]) for label, topic, subtype in core]), "",
        "## Broader discovery pool: 12 months", "",
        table([(topic + (': moneyline type only' if topic == 'Sports' else ': excluding mentions'), lookup['12_months', topic, 'all']) for topic in ['Sports', 'Politics', 'Economics']]), "",
        "The API moneyline type can include tournament winner and placement contracts. These broad counts require a further match-level screen before defining an individual-game cohort.", "",
        "Topic memberships can overlap. Event IDs are Polymarket's grouping identifiers, not a verified count of statistically independent outcomes. The election and macro/policy labels are automated tag-based screens and still require review.", "",
        "## What a candidate means", "",
        "Candidates have an explicitly resolved binary outcome, join identifiers, and recorded listing and closure times consistent with being open at the indicated forecast cutoff. The anchor prefers gameStartTime, then event.startTime, then an explicitly marked endDate proxy. Conflicting explicit start times more than one hour apart fail the screen. A candidate flag does not establish full data coverage or validate the event time.", "",
        "The final column shows which 24-hour candidates have an explicit event-start field rather than an endDate proxy. Even explicit fields can be revised or incorrect. Economic release times and election cutoffs especially need source-calendar/rules review. Deadline contracts also need checks that the outcome was not already known before a forecast.", "",
        "## Historical data coverage audit", "",
        "Up to 30 markets from different event IDs were selected per group, spread across available months with deterministic hashed ordering. This is a feasibility check, not a statistically representative estimate of missingness or forecast accuracy.", "",
        "| Sample group | Tested | 1h price available | 24h price available / eligible | Trade rows returned | Explicit event-start field |",
        "|---|---:|---:|---:|---:|---:|"]
    for group, result in sorted(audit_counts.items()):
        eligible24 = result['tested'] - result['price_24h'].get('not_eligible', 0)
        lines.append(f"| {group.replace('_', ' ')} | {result['tested']} | {result['price_1h'].get('available', 0)} | {result['price_24h'].get('available', 0)} / {eligible24} | {result['trades'].get('rows_returned', 0)} | {result['explicit_event_time']} |")
    lines.extend(["", "Prices must be observed at or before the cutoff, after listing, and within one hour of the 1h target or six hours of the 24h target. A returned price at a provisional anchor is a retrievability result, not confirmation of a valid pre-event forecast. Trade probes request at most five records and check the market join; they do not verify lifetime coverage, pre-cutoff trade coverage, maker/taker roles, or wallet experience histories.", "",
        "## Implications for the project", "",
        "The inventory establishes a substantial candidate pool across the three topics. It does not yet establish the final number of fully usable modeling rows. Next, review subtype rules and event times, select a manageable sample across topic and time, verify its histories, and build features using only data available at each forecast cutoff. Keep related markets and repeated horizons grouped during evaluation. Preserve quieter markets and inspect the effects of coverage exclusions.", "",
        "## Files and reproducibility", "",
        "- [Market-level candidate inventory](candidate_inventory.csv)",
        "- [Counts by topic, subtype, period, and horizon](screen_counts.csv)",
        "- [Coverage audit results](coverage_audit.csv)",
        "- [Inventory completion and monthly counts](inventory_summary.json)",
        "- [Selection rules](selection.json)",
        "- [Capture layout and commands](../README.md)", "",
        "Public API responses are cached as compressed JSON with request URLs, retrieval times, and SHA-256 hashes. Politics and Economics use cursor pagination. Sports reuses completed legacy intervals and uses verified cursor filtering for fresh periods; every sports response is checked for the requested type. The original September 9 pilot and course website remain separate.", "",
        "API references: [market discovery](https://docs.polymarket.com/api-reference/markets/list-markets), [cursor pagination](https://docs.polymarket.com/api-reference/markets/list-markets-keyset-pagination), [historical prices](https://docs.polymarket.com/api-reference/markets/get-prices-history).", ""])
    (run / "report.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--audit", action="store_true")
    parser.add_argument("--audit-groups", nargs="+")
    args = parser.parse_args()
    inventory = json.loads((args.run / "inventory_summary.json").read_text())
    rows = []
    for topic, slugs in [("Sports", ["sports"]), ("Politics", ["politics"]), ("Economics", ["economy", "economics"])]:
        markets = {str(m["id"]): m for slug in slugs for m in read_markets(args.run, slug)}
        rows.extend(screen(m, topic) for m in markets.values())
    deferred = [r for r in rows if r["is_mention"]]
    rows = [r for r in rows if not r["is_mention"]]
    write_csv(args.run / "deferred_mentions.csv", deferred)
    write_csv(args.run / "candidate_inventory.csv", rows)
    counts = []
    for period, lower in [("12_months", "2025-09"), ("6_months", "2026-03")]:
        for topic in ("Sports", "Politics", "Economics"):
            for subtype in ["all"] + sorted({r["subtype"] for r in rows if r["topic"] == topic}):
                subset = [r for r in rows if r["topic"] == topic and r["end_date"][:7] >= lower and (subtype == "all" or r["subtype"] == subtype)]
                counts.append({"period": period, "topic": topic, "subtype": subtype,
                    "markets": len(subset), "event_ids": len({e for r in subset for e in r["event_ids"].split(";") if e}),
                    "resolved_binary": sum(r["binary_resolved"] for r in subset),
                    **{f"candidate_{h}h": sum(r[f"candidate_{h}h"] for r in subset) for h in (1, 24, 168)},
                    **{f"explicit_time_candidate_{h}h": sum(r[f"candidate_{h}h"] and r["anchor_source"] != "endDate_proxy" for r in subset) for h in (1, 24, 168)}})
    write_csv(args.run / "screen_counts.csv", counts)
    summary = {"inventory_complete": inventory["pagination_complete"], "counts": counts,
               "scope": "Mentions excluded from the current cohort per author direction; preserved separately for possible later work.",
               "deferred_mentions_by_topic": dict(Counter(r["topic"] for r in deferred)),
               "unique_market_ids": len({r["market_id"] for r in rows}),
               "topic_memberships": len(rows),
               "warning": "Candidates pass automated metadata rules only; endDate proxies and recorded event times need review. Full price/trade coverage is not established."}
    (args.run / "screen_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    for count in counts:
        if count["period"] == "12_months":
            print(json.dumps(count), flush=True)
    sample = select_sample(rows)
    (args.run / "audit_sample.json").write_text(json.dumps(sample, indent=2), encoding="utf-8")
    if args.audit:
        if args.audit_groups:
            sample = [row for row in sample if row["audit_group"] in args.audit_groups]
        results = []
        with ThreadPoolExecutor(max_workers=6) as pool:
            for result in pool.map(lambda row: audit_one(args.run, row), sample):
                results.append(result)
        write_csv(args.run / "coverage_audit.csv", results)
        audit_counts = {}
        for group in sorted({r["audit_group"] for r in results}):
            group_rows = [r for r in results if r["audit_group"] == group]
            audit_counts[group] = {"tested": len(group_rows),
                "explicit_event_time": sum(r["anchor_source"] != "endDate_proxy" for r in group_rows),
                "price_1h": dict(Counter(r["price_1h_status"] for r in group_rows)),
                "price_24h": dict(Counter(r["price_24h_status"] for r in group_rows)),
                "trades": dict(Counter(r["trade_probe_status"] for r in group_rows))}
        (args.run / "coverage_summary.json").write_text(json.dumps(audit_counts, indent=2), encoding="utf-8")
        print("COVERAGE", json.dumps(audit_counts), flush=True)
        write_report(args.run, summary, audit_counts)


if __name__ == "__main__":
    main()
