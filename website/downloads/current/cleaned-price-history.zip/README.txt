Current prepared price_history table: 75,061 rows. The CSV is unchanged from the current EDA output. data_dictionary.md defines its fields.
