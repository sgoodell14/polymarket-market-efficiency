"""Offline diagnostic of three deliberately selected repeated-row transactions.

This does not establish fill identity or modify the primary EDA tables.
"""
import csv
import gzip
import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "data/cohort_audit/20260914_sample200"
LEDGER = BASE / "eda_audit_20260916/duplicate_groups.csv"
OUTPUT = ROOT / "data/eda/20260916_repeat_followup/evidence.json"


def signature(row):
    return json.dumps(row, sort_keys=True, separators=(",", ":"))


def balance(rows):
    toward = away = Decimal(0)
    for row in rows:
        assert row["side"] in ("BUY", "SELL")
        assert row["outcomeIndex"] in (0, 1)
        size = Decimal(str(row["size"]))
        if (row["side"] == "BUY") == (row["outcomeIndex"] == 0):
            toward += size
        else:
            away += size
    return {"toward_outcome_0_shares": str(toward),
            "away_from_outcome_0_shares": str(away),
            "difference": str(toward - away)}


def main():
    with LEDGER.open(encoding="utf-8", newline="") as handle:
        groups = [r for r in csv.DictReader(handle) if r["kind"] == "exact_row"]
    cases = []
    for market_id in ("904439", "1628299", "906972"):
        candidates = [r for r in groups if r["market_id"] == market_id]
        group = (max(candidates, key=lambda r: int(r["rows"]))
                 if market_id == "906972" else candidates[0])
        path = BASE / group["source"]
        payload = path.read_bytes()
        rows = json.loads(gzip.decompress(payload))
        indices = json.loads(group["source_row_indices"])
        repeated = rows[indices[0]]
        assert all(rows[index] == repeated for index in indices)
        transaction = [r for r in rows
                       if r["transactionHash"] == repeated["transactionHash"]]
        distinct = list({signature(r): r for r in transaction}.values())
        raw_matches = []
        for raw_path in sorted(path.parent.glob("trades_*.json.gz")):
            if raw_path == path:
                continue
            raw_bytes = raw_path.read_bytes()
            raw = json.loads(gzip.decompress(raw_bytes))
            if not isinstance(raw, list):
                continue
            count = sum(r == repeated for r in raw)
            if count:
                raw_matches.append({"source": raw_path.relative_to(ROOT).as_posix(),
                                    "sha256": hashlib.sha256(raw_bytes).hexdigest(),
                                    "response_rows": len(raw), "matching_rows": count})
        cases.append({"market_id": market_id,
                      "source": path.relative_to(ROOT).as_posix(),
                      "sha256": hashlib.sha256(payload).hexdigest(),
                      "source_row_indices": indices,
                      "repeated_original_row": repeated,
                      "timestamp_utc": datetime.fromtimestamp(
                          repeated["timestamp"], timezone.utc).isoformat(),
                      "transaction_rows": len(transaction),
                      "distinct_complete_transaction_rows": len(distinct),
                      "retained_balance": balance(transaction),
                      "collapsed_balance": balance(distinct),
                      "raw_response_matches": raw_matches})
    result = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "selection": "Deliberate examples, not random or representative; first ledger group for 904439 and 1628299; largest for 906972.",
        "ledger": LEDGER.relative_to(ROOT).as_posix(),
        "ledger_sha256": hashlib.sha256(LEDGER.read_bytes()).hexdigest(),
        "exact_groups_in_ledger": len(groups),
        "excess_rows_in_ledger": sum(int(r["excess_rows"]) for r in groups),
        "balance_definition": "BUY outcome 0 or SELL outcome 1 versus BUY outcome 1 or SELL outcome 0, summing share sizes within each selected transaction.",
        "limitations": "No on-chain logs decoded. Balance supports but does not prove genuine fills. Raw parent/leaf responses overlap and must not be summed. Primary tables unchanged.",
        "cases": cases,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(),
                      "cases": [{k: c[k] for k in (
                          "market_id", "transaction_rows", "retained_balance",
                          "collapsed_balance", "raw_response_matches")} for c in cases]}, indent=2))


if __name__ == "__main__":
    main()
