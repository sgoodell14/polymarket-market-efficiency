"""Read-only audit of two-sided recording in the frozen v2 EDA trade data.

Balances account share quantities within market/transaction groups. This does
not identify execution logs, infer maker/taker roles, or calculate turnover.
"""
import csv
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/eda/20260916_v2"
OUT = ROOT / "data/eda/20260917_trade_sides"
ZERO = Decimal(0)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def direction(row):
    assert row["side"] in ("BUY", "SELL")
    assert row["outcomeIndex"] in (0, 1)
    return int((row["side"] == "BUY") == (row["outcomeIndex"] == 0))


def totals(rows):
    amounts = [ZERO, ZERO]
    for row in rows:
        amounts[direction(row)] += Decimal(row["size"])
    return amounts


def pair_pattern(rows):
    if len(rows) != 2:
        return "single_row" if len(rows) == 1 else "multiple_rows"
    a, b = rows
    if a["asset"] == b["asset"] and a["side"] != b["side"]:
        return "same_token_buy_sell"
    if a["outcomeIndex"] != b["outcomeIndex"] and a["side"] == b["side"]:
        return "opposite_tokens_" + a["side"].lower() + "_" + b["side"].lower()
    return "other_two_row_pattern"


def main():
    with (DATA / "markets.csv").open(encoding="utf-8", newline="") as f:
        markets = list(csv.DictReader(f))
    typed = defaultdict(dict)
    with gzip.open(DATA / "trades.csv.gz", "rt", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            idx = int(row["source_row_index"])
            assert idx not in typed[row["market_id"]]
            typed[row["market_id"]][idx] = row
    records, sources, examples = [], [], {}
    request_flags = Counter()
    status_counts, pattern_counts, topic_counts = Counter(), Counter(), defaultdict(Counter)
    row_counts, activity = Counter(), defaultdict(lambda: ZERO)
    tx_markets = defaultdict(set)
    repeats = Counter()
    pair_checks = Counter()
    total_activity = ZERO
    for market in markets:
        mid = market["market_id"]
        path = ROOT / market["source_trade_file"]
        digest = sha(path)
        rows = json.loads(gzip.decompress(path.read_bytes()), parse_float=Decimal)
        assert len(rows) == len(typed[mid]) == int(market["trade_row_count"])
        sources.append({"market_id": mid, "path": path.relative_to(ROOT).as_posix(),
                        "sha256": digest, "rows": len(rows)})
        groups = defaultdict(list)
        for idx, row in enumerate(rows):
            table = typed[mid][idx]
            assert digest == table["source_file_sha256"]
            assert table["source_file"] == path.relative_to(ROOT).as_posix()
            assert row["transactionHash"].lower() == table["transaction_hash"]
            assert row["proxyWallet"].lower() == table["wallet_address"]
            assert row["side"] == table["side"]
            assert str(row["asset"]) == table["token_id"]
            assert str(row["outcomeIndex"]) == table["outcome_index"]
            assert row["conditionId"].lower() == market["condition_id"].lower()
            assert float(row["price"]) == float(table["price"])
            assert float(row["size"]) == float(table["size"])
            assert int(row["timestamp"]) == int(table["timestamp_epoch_seconds"])
            assert Decimal(row["size"]) > 0
            assert 0 <= Decimal(row["price"]) <= 1
            groups[table["transaction_hash"]].append((idx, row, table["exact_signature_id"]))
        for req in sorted(path.parent.glob("trades_*.request.json")):
            request = json.loads(req.read_text(encoding="utf-8"))
            flag = parse_qs(urlparse(request.get("url", "")).query).get("takerOnly", ["absent"])[0]
            request_flags[flag] += 1
        for tx, indexed in groups.items():
            tx_markets[tx].add(mid)
            rs = [r for _, r, _ in indexed]
            distinct = list({sig: r for _, r, sig in indexed}.values())
            away, toward = totals(rs)
            diff = toward - away
            status = "exactly_balanced" if diff == 0 else (
                "both_directions_unbalanced" if min(toward, away) > 0 else "one_direction_only")
            pattern = pair_pattern(rs)
            notional = sum((Decimal(r["price"]) * Decimal(r["size"]) for r in rs), ZERO)
            unique_wallets = len({r["proxyWallet"].lower() for r in rs})
            times = {r["timestamp"] for r in rs}
            ca, ct = totals(distinct)
            repeat_excess = len(rs) - len(distinct)
            if repeat_excess:
                repeats["transaction_groups"] += 1
                repeats["excess_rows"] += repeat_excess
                repeats["retained_" + status] += 1
                repeats["collapsed_balanced" if ca == ct else "collapsed_unbalanced"] += 1
            price_pair_ok = None
            if len(rs) == 2:
                p0, p1 = (Decimal(r["price"]) for r in rs)
                residual = abs(p0-p1) if pattern == "same_token_buy_sell" else abs(p0+p1-1)
                price_pair_ok = residual <= Decimal("0.000001")
                pair_checks["two_row_groups"] += 1
                pair_checks["equal_sizes"] += rs[0]["size"] == rs[1]["size"]
                pair_checks["different_wallets"] += unique_wallets == 2
                pair_checks["same_timestamp"] += len(times) == 1
                pair_checks["price_consistent_with_pattern_to_1e-6"] += price_pair_ok
            record = {
                "market_id": mid, "topic": market["topic"], "transaction_hash": tx,
                "rows": len(rs), "wallets": unique_wallets, "timestamp_count": len(times),
                "pattern": pattern, "status": status,
                "toward_outcome_0_shares": str(toward), "away_from_outcome_0_shares": str(away),
                "share_difference": str(diff),
                "relative_share_difference": str(abs(diff) / max(toward, away)),
                "gross_account_activity": str(notional),
                "repeat_excess_rows": repeat_excess, "collapsed_share_difference": str(ct-ca),
                "source_file": path.relative_to(ROOT).as_posix(),
                "source_row_indices": json.dumps([idx for idx, _, _ in indexed]),
            }
            records.append(record)
            status_counts[status] += 1
            topic_counts[market["topic"]][status] += 1
            pattern_counts[pattern] += 1
            row_counts[status] += len(rs)
            activity[status] += notional
            total_activity += notional
            example_key = status if status != "exactly_balanced" else pattern
            if example_key not in examples:
                examples[example_key] = {**record, "question": market["question"],
                    "rows_detail": [{"source_row_index": idx, **{k: r[k] for k in (
                        "proxyWallet", "side", "outcomeIndex", "asset", "price", "size", "timestamp")}}
                        for idx, r, _ in indexed]}
    assert sum(row_counts.values()) == sum(len(v) for v in typed.values())
    unbalanced = sorted([r for r in records if r["status"] != "exactly_balanced"],
                        key=lambda r: abs(Decimal(r["share_difference"])), reverse=True)
    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "script_sha256": sha(Path(__file__)),
        "table_hashes": {name: sha(DATA / name) for name in ("markets.csv", "trades.csv.gz")},
        "method": "Exact decimal share sums from saved JSON numeric text, grouped by market ID and transaction hash. BUY 0 + SELL 1 versus BUY 1 + SELL 0. Every source row cross-checked against the typed trade table and its source hash/index.",
        "markets": len(markets), "markets_with_trades": sum(bool(typed[m["market_id"]]) for m in markets),
        "trade_rows": sum(row_counts.values()), "market_transaction_groups": len(records),
        "distinct_transaction_hashes": len(tx_markets),
        "hashes_spanning_markets": sum(len(mids)>1 for mids in tx_markets.values()),
        "request_taker_only_flags": dict(request_flags),
        "transaction_status_counts": dict(status_counts), "rows_by_status": dict(row_counts),
        "gross_activity_by_status": dict(activity), "total_gross_activity": total_activity,
        "transaction_patterns": dict(pattern_counts), "two_row_checks": dict(pair_checks),
        "topic_status_counts": dict(topic_counts), "repeat_sensitivity": dict(repeats),
        "groups_with_multiple_wallets": sum(r["wallets"] > 1 for r in records),
        "groups_with_one_timestamp": sum(r["timestamp_count"] == 1 for r in records),
        "unbalanced_absolute_difference_le_one_microshare": sum(abs(Decimal(r["share_difference"])) <= Decimal("0.000001") for r in unbalanced),
        "largest_unbalanced_groups": unbalanced[:10], "examples": examples,
        "limitations": "No execution log/order IDs in these API records; no on-chain reconciliation. Share balance supports two-sided representation but cannot certify every individual fill or full coverage. Price comparison uses a stated 1e-6 tolerance; share balance has zero tolerance. No data deduplication, role inference, turnover estimation, or data changes.",
        "official_sources": ["https://docs.polymarket.com/api-reference/core/get-trades-for-a-user-or-markets", "https://github.com/Polymarket/ctf-exchange-v2/blob/main/README.md"],
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str)+"\n", encoding="utf-8")
    (OUT / "sources.json").write_text(json.dumps(sources, indent=2)+"\n", encoding="utf-8")
    for name, group in (("transaction_groups.csv.gz", records), ("unbalanced_groups.csv.gz", unbalanced)):
        with gzip.open(OUT / name, "wt", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(records[0]))
            writer.writeheader()
            writer.writerows(group)
    print(json.dumps({k: v for k, v in summary.items() if k not in (
        "examples", "largest_unbalanced_groups", "official_sources", "table_hashes")}, indent=2, default=str))


if __name__ == "__main__":
    main()
