"""Activate the reviewed, in-window, one-contract-per-family cohort offline.

Preserve a hash-checked copy of every overwritten audit view. Family-overlap
removals are design changes, not new claims that the contracts were invalid.
"""
import hashlib
from collections import Counter
from datetime import datetime, timezone

from prepare_sampling_plan import ROOT, OUTPUT, write_csv
from replace_event_family_overlaps import RUN, read, load, dump


def main():
    marker = RUN / 'applied.json'
    if marker.exists():
        from cohort_state import validate_membership
        validate_membership(read(OUTPUT / 'active_candidates.csv'))
        print('Family replacement cohort already active; no membership rewritten.')
        return
    selected = load(RUN / 'selected_candidates.json')
    checks = read(RUN / 'validation_results.csv')
    retained = read(RUN / 'retained_candidates.csv')
    incoming = {r['market_id'] for r in selected}
    kept = {r['market_id'] for r in retained}
    assert incoming == {r['market_id'] for r in checks}
    assert all(r['status'] == 'checks_passed' for r in checks)
    assert not kept & incoming
    # Fail on concurrent changes to the audited baseline.
    for item in load(RUN / 'baseline.json')['files']:
        assert hashlib.sha256((ROOT / item['source']).read_bytes()).hexdigest() == item['sha256'], item['source']
    audit = OUTPUT / 'full_audit_20260915'
    prior_specs = load(audit / 'market_decisions.json')
    prior_inputs = {r['market_id']: r for t in ('sports', 'politics', 'economics')
                    for r in load(audit / (t + '_review_inputs.json'))}
    specs = {mid: prior_specs[mid] for mid in kept}
    specs.update(load(RUN / 'market_decisions.json'))
    assert set(specs) == kept | incoming
    captures = load(RUN / 'collection_results.json')
    for row in selected:
        mid = row['market_id']
        assert captures[mid]['applied']
        assert '2025-09-01' <= specs[mid]['anchor'] < '2026-09-01'
    rows = retained + [{k: v for k, v in r.items() if k != 'rules'} for r in selected]
    assert len(rows) == len({r['market_id'] for r in rows}) == 565
    assert len({specs[r['market_id']]['event_family_id'] for r in rows}) == len(rows)
    assert Counter(r['topic'] for r in rows) == {'Sports': 200, 'Politics': 200, 'Economics': 165}
    for row in rows:
        row['validation_status'] = 'checks_passed'
        row['event_family_id'] = specs[row['market_id']]['event_family_id']
        # Original probabilities remain provenance, never final inclusion weights.
        row['final_inclusion_probability_known'] = False
    paths = [p for folder in (OUTPUT, audit, OUTPUT / 'followup_20260915')
             for p in folder.iterdir() if p.is_file() and p.suffix in ('.json', '.csv', '.md')]
    paths += [OUTPUT / 'corrections/active_corrections.json', ROOT / 'docs/approved_cohort_decisions.json']
    snapshot = RUN / 'activation_snapshot'
    assert not (snapshot / 'manifest.json').exists(), 'Inspect partial activation after completed snapshot before retrying.'
    hashes, snapshot_files = {}, {}
    # Flat filenames avoid Windows' legacy path-length limit. A partial backup
    # can resume only while every baseline source still matches (checked above).
    snapshot.mkdir(exist_ok=True)
    for i, path in enumerate(paths):
        relative = path.relative_to(ROOT)
        target = snapshot / (f'{i:03d}_' + path.name)
        body = path.read_bytes()
        target.write_bytes(body)
        hashes[relative.as_posix()] = hashlib.sha256(body).hexdigest()
        snapshot_files[relative.as_posix()] = target.name
    dump(snapshot / 'manifest.json', dict(sha256=hashes, snapshot_files=snapshot_files))
    old_membership = load(OUTPUT / 'cohort_membership.json')
    removed = [r for r in read(RUN / 'family_selection.csv') if r['disposition'] != 'retain']
    manifest = dict(version='family_unique_20260916', original_count=600, prior_active_count=589,
        active_count=len(rows), active_market_ids=[r['market_id'] for r in rows],
        topic_counts=dict(Counter(r['topic'] for r in rows)), one_contract_per_event_family=True,
        event_window_start='2025-09-01', event_window_end_exclusive='2026-09-01',
        omitted_market_ids=old_membership['omitted_market_ids'],
        historical_omission_note='Original eleven omitted identities remain excluded; vacant slots were eligible for the later family replacement search.',
        family_overlap_removed_ids=[r['market_id'] for r in removed],
        replacement_ids=sorted(incoming), unfilled_topic_slots={'Economics': 35},
        replacement_policy='Saved topic/month reserve order, then nearest month, earlier month tie, original rank; original date range only.',
        exhaustion_scope='No further eligible candidates remained in the screened Economics reserve pool; not a census of every Polymarket listing.',
        decision_record=(RUN / 'applied.json').relative_to(ROOT).as_posix())
    index = load(OUTPUT / 'corrections/active_corrections.json')
    index = {mid: capture for mid, capture in index.items() if mid in kept}
    index.update({mid: captures[mid]['capture'] for mid in incoming})
    approvals = load(ROOT / 'docs/approved_cohort_decisions.json')
    approvals['family_unique_adoption'] = dict(membership_manifest='data/cohort_audit/20260914_sample200/cohort_membership.json',
        active_count=565, retained=496, removed_overlapping_contracts=93, replacements=69,
        topic_counts=manifest['topic_counts'], date_extension=False,
        reason='User requested replacing shared event families, checking available in-window reserves, and accepting a smaller topic sample when exhausted.')
    assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest for name, digest in hashes.items())
    dump(OUTPUT / 'cohort_membership.json', manifest)
    dump(audit / 'market_decisions.json', specs)
    dump(OUTPUT / 'corrections/active_corrections.json', index)
    dump(ROOT / 'docs/approved_cohort_decisions.json', approvals)
    all_inputs = {mid: prior_inputs[mid] for mid in kept}
    all_inputs.update({r['market_id']: r for r in selected})
    for topic in ('Sports', 'Politics', 'Economics'):
        dump(audit / (topic.lower() + '_review_inputs.json'), [all_inputs[r['market_id']] for r in rows if r['topic'] == topic])
    write_csv(OUTPUT / 'active_candidates.csv', rows)
    # A pilot flag records collection history, not a fresh balanced 20/topic draw.
    pilot = [r for r in rows if str(r['collection_pilot']).lower() == 'true']
    write_csv(OUTPUT / 'active_pilot_candidates.csv', pilot)
    write_csv(RUN / 'family_overlap_removals.csv', removed)
    write_csv(RUN / 'activated_candidates.csv', rows)
    from refresh_full_audit import main as refresh
    refresh()
    register = read(audit / 'cohort_audit_register.csv')
    assert len(register) == 565 and all(r['audit_status'] == 'checks_passed' for r in register)
    assert len({r['event_family_id'] for r in register}) == 565
    assert all(load(audit / 'market_decisions.json')[mid] == prior_specs[mid] for mid in kept)
    dump(marker, dict(applied_at_utc=datetime.now(timezone.utc).isoformat(), active_count=565,
        topic_counts=manifest['topic_counts'], retained=496, removed_family_overlaps=93,
        validated_replacements=69, distinct_families=565, original_window_preserved=True,
        historical_pilot_flags_retained=len(pilot), membership_changed=True,
        snapshot='activation_snapshot/manifest.json', modeling_ready=False))
    print('Activated 565 checked forecasts from 565 distinct event families.')


if __name__ == '__main__':
    main()
