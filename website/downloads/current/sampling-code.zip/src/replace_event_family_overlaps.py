"""Prepare a reproducible family-unique replacement batch without activating it.

The frozen 589-market checkpoint stays intact until replacement evidence and
collection pass. Selection never reads prices, volume, or settlement outcomes.
"""
import csv
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from prepare_sampling_plan import OUTPUT, ROOT, SEED, hashed, write_csv
from select_replacements import replacement_order

RUN = OUTPUT / 'family_replacements_20260916'
TOPICS = ('Sports', 'Politics', 'Economics')


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def family_selection(active, register):
    groups = defaultdict(list)
    for row in active:
        family = register[row['market_id']]['event_family_id']
        if not family:
            raise ValueError('Missing reviewed family: ' + row['market_id'])
        groups[family].append(row)
    winners = {}
    for family, members in groups.items():
        if len({r['topic'] for r in members}) != 1:
            raise ValueError('Cross-topic family requires an explicit topic decision: ' + family)
        winners[family] = min(members, key=lambda r: (hashed('contract:' + r['market_id']), r['market_id']))['market_id']
    retained, removed, ledger = [], [], []
    for row in active:
        family = register[row['market_id']]['event_family_id']
        keep = row['market_id'] == winners[family]
        (retained if keep else removed).append(dict(row, event_family_id=family))
        ledger.append(dict(market_id=row['market_id'], topic=row['topic'], question=row['question'],
                           event_family_id=family, family_size=len(groups[family]),
                           representative_market_id=winners[family],
                           selection_hash=hashed('contract:' + row['market_id']),
                           disposition='retain' if keep else 'replace_family_overlap'))
    return retained, removed, ledger


def initialize():
    if (RUN / 'applied.json').exists():
        raise RuntimeError('This selection batch is already activated. Use report_family_replacements.py to refresh its report; do not overwrite the frozen allocation.')
    RUN.mkdir(parents=True, exist_ok=True)
    before = RUN / 'before'
    before.mkdir(exist_ok=True)
    manifest_path = RUN / 'baseline.json'
    if manifest_path.exists():
        for item in load(manifest_path)['files']:
            if hashlib.sha256((before / item['snapshot']).read_bytes()).hexdigest() != item['sha256']:
                raise ValueError('Frozen input changed: ' + item['snapshot'])
        return
    sources = {
        'active_candidates.csv': OUTPUT / 'active_candidates.csv',
        'cohort_audit_register.csv': OUTPUT / 'full_audit_20260915/cohort_audit_register.csv',
        'cohort_membership.json': OUTPUT / 'cohort_membership.json',
        'reserve_candidates.csv': OUTPUT / 'reserve_candidates.csv',
        'omissions.csv': OUTPUT / 'adopt105_20260916/omissions.csv',
        'pre_omission_candidates.csv': OUTPUT / 'adopt105_20260916/before/00_active_candidates.csv',
        'approved_cohort_decisions.json': ROOT / 'docs/approved_cohort_decisions.json',
        'family_reconciliation.json': OUTPUT / 'full_audit_20260915/family_reconciliation.json',
    }
    # Locate the numbered archival roster by its original filename, not its index.
    sources['pre_omission_candidates.csv'] = next((OUTPUT / 'adopt105_20260916/before').glob('*_active_candidates.csv'))
    for batch in ('followup_20260915', 'replacements_10_20260915', 'replacements_12_20260915'):
        for name in ('reserve_rules.json', 'reserve_reviews.json', 'effective_reviews.json'):
            path = OUTPUT / batch / name
            if path.exists():
                sources[batch + '__' + name] = path
    files = []
    for name, source in sources.items():
        body = source.read_bytes()
        (before / name).write_bytes(body)
        files.append(dict(source=source.relative_to(ROOT).as_posix(), snapshot=name,
                          sha256=hashlib.sha256(body).hexdigest()))
    dump(manifest_path, dict(created_at_utc=datetime.now(timezone.utc).isoformat(), files=files,
                            authorization='User requested replacement of family overlaps and restoration of 200 per topic.',
                            target_per_topic=200, seed=SEED,
                            representative_rule='Minimum SHA256(seed + :contract: + market_id) among currently audited members of each family.',
                            prior_11_omissions='Remain excluded; their vacancies are now eligible for replacement.',
                            active_membership_changed=False))


def inherited_evidence(before, register):
    rules, reviews = {}, {}
    for batch in ('followup_20260915', 'replacements_10_20260915', 'replacements_12_20260915'):
        path = before / (batch + '__reserve_rules.json')
        rules.update({r['market_id']: r for r in load(path)})
        for name in ('reserve_reviews.json', 'effective_reviews.json'):
            path = before / (batch + '__' + name)
            if path.exists():
                reviews.update({mid: dict(rv, inherited_from=path.relative_to(ROOT).as_posix()) for mid, rv in load(path).items()})
    mapping = {r['market_id']: r['family'] for r in load(before / 'family_reconciliation.json')}
    mapping.update({mid: r['event_family_id'] for mid, r in register.items()})
    for mid, rv in reviews.items():
        related = rv.get('related_selected_market_id')
        if related in mapping:
            rv['event_family_id'] = mapping[related]
        if mid in mapping:
            rv['event_family_id'] = mapping[mid]
        if mid in rules and rv['rules_sha256'] != hashlib.sha256(rules[mid]['rules'].encode()).hexdigest():
            raise ValueError('Inherited review does not match saved rules: ' + mid)
    overrides = RUN / 'review_decisions.json'
    if overrides.exists():
        reviews.update(load(overrides))
    inventory_rules = RUN / 'inventory_contract_rules.json'
    if inventory_rules.exists():
        for mid, item in load(inventory_rules).items():
            if mid not in rules:
                rules[mid] = item
    for path in (RUN / 'metadata').glob('*/market.json.gz'):
        import gzip
        metadata = json.loads(gzip.decompress(path.read_bytes()))
        mid = str(metadata['id'])
        if mid not in rules:
            rules[mid] = dict(market_id=mid, rules=metadata.get('description', ''), question=metadata.get('question', ''))
    notes_path = RUN / 'scope_review_notes.json'
    if notes_path.exists():
        for mid, note in load(notes_path).items():
            if mid not in rules:
                raise ValueError('Cannot record a scope review without saved full rules: ' + mid)
            reviews[mid] = dict(note, rules_sha256=hashlib.sha256(rules[mid]['rules'].encode()).hexdigest(),
                                inherited_from=notes_path.relative_to(ROOT).as_posix())
    return rules, reviews


def classify_reserves(reserves, retained, removed, approvals, omissions, rules, reviews):
    retained_ids = {r['market_id'] for r in retained}
    removed_ids = {r['market_id'] for r in removed}
    families = {r['event_family_id'] for r in retained}
    excluded = {str(r['market_id']) for r in approvals.get('exclusions', [])} | {r['market_id'] for r in omissions}
    records = []
    for row in reserves:
        mid = row['market_id']
        rv = reviews.get(mid, {})
        family = rv.get('event_family_id', '')
        if mid in retained_ids:
            status, reason = 'already_retained', 'Already represents a retained family.'
        elif mid in removed_ids:
            status, reason = 'family_overlap', 'Sibling of the retained representative; cannot re-enter.'
        elif mid in excluded:
            status, reason = 'prior_exclusion_or_omission', 'Prior exclusion/omission remains in force.'
        elif family and family in families:
            status, reason = 'family_overlap', 'Reviewed family already represented.'
        elif rv.get('status', '').startswith('skip'):
            status, reason = 'prior_review_rejection', rv['reason']
        elif rv.get('status') == 'scope_eligible_timing_pending' and family and mid in rules:
            status, reason = 'candidate_needs_full_validation', rv['reason']
        else:
            status, reason = 'needs_rules_and_family_review', 'No conclusive current review for a new family.'
        records.append(dict(row, reviewed_event_family_id=family, reserve_status=status, reserve_reason=reason,
                            review_source=rv.get('inherited_from', ''), rules_available=mid in rules))
    return records


def main():
    initialize()
    before = RUN / 'before'
    active = read(before / 'active_candidates.csv')
    register = {r['market_id']: r for r in read(before / 'cohort_audit_register.csv')}
    retained, removed, ledger = family_selection(active, register)
    omissions = read(before / 'omissions.csv')
    omitted_ids = {r['market_id'] for r in omissions}
    omitted_slots = [dict(r, vacancy_reason='prior_omission') for r in read(before / 'pre_omission_candidates.csv') if r['market_id'] in omitted_ids]
    if len(omitted_slots) != len(omissions):
        raise ValueError('An omitted slot is missing from the pre-omission roster')
    slots = [dict(r, vacancy_reason='family_overlap') for r in removed] + omitted_slots
    assert len(active) == 589 and len(retained) == 496 and len(slots) == 104
    assert all(sum(r['topic'] == topic for r in retained + slots) == 200 for topic in TOPICS)
    rules, reviews = inherited_evidence(before, register)
    reserves = classify_reserves(read(before / 'reserve_candidates.csv'), retained, removed,
                                 load(before / 'approved_cohort_decisions.json'), omissions, rules, reviews)
    by_id = {r['market_id']: r for r in reserves}
    allocated, selected, attempts, pending = set(), [], [], []
    allocated_families = set()
    # Never advance past an unreviewed candidate in a slot's saved order.
    for slot in slots:
        for row in replacement_order(reserves, slot['topic'], slot['sampling_month']):
            mid, status = row['market_id'], row['reserve_status']
            if mid in allocated:
                status = 'allocated_to_earlier_slot'
            elif row['reviewed_event_family_id'] and row['reviewed_event_family_id'] in allocated_families:
                status = 'family_allocated_to_earlier_slot'
            attempts.append(dict(slot_market_id=slot['market_id'], topic=slot['topic'],
                                 slot_month=slot['sampling_month'], candidate_market_id=mid,
                                 candidate_month=row['sampling_month'], original_random_rank=row['selection_rank'],
                                 decision=status, reason=row['reserve_reason']))
            if status == 'candidate_needs_full_validation':
                selected.append(dict(row, replaces_market_id=slot['market_id'],
                                     collection_pilot=slot['collection_pilot'],
                                     event_family_id=row['reviewed_event_family_id'],
                                     rules=rules[mid]['rules'],
                                     event_inclusion_probability='',
                                     inclusion_probability_note='Adaptive family-unique replacement; original draw probability does not apply.',
                                     validation_status='scope_reviewed_full_validation_pending'))
                allocated.add(mid)
                allocated_families.add(row['reviewed_event_family_id'])
                break
            if status == 'needs_rules_and_family_review':
                pending.append(dict(slot_market_id=slot['market_id'], topic=slot['topic'],
                                    candidate_market_id=mid, question=row['question'], status=status))
                break
        else:
            pending.append(dict(slot_market_id=slot['market_id'], topic=slot['topic'],
                                candidate_market_id='', status='saved_reserve_exhausted'))
    for filename, rows in [('family_selection.csv', ledger), ('retained_candidates.csv', retained),
                           ('replacement_slots.csv', slots), ('reserve_screen.csv', reserves),
                           ('selection_attempts.csv', attempts), ('pending_slots.csv', pending)]:
        write_csv(RUN / filename, rows)
    dump(RUN / 'saved_rules.json', rules)
    dump(RUN / 'inherited_reviews.json', reviews)
    dump(RUN / 'selected_candidates.json', selected)
    if selected:
        write_csv(RUN / 'selected_candidates.csv', [{k: v for k, v in row.items() if k != 'rules'} for row in selected])
    summary = dict(active_membership_changed=False, retained=len(retained), removed_family_overlaps=len(removed),
                   prior_omission_vacancies=len(omitted_slots), replacements_needed=len(slots),
                   retained_by_topic=dict(Counter(r['topic'] for r in retained)),
                   vacancies_by_topic=dict(Counter(r['topic'] for r in slots)),
                   reserve_status_by_topic={topic: dict(Counter(r['reserve_status'] for r in reserves if r['topic'] == topic)) for topic in TOPICS},
                   next_distinct_review_candidates=sorted({r['candidate_market_id'] for r in pending if r['candidate_market_id']}),
                   scope_selected=len(selected), selected_by_topic=dict(Counter(r['topic'] for r in selected)),
                   selected_pending_full_validation=[r['market_id'] for r in selected],
                   status='replacement_review_in_progress')
    dump(RUN / 'summary.json', summary)
    report = ['# Replacement of overlapping event families', '',
              '**Current direction:** use saved reserves within September 2025–August 2026. Do not extend backward. Add fully validated replacements where available and accept fewer than 200 in a topic if this screened reserve is exhausted. The user specifically requested testing the two remaining Economics candidates. The additional tag-missed inventory review is exploratory and does not silently expand the original sampling pool.', '',
              'Status: selection and evidence review in progress. The 589-market checkpoint is preserved and has not been overwritten.', '',
              'The user requested one contract per real-world event family and restoration of 200 per topic. The prior 11 omissions remain omitted; their vacancies can now be filled.', '',
              '| Topic | Audited family representatives | Vacancies to reach 200 |', '|---|---:|---:|']
    for topic in TOPICS:
        report.append(f"| {topic} | {summary['retained_by_topic'][topic]} | {summary['vacancies_by_topic'][topic]} |")
    report += ['', '## Reproducible choices', '',
               'Retain the existing family member with the lowest SHA-256 of `efficiency-200-v1:contract:<market_id>`. This reuses the original contract-ordering function and does not inspect outcomes, prices, activity, or accuracy. All other family members remain preserved as historical observations.', '',
               'Process overlapping slots in frozen roster order, followed by the prior omission slots in their frozen pre-omission order. Reuse the saved reserve order: same topic/month first, then nearest month, earlier month on ties, and original rank within that month. Stop a slot at its first unreviewed candidate. Do not accept a replacement until scope, family, participation, event boundary, outcome mapping and history checks pass.', '',
               '## Records', '',
               '- [Family representative selection](family_selection.csv)',
               '- [Vacant slots](replacement_slots.csv)',
               '- [Reserve screening](reserve_screen.csv)',
               '- [Attempt ledger](selection_attempts.csv)',
               '- [Pending slots](pending_slots.csv)',
               '- [Frozen source hashes and authorization](baseline.json)', '',
               f'{len(selected)} candidates are allocated after scope review; they are not accepted forecasts until full validation passes.', '',
               'The saved Economics reserve contains only two potential new families according to inherited reviews. Exhaustion describes this screened reserve pool, not every market on Polymarket. The August 2025 inventory was captured under earlier authorization but no earlier market is part of this selection.', '']
    (RUN / 'report.md').write_text('\n'.join(report), encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
