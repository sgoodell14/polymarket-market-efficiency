"""Validate and collect family replacements in isolation from the active cohort."""
import argparse
import gzip
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor

from full_audit_evidence import boundary
from prepare_sampling_plan import OUTPUT, write_csv
from refresh_full_audit import assess
from replace_event_family_overlaps import RUN, load, dump, read
from validate_replacement_windows import collect, validate_spec, timing_review


def specifications(rows):
    authored = load(RUN / 'boundary_reviews.json') if (RUN / 'boundary_reviews.json').exists() else {}
    specs = {}
    for mid, rv in authored.items():
        if mid not in rows:
            continue
        specs[mid] = boundary(rows, mid, rv['local_time'], rv['time_zone'], rv['event_family_id'],
                              rv['source_urls'], rv['evidence'], expected=rv['expected_final_outcome'],
                              boundary_type=rv['boundary_type'])
        # Keep the authored date stable so collection caches are reproducible.
        specs[mid]['reviewed_at_utc'] = rv['reviewed_at'] + 'T00:00:00+00:00'
        if 'time_precision' in rv:
            specs[mid]['time_precision'] = rv['time_precision']
    dump(RUN / 'market_decisions.json', specs)
    return specs


def report(rows, specs, results):
    audit = []
    retained_families = {r['event_family_id'] for r in read(RUN / 'retained_candidates.csv')}
    selected_families = set()
    for mid, row in rows.items():
        spec = specs.get(mid)
        result = results.get(mid, {})
        capture, metadata, folder = {}, {}, None
        if result.get('capture'):
            folder = OUTPUT / 'corrections' / result['capture'] / 'pilot_collection' / mid
            capture = load(folder / 'result.json')
            metadata = json.loads(gzip.decompress((folder / 'market.json.gz').read_bytes()))
        status, reasons = assess(row, spec, capture, metadata) if spec else ('evidence_hold', ['boundary_participation_outcome_review_pending'])
        family = spec['event_family_id'] if spec else row['event_family_id']
        if family in retained_families or family in selected_families:
            status, reasons = 'evidence_hold', reasons + ['family_already_represented']
        selected_families.add(family)
        if status == 'checks_passed':
            if metadata.get('description') != row['rules']:
                status, reasons = 'evidence_hold', ['current_rules_differ_from_reviewed_rules']
            for name, clock, count in [('trades_window', 'timestamp', 'trade_rows'), ('prices_window', 't', 'price_points')]:
                data = json.loads(gzip.decompress((folder / (name + '.json.gz')).read_bytes()))
                assert len(data) == capture[count], (mid, count)
                assert all(capture['window_start_timestamp'] <= x[clock] <= capture['cutoff_timestamp'] for x in data), (mid, name)
                if name == 'trades_window':
                    assert all(x['conditionId'] == row['condition_id'] for x in data), mid
            for request_path in folder.glob('*.request.json'):
                request = load(request_path)
                response_path = request_path.with_name(request_path.name.replace('.request.json', '.json.gz'))
                assert hashlib.sha256(gzip.decompress(response_path.read_bytes())).hexdigest() == request['sha256'], response_path
        audit.append(dict(market_id=mid, topic=row['topic'], question=row['question'],
                          replaces_market_id=row['replaces_market_id'], event_family_id=family,
                          status=status, reasons=';'.join(reasons),
                          reviewed_anchor_utc=spec['anchor'] if spec else '',
                          capture=result.get('capture', ''), trade_rows=capture.get('trade_rows', ''),
                          forecast_price_age_seconds=capture.get('forecast_price_age_seconds', ''),
                          source_urls=';'.join(spec['source_urls']) if spec else ''))
    write_csv(RUN / 'validation_results.csv', audit)
    summary = dict(selected=len(rows), fully_validated=sum(x['status'] == 'checks_passed' for x in audit),
                   validated_ids=[x['market_id'] for x in audit if x['status'] == 'checks_passed'],
                   active_membership_changed=(RUN / 'applied.json').exists())
    dump(RUN / 'validation_summary.json', summary)
    print(json.dumps(summary), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--collect', action='store_true')
    args = parser.parse_args()
    rows = {r['market_id']: r for r in load(RUN / 'selected_candidates.json')}
    specs = specifications(rows)
    results_path = RUN / 'collection_results.json'
    results = load(results_path) if results_path.exists() else {}
    if args.collect:
        jobs = []
        for mid, spec in specs.items():
            reasons = validate_spec(rows[mid], spec)
            supported, timing_reason = timing_review(spec)
            if reasons or not supported:
                print(json.dumps(dict(market_id=mid, held=reasons or [timing_reason])), flush=True)
                continue
            jobs.append((dict(rows[mid], event_family_id=spec['event_family_id']), spec))
        with ThreadPoolExecutor(max_workers=4) as pool:
            for result in pool.map(collect, jobs):
                results[result['market_id']] = result
                dump(results_path, results)
                print(json.dumps(result), flush=True)
    report(rows, specs, results)


if __name__ == '__main__':
    main()
