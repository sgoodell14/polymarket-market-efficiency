"""Select audited replacements in saved random order and collect their windows.

Selection uses topic, month distance, saved rank, and recorded eligibility only.
It never scores forecasts or re-shuffles until a desired candidate appears.
"""
import csv
import gzip
import json
from collections import Counter
from datetime import timedelta

from audit_cohort import stamp
from collect_sample_pilot import collect_one
from prepare_sampling_plan import OUTPUT, ROOT, active_candidates, write_csv


def read_csv(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def month_number(month):
    year, number = map(int, month.split("-"))
    return year * 12 + number


def replacement_order(reserves, topic, month):
    """Same month first, then nearest month; ties favor the earlier month."""
    target = month_number(month)
    return sorted((r for r in reserves if r["topic"] == topic), key=lambda r: (
        abs(month_number(r["sampling_month"]) - target), r["sampling_month"], int(r["selection_rank"])))


def choose(reserves, old, reviews):
    attempts = []
    for position, candidate in enumerate(replacement_order(reserves, old["topic"], old["sampling_month"]), 1):
        review = reviews.get(candidate["market_id"])
        if review is None:
            raise ValueError("Next random candidate needs review: " + candidate["market_id"])
        attempts.append(dict(excluded_market_id=old["market_id"], topic=old["topic"],
            attempt=position, candidate_market_id=candidate["market_id"], question=candidate["question"],
            original_slot_month=old["sampling_month"], candidate_month=candidate["sampling_month"],
            original_random_rank=candidate["selection_rank"], decision=review["status"],
            reason=review["reason"], detail=review["detail"],
            related_selected_market_id=review.get("related_selected_market_id", "")))
        if review["status"] == "accept":
            return dict(candidate), review, attempts
    raise ValueError("No eligible reserves for " + old["topic"])


def main():
    base = OUTPUT / "replacements"
    reviews = json.loads((base / "candidate_reviews.json").read_text(encoding="utf-8"))
    decision_path = ROOT / "docs/approved_cohort_decisions.json"
    decisions = json.loads(decision_path.read_text(encoding="utf-8"))
    original = read_csv(OUTPUT / "primary_candidates.csv")
    original_by_id = {r["market_id"]: r for r in original}
    reserves = read_csv(OUTPUT / "reserve_candidates.csv")
    queue = read_csv(OUTPUT / "validation_queue.csv")
    queue_by_id = {r["market_id"]: r for r in queue}
    index_path = OUTPUT / "corrections/active_corrections.json"
    index = json.loads(index_path.read_text(encoding="utf-8"))
    selected, attempts, replacements, review_rows = [], [], [], []
    # Replay established slots first, then newly approved exclusions.
    slots = [r["excluded_market_id"] for r in decisions.get("replacements", [])]
    slots.extend(r["market_id"] for r in decisions["exclusions"] if r["market_id"] not in slots)
    for old_id in slots:
        old = original_by_id[old_id]
        slot_path = base / ("candidate_reviews_" + old_id + ".json")
        slot_reviews = json.loads(slot_path.read_text(encoding="utf-8")) if slot_path.exists() else reviews
        row, review, log = choose(reserves, old, slot_reviews)
        attempts.extend(log)
        mid = row["market_id"]
        assert mid not in original_by_id
        assert review["event_family_id"] not in {r["event_family_id"] for r in queue if r["event_family_id"] and r["market_id"] != mid}
        # Resolution checks occur after selection and are not selection inputs.
        assert row["final_outcome"] == review["expected_final_outcome"]
        anchor = stamp(review["anchor"])
        cutoff = anchor - timedelta(hours=24)
        assert stamp(row["start_date"]) <= cutoff <= stamp(row["closed_time"])
        assert stamp("2025-09-01T00:00:00Z") <= anchor < stamp("2026-09-01T00:00:00Z")
        original_anchor = row["anchor"]
        row.update(anchor=anchor.isoformat(), anchor_source=review["boundary_type"],
                   replaces_market_id=old_id, cohort_role="replacement", collection_pilot=old["collection_pilot"],
                   event_family_id=review["event_family_id"], validation_status="topic_time_reviewed_history_collected_features_pending",
                   event_inclusion_probability="", inclusion_probability_note="Original draw probability does not apply to adaptive replacement.")
        root = OUTPUT / "corrections" / ("replacement_" + mid)
        result = collect_one(row, output_root=root)
        if result["price_status"] != "available" or result["trade_status"] != "api_window_exhausted":
            raise ValueError("Selected market has incomplete coverage; keep selection and resolve collection: " + mid)
        for name, field in [("prices_window", "t"), ("trades_window", "timestamp")]:
            items = json.loads(gzip.decompress((root / "pilot_collection" / mid / (name + ".json.gz")).read_bytes()))
            assert all(result["window_start_timestamp"] <= item[field] <= int(cutoff.timestamp()) for item in items)
        result.update(event_time_verified=True, boundary_type=review["boundary_type"],
                      event_family_id=review["event_family_id"], event_time_source_url=review["source_url"],
                      replaces_market_id=old_id, modeling_ready=False)
        (root / "pilot_collection" / mid / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        review_row = {key: "" for key in queue[0]}
        review_row.update(topic=row["topic"], market_id=mid, question=row["question"], event_ids=row["event_ids"],
            collection_pilot=old["collection_pilot"], provisional_anchor=original_anchor, anchor_source="endDate_proxy",
            market_metadata_url="https://gamma-api.polymarket.com/markets/" + mid,
            event_family_id=review["event_family_id"], reviewed_topic_subtype=review["reason"],
            verified_event_time_utc=review["anchor"], event_time_source_url=review["source_url"],
            review_status="replacement_topic_time_reviewed_history_collected",
            review_notes=review["source_evidence"] + " Replaces " + old_id + "; cutoff " + cutoff.isoformat() + ". Features/duplicate-fill review remains pending.")
        manifest = dict(market_id=mid, original_anchor_utc=original_anchor, corrected_anchor_utc=review["anchor"],
                        corrected_cutoff_utc=cutoff.isoformat(), boundary_type=review["boundary_type"],
                        event_family_id=review["event_family_id"], source_urls=[review["source_url"], review["result_source_url"]],
                        evidence=review["source_evidence"], evidence_type="official_event_source",
                        status="replacement_window_collected", replaces_market_id=old_id,
                        original_capture_preserved=True, validation_queue_update="pending_merge")
        (root / "correction.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        write_csv(root / "review_update.csv", [review_row])
        index[mid] = root.name
        review_rows.append(review_row)
        selected.append(row)
        replacements.append(dict(excluded_market_id=old_id, replacement_market_id=mid, topic=row["topic"],
            excluded_slot_month=old["sampling_month"], replacement_month=row["sampling_month"],
            original_random_rank=row["selection_rank"], attempts=len(log), anchor_utc=review["anchor"],
            cutoff_utc=cutoff.isoformat(), source_url=review["source_url"], status="selected_reviewed_collected"))
    assert len({r["market_id"] for r in selected}) == len(slots)
    write_csv(base / "selection_attempts.csv", attempts)
    write_csv(OUTPUT / "replacement_candidates.csv", selected)
    write_csv(base / "replacement_log.csv", replacements)
    decisions.update(replacements=replacements, replacement_status=str(len(slots)) + "_selected_reviewed_and_collected",
                     replacement_rule="Original saved random rank within topic/month; nearest month fallback, earlier month on ties; skip logged scope, prior-resolution, or related-family issues.")
    decision_path.write_text(json.dumps(decisions, indent=2), encoding="utf-8")
    index_path.write_text(json.dumps(index, indent=2), encoding="utf-8")
    for r in review_rows:
        queue_by_id[r["market_id"]] = r
    for replacement in replacements:
        excluded = queue_by_id[replacement["excluded_market_id"]]
        excluded["review_notes"] = excluded["review_notes"].replace("replacement pending.", "replacement " + replacement["replacement_market_id"] + " selected, reviewed, and collected.")
    write_csv(base / "review_updates.csv", review_rows)
    try:
        write_csv(OUTPUT / "validation_queue.csv", list(queue_by_id.values()))
        queue_status = "merged"
    except PermissionError:
        queue_status = "pending_merge_file_locked; see replacements/review_updates.csv"
    for row in selected:
        path = OUTPUT / "corrections" / index[row["market_id"]] / "correction.json"
        manifest = json.loads(path.read_text(encoding="utf-8"))
        manifest["validation_queue_update"] = queue_status
        path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    active = active_candidates(original)
    pilot = active_candidates(read_csv(OUTPUT / "pilot_candidates.csv"))
    assert Counter(r["topic"] for r in active) == {"Sports": 200, "Politics": 200, "Economics": 200}
    assert Counter(r["topic"] for r in pilot) == {"Sports": 20, "Politics": 20, "Economics": 20}
    write_csv(OUTPUT / "active_candidates.csv", active)
    write_csv(OUTPUT / "active_pilot_candidates.csv", pilot)
    coverage = []
    for row in pilot:
        root = OUTPUT / "corrections" / index[row["market_id"]] if row["market_id"] in index else OUTPUT
        path = root / "pilot_collection" / row["market_id"] / "result.json"
        coverage.append(dict(json.loads(path.read_text(encoding="utf-8")), capture_path=str(path.relative_to(OUTPUT))))
    write_csv(OUTPUT / "active_pilot_coverage.csv", coverage)
    exclusions = read_csv(OUTPUT / "exclusion_log.csv")
    for exclusion in exclusions:
        replacement = next(r for r in replacements if r["excluded_market_id"] == exclusion["market_id"])
        exclusion.update(replacement_market_id=replacement["replacement_market_id"], replacement_status=replacement["status"])
    write_csv(OUTPUT / "exclusion_log.csv", exclusions)
    summary_path = OUTPUT / "approved_review_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary.update(active_candidates=len(active), active_pilot=len(pilot), active_by_topic=dict(Counter(r["topic"] for r in active)),
                   approved_exclusions=[r["market_id"] for r in decisions["exclusions"]],
                   replacements_pending=0, replacements=replacements, replacement_validation_queue_update=queue_status,
                   active_correction_count=len(index))
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(dict(replacements=replacements, active_candidates=len(active), active_pilot=len(pilot),
                          attempts=len(attempts), skipped=len(attempts)-len(slots), queue_status=queue_status), indent=2))


if __name__ == "__main__":
    main()
