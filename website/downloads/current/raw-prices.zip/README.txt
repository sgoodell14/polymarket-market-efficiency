Current cohort: 565 contracts, one per real-world event family; 200 Sports, 200 Politics and 165 Economics.
hourly/<market_id>.json contains the collector-filtered hourly price window, using the original API fields (75,061 observations). finer_cutoff/ contains eight separate unchanged finer-query responses used to select cutoff forecasts. Keep these separate from the hourly path.
