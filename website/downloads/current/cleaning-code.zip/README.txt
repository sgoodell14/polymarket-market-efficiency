Current shared table and market-feature preparation code.
Run python src/prepare_analysis_data.py after extracting the complete shared bundle.

For all saved inputs and the Python environment, extract the existing
eda-notebook-and-data.zip download. Use Python 3.11 and requirements.txt.
Current source filenames match the repository. Historical human-reviewed
decisions remain saved inputs; these commands do not replay every review step.
The complete shared bundle runs offline without a local archive directory.
