"""Independent saved-table checks, including every trade/price row's source mapping."""
import gzip
import hashlib
import json
from datetime import datetime,timezone

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from eda_tables import DATA,ROOT,VERSION,load_table


def validate_market_features(indexed, trades, prices, require):
    """Independent pandas rollups; do not call the builder's feature functions."""
    prob = indexed.forecast_probability.astype(float)
    favorite = pd.Series(np.where(prob > .5, 0, 1), index=indexed.index).where(prob != .5)
    require("favorite_probability_calculation", np.allclose(indexed.favorite_probability.astype(float), np.maximum(prob, 1-prob)))
    require("favorite_index_and_ties", np.allclose(indexed.favorite_index.astype(float), favorite, equal_nan=True))
    keys = ["market_id", "wallet_address", "transaction_hash", "token_id", "side"]
    buys = trades.loc[trades.side.eq("BUY")].copy()
    buys["value"] = buys.price.astype(float) * buys["size"].astype(float)
    groups = buys.groupby(keys).agg(value=("value", "sum"), outcome=("outcome_index", "first")).reset_index()
    groups["median"] = groups.groupby("market_id").value.transform("median")
    large = groups.loc[groups["median"].gt(0) & groups.value.ge(5*groups["median"])].copy()
    large["favorite"] = large.market_id.map(favorite)
    expected = pd.DataFrame(index=indexed.index)
    expected["purchase_count"] = groups.groupby("market_id").size().reindex(indexed.index, fill_value=0)
    expected["median_purchase_value"] = groups.groupby("market_id").value.median()
    expected["large_threshold"] = 5 * expected.median_purchase_value
    expected["large_purchase_count"] = large.groupby("market_id").size().reindex(indexed.index, fill_value=0)
    expected["large_purchase_value"] = large.groupby("market_id").value.sum().reindex(indexed.index, fill_value=0)
    expected["large_favorite_purchase_value"] = (large.loc[large.outcome.eq(large.favorite)]
        .groupby("market_id").value.sum().reindex(indexed.index, fill_value=0).where(favorite.notna()))
    expected["large_purchase_favorite_share"] = expected.large_favorite_purchase_value.div(
        expected.large_purchase_value.where(expected.large_purchase_value.gt(0)))
    for name in expected:
        require(name+"_independent_rollup", np.allclose(indexed[name].astype(float), expected[name], equal_nan=True, rtol=1e-12, atol=1e-10))
    status = np.select([expected.purchase_count.eq(0), expected.median_purchase_value.le(0),
                        expected.large_purchase_count.eq(0), favorite.isna()],
                       ["no_purchases", "nonpositive_median", "no_qualifying_purchases", "no_cutoff_favorite"], default="available")
    require("purchase_status_independent_rollup", np.array_equal(indexed.large_purchase_status.to_numpy(), status))
    require("purchase_share_range", indexed.large_purchase_favorite_share.dropna().between(0, 1).all())
    histories = {mid: g.sort_values("observation_time_utc") for mid, g in prices.groupby("market_id")}
    rows = []
    for mid, m in indexed.iterrows():
        target = m.forecast_cutoff_utc - pd.Timedelta(hours=24)
        row = dict(market_id=mid, trend_anchor_target_24h=target, trend_anchor_observed_24h=pd.NaT,
                   trend_anchor_age_hours_24h=np.nan, trend_anchor_probability_24h=np.nan,
                   trend_observed_hours_24h=np.nan, favorite_change_pp_24h=np.nan, trend_status_24h="available")
        history = histories.get(mid)
        if m.window_start_utc > target:
            row["trend_status_24h"] = "history_shorter_than_horizon"
        elif history is None:
            row["trend_status_24h"] = "no_hourly_price_history"
        else:
            before = history.loc[history.observation_time_utc.le(target) & history.observation_time_utc.ge(m.window_start_utc)]
            if before.empty:
                row["trend_status_24h"] = "no_price_at_or_before_anchor"
            else:
                anchor = before.iloc[-1]
                age = (target-anchor.observation_time_utc).total_seconds()/3600
                row.update(trend_anchor_observed_24h=anchor.observation_time_utc, trend_anchor_age_hours_24h=age)
                if age > 6:
                    row["trend_status_24h"] = "anchor_older_than_tolerance"
                else:
                    row.update(trend_anchor_probability_24h=float(anchor.probability),
                               trend_observed_hours_24h=(m.forecast_observation_utc-anchor.observation_time_utc).total_seconds()/3600)
                    if m.forecast_probability == .5:
                        row["trend_status_24h"] = "no_cutoff_favorite"
                    else:
                        row["favorite_change_pp_24h"] = 100*(m.forecast_probability-anchor.probability)*(1 if m.forecast_probability>.5 else -1)
        rows.append(row)
    expected = pd.DataFrame(rows).set_index("market_id")
    for name in ("trend_anchor_target_24h", "trend_anchor_observed_24h"):
        actual = pd.to_datetime(indexed[name], utc=True)
        wanted = pd.to_datetime(expected[name], utc=True)
        require(name+"_independent_asof", (actual.eq(wanted) | (actual.isna() & wanted.isna())).all())
    for name in ("trend_anchor_age_hours_24h", "trend_anchor_probability_24h", "trend_observed_hours_24h", "favorite_change_pp_24h"):
        require(name+"_independent_asof", np.allclose(indexed[name].astype(float), expected[name], equal_nan=True))
    require("trend_status_independent_asof", np.array_equal(indexed.trend_status_24h.to_numpy(), expected.trend_status_24h.to_numpy()))
    valid = indexed.favorite_change_pp_24h.notna()
    require("trend_missingness_matches_status", np.array_equal(valid.to_numpy(), indexed.trend_status_24h.eq("available").to_numpy()))
    require("trend_actual_duration_bounds", indexed.loc[valid, "trend_observed_hours_24h"].between(18, 30).all())
    return dict(markets=len(indexed), favorite_available=int(favorite.notna().sum()),
                grouped_buy_purchases=int(indexed.purchase_count.sum()),
                qualifying_purchases=int(indexed.large_purchase_count.sum()),
                markets_with_large_purchases=int(indexed.large_purchase_count.gt(0).sum()),
                purchase_status_counts=indexed.large_purchase_status.value_counts().to_dict(),
                trend_status_counts=indexed.trend_status_24h.value_counts().to_dict())


def main():
    manifest=json.loads((DATA/"manifest.json").read_text(encoding="utf-8"))
    checks={}
    def require(name,condition):
        if not bool(condition):raise AssertionError(name)
        checks[name]=True
    for name,digest in manifest["audited_input_hashes"].items():
        require("audited_source_hashes_unchanged",hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest)
    for name,digest in manifest["output_sha256"].items():
        require("generated_output_hashes_match",hashlib.sha256((DATA/name).read_bytes()).hexdigest()==digest)
    if "column_definitions_source" in manifest:
        definitions = ROOT / manifest["column_definitions_source"]
        require("column_definitions_hash_matches", hashlib.sha256(definitions.read_bytes()).hexdigest() == manifest["column_definitions_sha256"])
        require("column_definitions_match_saved_schema", json.loads(definitions.read_text(encoding="utf-8")) == json.loads((DATA/"schema.json").read_text(encoding="utf-8")))
    m,t,p=(load_table(name) for name in ("markets","trades","price_history"))
    base=ROOT/'data/cohort_audit/20260914_sample200'
    membership=json.loads((base/'cohort_membership.json').read_text())
    audit_dir=base/('eda_audit_20260916' if VERSION.endswith('_v1') else 'eda_audit_20260916_v2')
    source_audit=json.loads((audit_dir/'summary.json').read_text())
    flags=source_audit['market_flags']
    option_counts=json.loads((base/('options_20260916' if VERSION.endswith('_v1') else 'options_20260916_v2')/'summary.json').read_text())['status_counts']
    require("row_counts",[len(m),len(t),len(p)]==[source_audit['markets'],source_audit['totals']['trades'],source_audit['totals']['hourly_prices']])
    require("approved_market_ids",set(m.market_id)==set(membership['active_market_ids']))
    if membership.get('one_contract_per_event_family'):
        require('one_contract_per_event_family',m.event_family_id.is_unique and (m.family_market_count==1).all())
    require("market_ids_unique",m.market_id.is_unique)
    require("trade_source_row_ids_unique",t.trade_row_id.is_unique)
    require("price_source_row_ids_unique",p.price_row_id.is_unique)
    require("approved_topic_counts",m.topic.value_counts().to_dict()==membership['topic_counts'])
    for name,frame in (("markets",m),("trades",t),("price_history",p)):
        schema=pq.read_schema(DATA/f"{name}.parquet")
        require(name+"_string_ids",str(schema.field("market_id").type)=="string")
        require(name+"_required_fields_nonnull",all(frame[field.name].notna().all() for field in schema if not field.nullable))
    indexed=m.set_index("market_id")
    for name,frame,timecol in (("trades",t,"trade_time_utc"),("price_history",p,"observation_time_utc")):
        joined=frame.merge(m[["market_id","window_start_utc","forecast_cutoff_utc","condition_id","outcome_0_token_id","outcome_1_token_id"]],
                           on="market_id",how="left",validate="many_to_one",suffixes=("","_market"))
        require(name+"_market_join",joined.window_start_utc.notna().all())
        require(name+"_time_bounds",((joined[timecol]>=joined.window_start_utc)&(joined[timecol]<=joined.forecast_cutoff_utc)).all())
        require(name+"_sorted_within_market",not ((frame.market_id==frame.market_id.shift())&(frame.timestamp_epoch_seconds.diff()<0)).any())
        if name=="trades":
            expected=joined.outcome_0_token_id.where(joined.outcome_index==0,joined.outcome_1_token_id)
            require("token_outcome_index_mapping",(joined.token_id==expected).all())
            require("trade_condition_mapping",(joined.condition_id==joined.condition_id_market).all())
        else:require("price_first_token_mapping",(joined.token_id==joined.outcome_0_token_id).all())
    require("trade_values_valid",np.isfinite(t.price.astype(float)).all() and t.price.between(0,1).all() and (t['size']>0).all())
    require("price_values_valid",np.isfinite(p.probability.astype(float)).all() and p.probability.between(0,1).all())
    require("notional_calculation",np.allclose(t.row_notional.astype(float),(t.price*t['size']).astype(float),rtol=1e-13,atol=1e-12))
    require("outcome_label_corrections",int(t.outcome_label_changed.sum())==source_audit['integrity_issue_counts'].get('trade_outcome_label_difference',0))
    require("duplicate_excess",int(t.duplicate_excess.sum())==source_audit['totals']['exact_duplicate_excess'])
    require("sensitivity_rows",int(t.in_exact_signature_sensitivity.sum())==len(t)-source_audit['totals']['exact_duplicate_excess'])
    require("duplicate_flags_consistent",((t.duplicate_excess==(t.duplicate_occurrence>1)) &
        (t.duplicate_candidate==(t.duplicate_group_size>1)) & (t.in_exact_signature_sensitivity==~t.duplicate_excess)).all())
    grouped=t.groupby("exact_signature_id",sort=False)
    require("duplicate_group_sizes",(grouped.size().astype("int64")==grouped.duplicate_group_size.first().astype("int64")).all())
    require("duplicate_occurrences",(grouped.duplicate_occurrence.min()==1).all() and (grouped.duplicate_occurrence.max()==grouped.size()).all())
    expected_direction=np.where((t.side=="BUY").to_numpy()==(t.outcome_index==0).to_numpy(),1,-1)
    require("semantic_trade_direction",np.array_equal(t.first_outcome_direction.to_numpy(),expected_direction))
    require("price_keys_unique",not p.duplicated(["market_id","token_id","timestamp_epoch_seconds"]).any())
    require("price_gap_calculation",np.allclose(p.elapsed_seconds_since_previous.astype(float),p.groupby("market_id").timestamp_epoch_seconds.diff().astype(float),equal_nan=True))
    require("price_change_calculation",np.allclose(p.observed_change_pp.astype(float),100*p.groupby("market_id").probability.diff().astype(float),equal_nan=True))
    feature_summary=None
    if manifest.get("preparation_revision") in ("20261006_forecast_price_features", "20261008_wallet_trade_size", "20261024_favorite_purchase_trend"):
        feature_columns={"forecast_certainty","price_movement_pp_per_hour","usable_price_intervals","price_movement_observed_hours"}
        require("forecast_price_feature_columns",feature_columns.issubset(m.columns))
        require("forecast_certainty_calculation",np.allclose(m.forecast_certainty.astype(float),2*(m.forecast_probability.astype(float)-.5).abs()))
        require("forecast_certainty_range",m.forecast_certainty.between(0,1).all())
        # Independently derive eligible changes from timestamps and probabilities.
        elapsed=p.groupby("market_id").timestamp_epoch_seconds.diff().astype(float)
        change=100*p.groupby("market_id").probability.diff().astype(float)
        eligible=elapsed.between(1800,5400)&change.notna()
        observed=p.loc[eligible,["market_id"]].assign(
            hours=elapsed[eligible]/3600,absolute_change=change[eligible].abs())
        expected=observed.groupby("market_id").agg(
            count=("hours","size"),hours=("hours","sum"),movement=("absolute_change","sum")
        ).reindex(indexed.index)
        expected_rate=expected.movement/expected.hours
        require("usable_price_interval_count",np.array_equal(indexed.usable_price_intervals.to_numpy(),expected["count"].fillna(0).to_numpy()))
        require("price_movement_observed_hours",np.allclose(indexed.price_movement_observed_hours.astype(float),expected.hours.fillna(0)))
        require("price_movement_independent_rollup",np.allclose(indexed.price_movement_pp_per_hour.astype(float),expected_rate,equal_nan=True))
        missing=indexed.usable_price_intervals==0
        require("price_movement_missingness",np.array_equal(indexed.price_movement_pp_per_hour.isna().to_numpy(),missing.to_numpy()))
        require("price_movement_zero_support",(indexed.loc[missing,"price_movement_observed_hours"]==0).all())
        require("price_movement_nonnegative",indexed.loc[~missing,"price_movement_pp_per_hour"].ge(0).all())
        market_schema=pq.read_schema(DATA/"markets.parquet")
        require("recorded_trading_activity_display_labels",all(
            market_schema.field(name).metadata.get(b"display_label",b"").decode()==label
            for name,label in (("gross_account_activity","Recorded trading activity ($)"),
                               ("account_activity_per_observed_day","Recorded trading activity ($/day)"))))
        trade_size = "mean_wallet_trade_notional" if "mean_wallet_trade_notional" in m.columns else "mean_trade_row_notional"
        numeric=["observed_wallet_count","account_activity_per_observed_day",trade_size,
                 "wallet_activity_hhi","forecast_certainty","price_movement_pp_per_hour"]
        complete=m[numeric].notna().all(axis=1)
        model_complete=complete&m.usable_price_intervals.ge(6)
        feature_summary=dict(
            certainty_available=int(m.forecast_certainty.notna().sum()),
            movement_available=int(m.price_movement_pp_per_hour.notna().sum()),
            movement_zero=int(m.price_movement_pp_per_hour.eq(0).sum()),
            no_usable_intervals=int(m.usable_price_intervals.eq(0).sum()),
            one_to_five_intervals=int(m.usable_price_intervals.between(1,5).sum()),
            at_least_six_intervals=int(m.usable_price_intervals.ge(6).sum()),
            six_features_complete=int(complete.sum()),
            six_features_with_six_intervals=int(model_complete.sum()),
            model_complete_by_topic=m.loc[model_complete,"topic"].value_counts().to_dict(),
            scope="Availability only; six-interval rule does not remove rows from saved tables.")
    if manifest.get("preparation_revision") in ("20261008_wallet_trade_size", "20261024_favorite_purchase_trend"):
        require("wallet_trade_fields_present", {"wallet_trade_count", "mean_wallet_trade_notional"}.issubset(m.columns))
        keys = ["market_id", "wallet_address", "transaction_hash", "token_id", "side"]
        require("wallet_trade_group_keys_complete", t[keys].notna().all().all())
        # Independent pandas rollup from price and size, not the builder helper.
        actions = t.assign(value=t.price.astype(float)*t["size"].astype(float)).groupby(keys).value.sum()
        counts = actions.groupby(level="market_id").size().reindex(indexed.index, fill_value=0)
        means = actions.groupby(level="market_id").mean().reindex(indexed.index)
        totals = actions.groupby(level="market_id").sum().reindex(indexed.index, fill_value=0)
        require("wallet_trade_counts_independent_rollup", np.array_equal(counts.to_numpy(), indexed.wallet_trade_count.to_numpy()))
        require("wallet_trade_means_independent_rollup", np.allclose(means, indexed.mean_wallet_trade_notional.astype(float), equal_nan=True))
        require("wallet_trade_activity_preserved", np.allclose(totals, indexed.gross_account_activity.astype(float)))
        require("wallet_trade_missingness", np.array_equal(indexed.mean_wallet_trade_notional.isna().to_numpy(), counts.eq(0).to_numpy()))
        require("wallet_trade_count_bounds", (indexed.wallet_trade_count.ge(indexed.transaction_count) & indexed.wallet_trade_count.le(indexed.trade_row_count)).all())
        require("wallet_trade_mean_nonnegative", indexed.mean_wallet_trade_notional.dropna().ge(0).all())
        require("wallet_trade_mean_not_less_than_record_mean", (indexed.mean_wallet_trade_notional.dropna().astype(float) + 1e-10 >= indexed.loc[indexed.mean_wallet_trade_notional.notna(), "mean_trade_row_notional"].astype(float)).all())
    predictor_summary = None
    if manifest.get("preparation_revision") == "20261024_favorite_purchase_trend":
        require("market_feature_parameters_recorded", manifest["market_feature_parameters"] ==
                {"large_purchase_multiple": 5.0, "trend_hours": 24, "max_anchor_age_hours": 6})
        feature_source = manifest.get("market_features_source", "src/market_features.py")
        require("market_feature_code_hash", manifest["market_features_sha256"] == hashlib.sha256((ROOT/feature_source).read_bytes()).hexdigest())
        predictor_summary = validate_market_features(indexed, t, p, require)
    require("forecast_price_freshness",m.forecast_age_seconds.between(0,21600).all())
    require("forecast_age_calculation",np.array_equal((m.forecast_cutoff_utc-m.forecast_observation_utc).dt.total_seconds().to_numpy(),m.forecast_age_seconds.to_numpy()))
    require("integer_second_cutoff_policy",m.cutoff_floor_difference_seconds.between(0,1,inclusive="left").all())
    require("zero_windows_preserved",int(m.zero_returned_trades.sum())==sum(x['zero_trade_markets'] for x in source_audit['topic_summary'].values()))
    require("short_windows_preserved",int(m.short_window.sum())==sum(x['short_windows'] for x in source_audit['topic_summary'].values()))
    require("fallback_snapshots_preserved",int((m.forecast_price_source=="one_minute_fallback").sum())==flags['cutoff_fallback'])
    require("no_hourly_path_preserved",int((m.price_point_count==0).sum())==source_audit['empty_hourly_histories'])
    zero=m.zero_returned_trades
    require("zero_is_not_missing_activity",(m.loc[zero,"gross_account_activity"]==0).all() and (m.loc[zero,"observed_wallet_count"]==0).all())
    require("undefined_concentration_is_missing",m.loc[zero,["top_wallet_activity_share","wallet_activity_hhi","mean_trade_row_size","duplicate_activity_difference_pct"]].isna().all().all())
    require("unavailable_paths_not_zero",m.loc[m.price_point_count==0,["max_price_gap_hours","max_observed_price_step_pp","flat_hourly_series"]].isna().all().all())
    require("historical_options_missingness",int(m.option_count_at_cutoff.isna().sum())==option_counts.get('historical_count_unverified',0)+option_counts.get('not_applicable_nonexclusive_bundle',0))
    require("lifetime_volume_missingness",int(m.reported_lifetime_volume.isna().sum())==flags['missing_reported_volume'])
    require("replacement_probability_missingness",int(m.event_inclusion_probability.isna().sum())==flags['missing_sampling_probability'])
    trade_counts=t.groupby("market_id").size().reindex(indexed.index,fill_value=0)
    price_counts=p.groupby("market_id").size().reindex(indexed.index,fill_value=0)
    require("trade_rollup_counts",np.array_equal(trade_counts.to_numpy(),indexed.trade_row_count.to_numpy()))
    require("price_rollup_counts",np.array_equal(price_counts.to_numpy(),indexed.price_point_count.to_numpy()))
    sums=t.groupby("market_id").row_notional.sum().reindex(indexed.index,fill_value=0)
    require("activity_rollup",np.allclose(sums.astype(float),indexed.gross_account_activity.astype(float),rtol=1e-12,atol=1e-10))
    wallet_sums=t.groupby(["market_id","wallet_address"]).row_notional.sum()
    shares=wallet_sums/wallet_sums.groupby(level=0).transform("sum")
    hhi=(shares*shares).groupby(level=0).sum()
    require("wallet_hhi_independent_rollup",np.allclose(hhi.astype(float),indexed.loc[hhi.index,"wallet_activity_hhi"].astype(float),rtol=1e-12))
    require("top_wallet_independent_rollup",np.allclose(shares.groupby(level=0).max().astype(float),indexed.loc[hhi.index,"top_wallet_activity_share"].astype(float),rtol=1e-12))
    # Check every transformed numerical observation and source index against raw arrays.
    tg={mid:g.sort_values("source_row_index") for mid,g in t.groupby("market_id",sort=False)}
    pg={mid:g.sort_values("source_row_index") for mid,g in p.groupby("market_id",sort=False)}
    for i,row in enumerate(m.itertuples(index=False),1):
        raw_t=json.loads(gzip.decompress((ROOT/row.source_trade_file).read_bytes()))
        raw_p=json.loads(gzip.decompress((ROOT/row.source_price_file).read_bytes()))
        if raw_t:
            g=tg[row.market_id]
            require("all_trade_rows_trace_to_source",g.source_row_index.tolist()==list(range(len(raw_t))))
            for output,source in (("price","price"),("size","size"),("timestamp_epoch_seconds","timestamp"),("token_id","asset"),("outcome_label_raw","outcome")):
                require("all_trade_values_preserved",g[output].tolist()==[r[source] for r in raw_t])
            keys=[hashlib.sha256((row.market_id+"|"+json.dumps(r,sort_keys=True,separators=(",",":"))).encode()).hexdigest() for r in raw_t]
            require("exact_signatures_match_original_rows",g.exact_signature_id.tolist()==keys)
        if raw_p:
            g=pg[row.market_id]
            require("all_price_rows_trace_to_source",g.source_row_index.tolist()==list(range(len(raw_p))))
            require("all_price_values_preserved",g.probability.tolist()==[r["p"] for r in raw_p] and g.timestamp_epoch_seconds.tolist()==[r["t"] for r in raw_p])
        if i%200==0 or i==len(m):print(f"Validated source rows for {i}/{len(m)} markets",flush=True)
    result=dict(validated_at_utc=datetime.now(timezone.utc).isoformat(),checks=checks,check_count=len(checks),
        row_counts=manifest["row_counts"],input_hashes_verified=len(manifest["audited_input_hashes"]),
        all_checks_pass=True,scope="saved data, derivations and provenance; not independent on-chain reconciliation")
    if feature_summary is not None:result["forecast_price_features"]=feature_summary
    if predictor_summary is not None:result["market_predictor_features"]=predictor_summary
    (DATA/"validation.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(f"PASS: {len(checks)} checks; all {len(m)} source histories reconciled.")


if __name__=="__main__":main()
