"""Independent saved-table checks, including every trade/price row's source mapping."""
import gzip
import hashlib
import json
from datetime import datetime,timezone

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from eda_tables import DATA,ROOT,VERSION,load_table


def main():
    manifest=json.loads((DATA/"manifest.json").read_text(encoding="utf-8"))
    checks={}
    def require(name,condition):
        if not bool(condition):raise AssertionError(name)
        checks[name]=True
    for name,digest in manifest["audited_input_hashes"].items():
        require("audited_source_hashes_unchanged",hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest)
    for name,digest in manifest["output_sha256"].items():
        require("generated_output_hashes_match",hashlib.sha256((DATA/name).read_bytes()).hexdigest()==digest)
    m,t,p=(load_table(name) for name in ("markets","trades","price_history"))
    base=ROOT/'data/cohort_audit/20260914_sample200'
    membership=json.loads((base/'cohort_membership.json').read_text())
    audit_dir=base/('eda_audit_20260916' if VERSION.endswith('_v1') else 'eda_audit_20260916_v2')
    source_audit=json.loads((audit_dir/'summary.json').read_text())
    flags=source_audit['market_flags']
    option_counts=json.loads((base/('options_20260916' if VERSION.endswith('_v1') else 'options_20260916_v2')/'summary.json').read_text())['status_counts']
    require("row_counts",[len(m),len(t),len(p)]==[source_audit['markets'],source_audit['totals']['trades'],source_audit['totals']['hourly_prices']])
    require("approved_market_ids",set(m.market_id)==set(membership['active_market_ids']))
    if membership.get('one_contract_per_event_family'):
        require('one_contract_per_event_family',m.event_family_id.is_unique and (m.family_market_count==1).all())
    require("market_ids_unique",m.market_id.is_unique)
    require("trade_source_row_ids_unique",t.trade_row_id.is_unique)
    require("price_source_row_ids_unique",p.price_row_id.is_unique)
    require("approved_topic_counts",m.topic.value_counts().to_dict()==membership['topic_counts'])
    for name,frame in (("markets",m),("trades",t),("price_history",p)):
        schema=pq.read_schema(DATA/f"{name}.parquet")
        require(name+"_string_ids",str(schema.field("market_id").type)=="string")
        require(name+"_required_fields_nonnull",all(frame[field.name].notna().all() for field in schema if not field.nullable))
    indexed=m.set_index("market_id")
    for name,frame,timecol in (("trades",t,"trade_time_utc"),("price_history",p,"observation_time_utc")):
        joined=frame.merge(m[["market_id","window_start_utc","forecast_cutoff_utc","condition_id","outcome_0_token_id","outcome_1_token_id"]],
                           on="market_id",how="left",validate="many_to_one",suffixes=("","_market"))
        require(name+"_market_join",joined.window_start_utc.notna().all())
        require(name+"_time_bounds",((joined[timecol]>=joined.window_start_utc)&(joined[timecol]<=joined.forecast_cutoff_utc)).all())
        require(name+"_sorted_within_market",not ((frame.market_id==frame.market_id.shift())&(frame.timestamp_epoch_seconds.diff()<0)).any())
        if name=="trades":
            expected=joined.outcome_0_token_id.where(joined.outcome_index==0,joined.outcome_1_token_id)
            require("token_outcome_index_mapping",(joined.token_id==expected).all())
            require("trade_condition_mapping",(joined.condition_id==joined.condition_id_market).all())
        else:require("price_first_token_mapping",(joined.token_id==joined.outcome_0_token_id).all())
    require("trade_values_valid",np.isfinite(t.price.astype(float)).all() and t.price.between(0,1).all() and (t['size']>0).all())
    require("price_values_valid",np.isfinite(p.probability.astype(float)).all() and p.probability.between(0,1).all())
    require("notional_calculation",np.allclose(t.row_notional.astype(float),(t.price*t['size']).astype(float),rtol=1e-13,atol=1e-12))
    require("outcome_label_corrections",int(t.outcome_label_changed.sum())==source_audit['integrity_issue_counts'].get('trade_outcome_label_difference',0))
    require("duplicate_excess",int(t.duplicate_excess.sum())==source_audit['totals']['exact_duplicate_excess'])
    require("sensitivity_rows",int(t.in_exact_signature_sensitivity.sum())==len(t)-source_audit['totals']['exact_duplicate_excess'])
    require("duplicate_flags_consistent",((t.duplicate_excess==(t.duplicate_occurrence>1)) &
        (t.duplicate_candidate==(t.duplicate_group_size>1)) & (t.in_exact_signature_sensitivity==~t.duplicate_excess)).all())
    grouped=t.groupby("exact_signature_id",sort=False)
    require("duplicate_group_sizes",(grouped.size().astype("int64")==grouped.duplicate_group_size.first().astype("int64")).all())
    require("duplicate_occurrences",(grouped.duplicate_occurrence.min()==1).all() and (grouped.duplicate_occurrence.max()==grouped.size()).all())
    expected_direction=np.where((t.side=="BUY").to_numpy()==(t.outcome_index==0).to_numpy(),1,-1)
    require("semantic_trade_direction",np.array_equal(t.first_outcome_direction.to_numpy(),expected_direction))
    require("price_keys_unique",not p.duplicated(["market_id","token_id","timestamp_epoch_seconds"]).any())
    require("price_gap_calculation",np.allclose(p.elapsed_seconds_since_previous.astype(float),p.groupby("market_id").timestamp_epoch_seconds.diff().astype(float),equal_nan=True))
    require("price_change_calculation",np.allclose(p.observed_change_pp.astype(float),100*p.groupby("market_id").probability.diff().astype(float),equal_nan=True))
    require("forecast_price_freshness",m.forecast_age_seconds.between(0,21600).all())
    require("forecast_age_calculation",np.array_equal((m.forecast_cutoff_utc-m.forecast_observation_utc).dt.total_seconds().to_numpy(),m.forecast_age_seconds.to_numpy()))
    require("integer_second_cutoff_policy",m.cutoff_floor_difference_seconds.between(0,1,inclusive="left").all())
    require("zero_windows_preserved",int(m.zero_returned_trades.sum())==sum(x['zero_trade_markets'] for x in source_audit['topic_summary'].values()))
    require("short_windows_preserved",int(m.short_window.sum())==sum(x['short_windows'] for x in source_audit['topic_summary'].values()))
    require("fallback_snapshots_preserved",int((m.forecast_price_source=="one_minute_fallback").sum())==flags['cutoff_fallback'])
    require("no_hourly_path_preserved",int((m.price_point_count==0).sum())==source_audit['empty_hourly_histories'])
    zero=m.zero_returned_trades
    require("zero_is_not_missing_activity",(m.loc[zero,"gross_account_activity"]==0).all() and (m.loc[zero,"observed_wallet_count"]==0).all())
    require("undefined_concentration_is_missing",m.loc[zero,["top_wallet_activity_share","wallet_activity_hhi","mean_trade_row_size","duplicate_activity_difference_pct"]].isna().all().all())
    require("unavailable_paths_not_zero",m.loc[m.price_point_count==0,["max_price_gap_hours","max_observed_price_step_pp","flat_hourly_series"]].isna().all().all())
    require("historical_options_missingness",int(m.option_count_at_cutoff.isna().sum())==option_counts.get('historical_count_unverified',0)+option_counts.get('not_applicable_nonexclusive_bundle',0))
    require("lifetime_volume_missingness",int(m.reported_lifetime_volume.isna().sum())==flags['missing_reported_volume'])
    require("replacement_probability_missingness",int(m.event_inclusion_probability.isna().sum())==flags['missing_sampling_probability'])
    trade_counts=t.groupby("market_id").size().reindex(indexed.index,fill_value=0)
    price_counts=p.groupby("market_id").size().reindex(indexed.index,fill_value=0)
    require("trade_rollup_counts",np.array_equal(trade_counts.to_numpy(),indexed.trade_row_count.to_numpy()))
    require("price_rollup_counts",np.array_equal(price_counts.to_numpy(),indexed.price_point_count.to_numpy()))
    sums=t.groupby("market_id").row_notional.sum().reindex(indexed.index,fill_value=0)
    require("activity_rollup",np.allclose(sums.astype(float),indexed.gross_account_activity.astype(float),rtol=1e-12,atol=1e-10))
    wallet_sums=t.groupby(["market_id","wallet_address"]).row_notional.sum()
    shares=wallet_sums/wallet_sums.groupby(level=0).transform("sum")
    hhi=(shares*shares).groupby(level=0).sum()
    require("wallet_hhi_independent_rollup",np.allclose(hhi.astype(float),indexed.loc[hhi.index,"wallet_activity_hhi"].astype(float),rtol=1e-12))
    require("top_wallet_independent_rollup",np.allclose(shares.groupby(level=0).max().astype(float),indexed.loc[hhi.index,"top_wallet_activity_share"].astype(float),rtol=1e-12))
    # Check every transformed numerical observation and source index against raw arrays.
    tg={mid:g.sort_values("source_row_index") for mid,g in t.groupby("market_id",sort=False)}
    pg={mid:g.sort_values("source_row_index") for mid,g in p.groupby("market_id",sort=False)}
    for i,row in enumerate(m.itertuples(index=False),1):
        raw_t=json.loads(gzip.decompress((ROOT/row.source_trade_file).read_bytes()))
        raw_p=json.loads(gzip.decompress((ROOT/row.source_price_file).read_bytes()))
        if raw_t:
            g=tg[row.market_id]
            require("all_trade_rows_trace_to_source",g.source_row_index.tolist()==list(range(len(raw_t))))
            for output,source in (("price","price"),("size","size"),("timestamp_epoch_seconds","timestamp"),("token_id","asset"),("outcome_label_raw","outcome")):
                require("all_trade_values_preserved",g[output].tolist()==[r[source] for r in raw_t])
            keys=[hashlib.sha256((row.market_id+"|"+json.dumps(r,sort_keys=True,separators=(",",":"))).encode()).hexdigest() for r in raw_t]
            require("exact_signatures_match_original_rows",g.exact_signature_id.tolist()==keys)
        if raw_p:
            g=pg[row.market_id]
            require("all_price_rows_trace_to_source",g.source_row_index.tolist()==list(range(len(raw_p))))
            require("all_price_values_preserved",g.probability.tolist()==[r["p"] for r in raw_p] and g.timestamp_epoch_seconds.tolist()==[r["t"] for r in raw_p])
        if i%200==0 or i==len(m):print(f"Validated source rows for {i}/{len(m)} markets",flush=True)
    result=dict(validated_at_utc=datetime.now(timezone.utc).isoformat(),checks=checks,check_count=len(checks),
        row_counts=manifest["row_counts"],input_hashes_verified=len(manifest["audited_input_hashes"]),
        all_checks_pass=True,scope="saved data, derivations and provenance; not independent on-chain reconciliation")
    (DATA/"validation.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(f"PASS: {len(checks)} checks; all {len(m)} source histories reconciled.")


if __name__=="__main__":main()
