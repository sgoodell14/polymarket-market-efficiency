"""Plain preparation extracts with actual fields and no explanatory copy."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data/eda/20260916_v2'
OUT = ROOT / 'figures/eda_20260917_cleaning_snapshots_v4'
WEB = ROOT / 'website/assets/cleaning-snapshots'
plt.rcParams.update({'font.family': 'DejaVu Sans Mono', 'font.size': 11,
                     'svg.fonttype': 'none', 'text.color': '#222222'})


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def display(value):
    if value is None:
        return '<NA>'
    return str(value)


def dimensions(headers, rows):
    # Allocate width from displayed content at a fixed monospace font size.
    widths = [max(len(h), *(len(display(r[i])) for r in rows)) * .094 + .30
              for i, h in enumerate(headers)]
    return widths, .40 * (len(rows) + 1)


def render(stem, before_headers, before_rows, after_headers, after_rows,
           before_title='Before', after_title='After', title=None):
    after_widths, after_height = dimensions(after_headers, after_rows)
    if before_headers:
        before_widths, before_height = dimensions(before_headers, before_rows)
    else:
        before_widths, before_height = [1], .6
    width = max(sum(before_widths), sum(after_widths)) + .4
    title_height = .55 if title else 0
    height = before_height + after_height + 1.55 + title_height
    fig = plt.figure(figsize=(width, height), facecolor='white')

    def block(y_top, title, headers, rows, widths, table_height):
        fig.text(.20 / width, y_top / height, title, fontsize=12,
                 weight='bold', va='top')
        y_table = y_top - .40 - table_height
        if not headers:
            fig.text(.20 / width, (y_top - .43) / height, '[]', fontsize=12, va='top')
            return y_table
        ax = fig.add_axes([.20 / width, y_table / height, sum(widths) / width, table_height / height])
        ax.axis('off')
        tab = ax.table(cellText=[[display(v) for v in row] for row in rows],
                       colLabels=headers, colWidths=[w / sum(widths) for w in widths],
                       cellLoc='left', colLoc='left', bbox=[0, 0, 1, 1])
        tab.auto_set_font_size(False)
        tab.set_fontsize(11)
        for (r, c), cell in tab.get_celld().items():
            cell.set_edgecolor('#d6d6d6')
            cell.set_linewidth(.55)
            cell.set_facecolor('#f0f0f0' if r == 0 else 'white')
            cell.PAD = .04
            if r == 0:
                cell.get_text().set_weight('bold')
        return y_table

    if title:
        fig.text(.20 / width, (height - .20) / height, title, fontsize=14, weight='bold', va='top')
    bottom = block(height - .20 - title_height, before_title, before_headers, before_rows, before_widths, before_height)
    block(bottom - .35, after_title, after_headers, after_rows, after_widths, after_height)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for ax in fig.axes:
        for tab in ax.tables:
            for cell in tab.get_celld().values():
                bounds = cell.get_window_extent(renderer)
                text = cell.get_text().get_window_extent(renderer)
                assert text.width < bounds.width * .96, cell.get_text().get_text()
                assert text.height < bounds.height * .96, cell.get_text().get_text()
    for text in fig.texts:
        assert text.get_text() in (before_title, after_title, title, '[]')
    for suffix in ('png', 'svg'):
        fig.savefig(OUT / f'{stem}.{suffix}', dpi=180, facecolor='white')
    plt.close(fig)


def render_table_only(stem, headers, rows):
    """A tightly cropped table: actual column headers and data, no other text."""
    widths, table_height = dimensions(headers, rows)
    margin = .08
    width, height = sum(widths) + 2 * margin, table_height + 2 * margin
    fig = plt.figure(figsize=(width, height), facecolor='white')
    ax = fig.add_axes([margin / width, margin / height, sum(widths) / width, table_height / height])
    ax.axis('off')
    tab = ax.table(cellText=[[display(value) for value in row] for row in rows],
                   colLabels=headers, colWidths=[value / sum(widths) for value in widths],
                   cellLoc='left', colLoc='left', bbox=[0, 0, 1, 1])
    tab.auto_set_font_size(False)
    tab.set_fontsize(11)
    for (row, _), cell in tab.get_celld().items():
        cell.set_edgecolor('#d6d6d6')
        cell.set_linewidth(.55)
        cell.set_facecolor('#f0f0f0' if row == 0 else 'white')
        cell.PAD = .04
        if row == 0:
            cell.get_text().set_weight('bold')
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    assert not fig.texts and not ax.texts and not ax.get_title()
    for cell in tab.get_celld().values():
        bounds = cell.get_window_extent(renderer)
        text = cell.get_text().get_window_extent(renderer)
        assert text.width < bounds.width * .96, cell.get_text().get_text()
        assert text.height < bounds.height * .96, cell.get_text().get_text()
    for suffix in ('png', 'svg'):
        fig.savefig(OUT / f'{stem}.{suffix}', dpi=180, facecolor='white')
    plt.close(fig)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    WEB.mkdir(parents=True, exist_ok=True)
    inputs = {p.relative_to(ROOT).as_posix(): sha(p) for p in
              [DATA / 'trades.parquet', DATA / 'markets.parquet']}
    source_records = []

    def source(row):
        path = row['source_file']
        assert sha(ROOT / path) == row['source_file_sha256']
        rows = json.loads(gzip.decompress((ROOT / path).read_bytes()))
        source_records.append(dict(path=path, sha256=row['source_file_sha256'],
                                   source_row_index=row['source_row_index']))
        return rows[row['source_row_index']]

    trades = pq.read_table(DATA / 'trades.parquet', filters=[('market_id', 'in', ['976988', '1005726'])]).to_pylist()
    label = next(r for r in trades if r['market_id'] == '976988' and r['source_row_index'] == 0)
    raw = source(label)
    assert raw['outcome'] == label['outcome_label_raw']
    assert label['outcome_label'] == "Durban's Super Giants"
    assert label['trade_time_utc'].timestamp() == raw['timestamp']
    assert raw['price'] == label['price'] and raw['size'] == label['size']
    before_fields = ['outcome', 'timestamp', 'price', 'size']
    after_fields = ['source_row_index', 'outcome_label_raw', 'outcome_label', 'trade_time_utc', 'price', 'size']
    render('01_trade_fields_before_after', before_fields, [[raw[k] for k in before_fields]],
           after_fields, [[label[k] for k in after_fields]])

    repeated = sorted([r for r in trades if r['market_id'] == '1005726' and r['source_row_index'] in (66, 67, 68)],
                      key=lambda r: r['source_row_index'])
    raws = [source(r) for r in repeated]
    assert len(raws) == 3 and raws[0] == raws[1] == raws[2]
    assert all(r['duplicate_candidate'] and r['duplicate_group_size'] == 3 for r in repeated)
    assert [r['duplicate_occurrence'] for r in repeated] == [1, 2, 3]
    assert [r['duplicate_excess'] for r in repeated] == [False, True, True]
    repeat_after = ['market_id', 'source_row_index', 'duplicate_candidate', 'duplicate_group_size',
                    'duplicate_occurrence', 'duplicate_excess']

    market = pq.read_table(DATA / 'markets.parquet', filters=[('market_id', '=', '1019728')]).to_pylist()[0]
    empty_path = ROOT / market['source_trade_file']
    assert json.loads(gzip.decompress(empty_path.read_bytes())) == []
    assert market['trade_row_count'] == 0 and market['mean_trade_row_size'] is None
    assert market['wallet_activity_hhi'] is None and market['trade_summary_status'] == 'no_returned_trades'
    assert market['zero_returned_trades'] is True
    assert pq.read_table(DATA / 'trades.parquet', columns=['market_id'],
                         filters=[('market_id', '=', '1019728')]).num_rows == 0
    source_records.append(dict(path=market['source_trade_file'], sha256=sha(empty_path)))
    missing_fields = ['market_id', 'trade_row_count', 'zero_returned_trades', 'mean_trade_row_size',
                      'wallet_activity_hhi', 'trade_summary_status']
    render_table_only('02_repeated_row_flags', repeat_after, [[r[k] for k in repeat_after] for r in repeated])
    render_table_only('03_empty_history_flags', missing_fields, [[market[k] for k in missing_fields]])

    cases = [
        ('01_trade_fields_before_after', 'Labels and timestamps',
         'The original outcome label is preserved alongside a consistent name, and the timestamp is converted to a readable UTC date and time. Price and share quantity remain unchanged.'),
        ('02_repeated_row_flags', 'Repeated trade rows',
         'Identical returned rows are retained. Added columns identify the repeated group, the number of occurrences and each row’s position within that group.'),
        ('03_empty_history_flags', 'Empty trade histories',
         'Markets with no returned trades were flagged in the markets table. The existing market row records a trade count of zero; average trade size and wallet concentration remain missing. No row was added to the trades table.')]
    readme = ['# Data preparation snapshots', '',
        'Actual fields and values from the current 20260916_v2 data. The repeated-row and empty-history examples are now separate, tightly cropped tables with only actual column headers and records. Neither has an After heading, table label or explanation. The trade-field before/after image is unchanged. These are rendered extracts, not screenshots of a spreadsheet application. Earlier versions, including the combined image in ../eda_20260917_cleaning_snapshots_v3, remain preserved.', '',
        'Full raw/cleaned tables have additional columns. Raw JSON rows are displayed as tables; no source-position field is invented in the Before views. `<NA>` represents the stored nulls, matching a nullable DataFrame display. UTC timestamps show their +00:00 offset. The first example omits long identifiers to keep the actual column headers readable.', '',
        '## Three optional explanations and links for Word', '']
    for stem, title, explanation in cases:
        target = f'assets/cleaning-snapshots/{stem}.png'
        shutil.copyfile(OUT / f'{stem}.png', ROOT / 'website' / target)
        readme += [f'### {title}', '', explanation, '',
                   f'Local image: http://127.0.0.1:8765/{target}', '',
                   f'Public URL after publication: https://sgoodell14.github.io/polymarket-market-efficiency/{target}', '']
    readme += ['## Sources and limits', '',
        'Label example: market 976988, source row 0. Repeats: market 1005726, source rows 66–68; complete raw rows match, not only the displayed fields. Empty window: market 1019728; summaries come from the market table. The selected examples explain preparation and are not a representative sample.', '',
        'Repeated-row flags do not establish unique exchange fills. An empty collected window does not establish no lifetime trading. No research data or Word text changed.', '',
        'Run `python -X utf8 -B src/render_cleaning_data_snapshots.py` from the original project to reproduce. Inputs need Matplotlib, PyArrow, the current tables and the saved collection files. Images are staged locally for linking; publication is separate.', '']
    (OUT / 'README.md').write_text('\n'.join(readme), encoding='utf-8')
    # Older separate-image Word links continue to show the matching current example.
    for current_name, previous_name in (
            ('02_repeated_row_flags.png', '02_repeated_rows_before_after.png'),
            ('03_empty_history_flags.png', '03_empty_history_before_after.png')):
        shutil.copyfile(OUT / current_name, WEB / previous_name)
    assert inputs == {p: sha(ROOT / p) for p in inputs}
    manifest = dict(checkpoint='20260916_v2', input_sha256=inputs, source_records=source_records,
                    actual_columns=dict(label_before=before_fields, label_after=after_fields,
                        flags_trades_table=repeat_after, flags_markets_table=missing_fields),
                    labels_only=True, explanatory_text_in_images=False, source_assertions='passed',
                    separate_flags_images=True, flag_images_have_no_labels=True,
                    empty_history_market_id='1019728', empty_history_trade_table_rows=0,
                    research_data_changed=False, publication=False,
                    image_sha256={p.name: sha(p) for p in OUT.glob('*.png')})
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(OUT / 'before-after-data-snapshots.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.iterdir()):
            if p.suffix in ('.png', '.svg', '.md', '.json') and p.name != 'verification.json':
                z.write(p, p.name)
    print(json.dumps(dict(output=str(OUT), images=3, actual_column_names=True,
                         explanations_in_images=False, checks='passed'), indent=2))


if __name__ == '__main__':
    main()
