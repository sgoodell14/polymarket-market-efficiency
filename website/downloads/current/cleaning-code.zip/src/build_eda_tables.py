"""Build transparent EDA tables from fixed audited captures; never alter sources.

No live requests, row deletions, imputation, winsorization or model preprocessing.
CSV exports accompany typed Parquet files; schema.json defines every field.
"""
import csv
import gzip
import hashlib
import io
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

from audit_eda_tables import Audit, distribution, effective_cutoff
from cohort_state import validate_membership
from eda_tables import DATA, ROOT, VERSION

BASE = ROOT / "data/cohort_audit/20260914_sample200"
AUDIT = BASE / ("eda_audit_20260916" if VERSION.endswith('_v1') else "eda_audit_20260916_v2")
TYPES = {"text":pa.string(), "integer":pa.int64(), "number":pa.float64(),
         "boolean":pa.bool_(), "utc_datetime":pa.timestamp("us",tz="UTC")}
SPECS = {t:{} for t in ("markets","trades","price_history")}


def define(table, kind, fields, source, availability, nullable=False):
    for name, description in fields.items():
        SPECS[table][name] = dict(type=kind, nullable=nullable, description=description,
                                source=source, information_class=availability)


define("markets","text",{
    "market_id":"Unique contract ID, preserved as text.", "condition_id":"Contract condition ID.",
    "topic":"Audited topic: Sports, Politics or Economics.", "question":"Contract question.",
    "slug":"Saved contract URL slug.", "event_id":"Parent API event ID; different from the real-world family.",
    "event_family_id":"Audited grouping of contracts about the same real-world event.",
    "outcome_0_token_id":"Token whose probability and result define this forecast.",
    "outcome_1_token_id":"Other token in the same binary contract.",
    "outcome_0_name":"Canonical display name for token index 0; not always Yes.",
    "outcome_1_name":"Canonical display name for token index 1.",
    "event_month":"Calendar month of the reviewed event boundary, YYYY-MM."},
    "active_candidates + reviewed register + effective market metadata","audited_metadata")
define("markets","utc_datetime",{
    "event_time_utc":"Reviewed event boundary, preserving supplied subsecond precision.",
    "reviewed_cutoff_utc":"Reviewed boundary minus 24 hours before integer-second conversion.",
    "original_event_time_utc":"Original discovery anchor, retained for provenance.",
    "listing_time_utc":"Saved market listing time.", "closed_time_utc":"Saved closing time, known after the forecast."},
    "register + active_candidates","audited_metadata")
define("markets","utc_datetime",{
    "forecast_cutoff_utc":"Effective integer-second collection cutoff: floor(event time)-86400.",
    "window_start_utc":"Later of listing time rounded up to seconds and cutoff minus seven days.",
    "forecast_observation_utc":"Timestamp of the selected observed cutoff probability."},
    "effective result.json","pre_cutoff_observation")
define("markets","number",{
    "window_hours":"Actual collection exposure in hours; not assumed to be seven days.",
    "forecast_probability":"Observed probability of outcome 0 at/before cutoff.",
    "cutoff_floor_difference_seconds":"Reviewed cutoff minus integer-second cutoff, in [0,1)."},
    "effective result + reviewed boundary","pre_cutoff_observation")
define("markets","integer",{
    "forecast_age_seconds":"Effective cutoff minus selected price-observation timestamp.",
    "family_market_count":"Number of retained contracts sharing this real-world family."},
    "effective result + audit register","audit_annotation")
define("markets","integer",{"outcome_0_result":"Audited settled outcome: 0 or 1. An outcome, never a pre-cutoff predictor."},
       "audit register + settled metadata","known_after_event")
define("markets","text",{
    "forecast_price_source":"hourly or one_minute_fallback; finer snapshots are not mixed into the hourly path.",
    "evidence_status":"Current accepted evidence status; supersedes provisional capture flags.",
    "boundary_type":"Meaning of the accepted event-time boundary.", "time_precision":"Precision stated by the event-time audit.",
    "event_source_urls":"External evidence links recorded by the audit, separated as in source.",
    "timing_sensitivity_status":"reviewed_scenarios or not_evaluated_in_review."},
    "audit register + effective result","audit_annotation")
define("markets","number",{"timing_sensitivity_range_pp":"Observed range over retained timing scenarios, in percentage points; not a confidence interval."},
       "audit register","audit_annotation",True)
define("markets","boolean",{
    "short_window":"Collection window is shorter than 168 hours.",
    "original_anchor_differs":"Original discovery anchor differs from accepted event time.",
    "sampling_month_differs":"Audited event month differs from the original sampling stratum.",
    "is_replacement":"Market was selected from the saved replacement reserve.",
    "collection_pilot":"Market belongs to the nested collection pilot."},
    "active_candidates + reviewed register + result","audit_annotation")
define("markets","text",{"sampling_month":"Original month stratum; not overwritten after event-time corrections.",
    "sampling_probability_status":"recorded_original_design or unavailable_replacement_probability."},
    "active_candidates","sampling_provenance")
define("markets","text",{"replaces_market_id":"Prior market occupying this sampling slot; null for original selections."},
       "active_candidates","sampling_provenance",True)
define("markets","number",{"event_inclusion_probability":"Saved original-design probability; not a final inverse-probability weight."},
       "active_candidates","sampling_provenance",True)
define("markets","number",{"reported_lifetime_volume":"Reported lifetime metadata volume; unavailable for some markets and not a historical window feature."},
       "active_candidates","metadata_at_collection",True)
define("markets","text",{"reported_volume_status":"available_lifetime_metadata or missing_lifetime_metadata."},
       "active_candidates","metadata_at_collection")
define("markets","text",{"event_structure":"Audited structure of the parent choice group.",
    "option_count_status":"Historical reconstruction, historical_count_unverified, or not_applicable_nonexclusive_bundle."},
    "active_market_options","audit_annotation")
define("markets","integer",{"option_count_at_cutoff":"Reconstructed count if justified; null for unknown/nonexclusive groups.",
    "listed_alternative_count_snapshot":"Descriptive count in the later event response; not backdated to the forecast."},
    "active_market_options","audit_annotation",True)
define("markets","boolean",{"alternatives_mutually_exclusive":"Whether the choice-group alternatives are mutually exclusive.",
    "contemporaneous_menu_verified":"Whether a contemporaneous historical menu was directly verified; false throughout this version."},
    "active_market_options","audit_annotation")
define("markets","integer",{
    "trade_row_count":"All returned rows, retaining ambiguous repeats.", "transaction_count":"Distinct transaction hashes represented in this market's window.",
    "observed_wallet_count":"Distinct observed wallet addresses; not necessarily distinct people.",
    "exact_duplicate_excess":"Repeated exact rows beyond one per signature.",
    "exact_duplicate_group_count":"Number of exact signatures occurring more than once.",
    "sensitivity_trade_row_count":"One row per exact signature, for sensitivity analysis only.",
    "price_point_count":"Observed hourly first-token prices; excludes finer cutoff recovery.",
    "price_interval_count":"Number of adjacent observed hourly pairs.",
    "price_gaps_over_90_minutes":"Count of adjacent observed intervals exceeding 5400 seconds.",
    "price_gaps_over_6_hours":"Count of adjacent observed intervals exceeding 21600 seconds."},
    "effective trade and price windows","derived_pre_cutoff")
define("markets","number",{
    "gross_account_activity":"Sum(price*size) over all returned account rows; not reconciled exchange turnover.",
    "sensitivity_account_activity":"Same sum after keeping the first row per exact signature.",
    "account_activity_per_observed_day":"Gross account activity divided by actual window hours/24; not an extrapolated weekly total."},
    "effective trade window","derived_pre_cutoff")
define("markets","number",{
    "mean_trade_row_size":"Mean shares per returned account row; null when no rows were returned.",
    "mean_trade_row_notional":"Mean price*size per returned account row.",
    "top_wallet_activity_share":"Largest wallet sum(price*size) / gross account activity, in [0,1].",
    "top_five_wallet_activity_share":"Combined five largest wallet activity shares; all wallets if fewer than five.",
    "wallet_activity_hhi":"Sum of squared wallet activity shares, in (0,1]; null with no denominator.",
    "sensitivity_top_wallet_share":"Top-wallet share in the exact-signature sensitivity view.",
    "sensitivity_wallet_hhi":"Wallet HHI in the exact-signature sensitivity view.",
    "duplicate_activity_difference_pct":"100*(all-row activity - sensitivity activity)/all-row activity; null for zero activity."},
    "effective trade window","derived_pre_cutoff",True)
define("markets","boolean",{"zero_returned_trades":"No API trade rows in the bounded pre-cutoff window; does not mean no lifetime trading."},
       "effective trade window","derived_pre_cutoff")
define("markets","text",{"trade_collection_status":"Saved API window completion status.",
    "trade_summary_status":"observed_rows or no_returned_trades; explains missing row means/concentration.",
    "price_path_status":"observed_hourly_path, single_hourly_observation, or no_hourly_observations; cutoff snapshot availability is separate."},
    "effective windows + result","audit_annotation")
define("markets","number",{"max_price_gap_hours":"Longest adjacent observed interval; null when fewer than two points exist.",
    "median_price_gap_seconds":"Median elapsed seconds between observed points.",
    "leading_price_gap_hours":"Time from window start to first hourly observation; null for an empty series.",
    "trailing_price_gap_hours":"Time from last hourly observation to cutoff, separately from selected snapshot age.",
    "max_observed_price_step_pp":"Largest absolute adjacent probability difference in percentage points; may span a gap."},
    "effective hourly price window","derived_pre_cutoff",True)
define("markets","boolean",{"flat_hourly_series":"All observed probabilities equal, with at least two points; null if no path."},
       "effective hourly price window","derived_pre_cutoff",True)
define("markets","integer",{"observed_steps_ge_20pp":"Number of adjacent observed price changes at least 20 percentage points; null if no path."},
       "effective hourly price window","derived_pre_cutoff",True)

for table in SPECS:
    define(table,"text",{"source_capture_id":"Market ID plus SHA-256 of its effective result.json; identifies the frozen capture."},
           "effective capture","provenance")
define("markets","text",{"source_capture_path":"Project-relative path to effective result.json.",
    "source_metadata_file":"Project-relative saved market metadata path.",
    "source_trade_file":"Project-relative effective trade-array path.",
    "source_price_file":"Project-relative effective hourly price-array path.",
    "source_register_file":"Project-relative current audit register; join by market_id."},
    "active coverage + register","provenance")
define("markets","utc_datetime",{"captured_at_utc":"Collection timestamp; later than forecast, not a predictor."},
       "effective result","provenance")
SPECS["markets"]["closed_time_utc"]["information_class"]="known_after_event"
SPECS["markets"]["listed_alternative_count_snapshot"]["information_class"]="metadata_at_collection"

define("trades","text",{"trade_row_id":"Stable source-row identity; not a unique fill ID.",
    "market_id":"Parent contract ID.","condition_id":"Condition ID used for the market join.",
    "token_id":"Traded token ID, kept as text.","wallet_address":"Lowercase wallet address; profile names are not identifiers.",
    "transaction_hash":"Lowercase transaction hash; may contain many distinct returned records.",
    "side":"Returned BUY or SELL, without an inferred maker/taker role.",
    "outcome_label_raw":"Original returned label, preserved including punctuation differences.",
    "outcome_label":"Canonical token-index label from saved market metadata.",
    "exact_signature_id":"SHA-256 of market ID and complete original row; candidate grouping, not fill identity."},
    "effective trades + token metadata","pre_cutoff_observation")
define("trades","utc_datetime",{"trade_time_utc":"UTC time of the returned trade record, with second precision."},
       "trade timestamp","pre_cutoff_observation")
define("trades","integer",{"timestamp_epoch_seconds":"Original integer Unix timestamp.",
    "outcome_index":"0 or 1; validated against the asset/token ID.",
    "first_outcome_direction":"+1 for BUY 0 or SELL 1; -1 for SELL 0 or BUY 1. Semantic direction, not inferred net demand.",
    "duplicate_group_size":"Number of identical full rows in this market capture.",
    "duplicate_occurrence":"One-based occurrence in original source order; defines the sensitivity view."},
    "effective trades","derived_pre_cutoff")
define("trades","number",{"price":"Token-native trade price, in [0,1].",
    "size":"Returned number of outcome shares.","row_notional":"Unrounded price times size in dollar-equivalent consideration."},
    "effective trades","pre_cutoff_observation")
define("trades","boolean",{"outcome_label_changed":"Canonical label differs from preserved original text.",
    "duplicate_candidate":"The exact signature has more than one source occurrence.",
    "duplicate_excess":"Occurrence beyond the first exact-signature row.",
    "in_exact_signature_sensitivity":"Keep this row in the separately named sensitivity view."},
    "effective trades + token metadata","audit_annotation")

define("price_history","text",{"price_row_id":"Stable identity of the observed source price row.",
    "market_id":"Parent contract ID.","token_id":"First outcome token; no synthetic complement series.",
    "interval_status":"first_observation, adjacent_within_90_minutes, or gap_over_90_minutes."},
    "effective hourly price window","pre_cutoff_observation")
define("price_history","utc_datetime",{"observation_time_utc":"UTC time of the actual returned hourly observation."},
       "price t field","pre_cutoff_observation")
define("price_history","integer",{"timestamp_epoch_seconds":"Original integer Unix observation timestamp."},
       "price t field","pre_cutoff_observation")
define("price_history","number",{"probability":"Observed first-outcome probability, in [0,1].",
    "hours_before_cutoff":"Elapsed hours from this observation to effective forecast cutoff."},
    "hourly history + effective cutoff","pre_cutoff_observation")
define("price_history","integer",{"elapsed_seconds_since_previous":"Actual gap to preceding observed point; null for first point."},
       "adjacent observed timestamps","derived_pre_cutoff",True)
define("price_history","number",{"observed_change_pp":"100*(current probability - previous observed probability); null for first point."},
       "adjacent observed prices","derived_pre_cutoff",True)
define("price_history","boolean",{"gap_over_90_minutes":"Actual observed interval exceeds 5400 seconds; null for first point.",
    "gap_over_6_hours":"Actual observed interval exceeds 21600 seconds; null for first point."},
    "adjacent observed timestamps","derived_pre_cutoff",True)
for table in ("trades","price_history"):
    define(table,"text",{"source_file":"Project-relative effective source-array path.",
        "source_file_sha256":"SHA-256 of the compressed source file; also recorded in manifest.json."},
        "effective capture","provenance")
    define(table,"integer",{"source_row_index":"Zero-based index in the original effective source array, before sorting."},
        "effective capture","provenance")


def utc(value):
    if isinstance(value,(int,float)):
        return datetime.fromtimestamp(value,timezone.utc)
    return datetime.fromisoformat(value.replace("Z","+00:00")).astimezone(timezone.utc)


def optional_number(value, as_int=False):
    return None if value in (None,"") else (int(value) if as_int else float(value))


def parse_bool(value):
    if value in (True,"True","true"):
        return True
    if value in (False,"False","false"):
        return False
    raise ValueError(f"Not an explicit Boolean: {value!r}")


def signature(mid,row):
    original=json.dumps(row,sort_keys=True,separators=(",",":"))
    return hashlib.sha256((mid+"|"+original).encode()).hexdigest()


def wallet_summary(rows):
    activity=defaultdict(float)
    for row in rows:
        activity[row["wallet_address"]]+=row["row_notional"]
    total=math.fsum(r["row_notional"] for r in rows)
    shares=sorted((value/total for value in activity.values()),reverse=True) if total>0 else []
    return dict(total=total,wallets=len(activity),top=shares[0] if shares else None,
                top5=math.fsum(shares[:5]) if shares else None,
                hhi=math.fsum(s*s for s in shares) if shares else None)


def transform_trades(mid,rows,tokens,names,capture,path,digest):
    signatures=[signature(mid,row) for row in rows]
    counts=Counter(signatures); occurrences=Counter(); result=[]
    for index,(row,key) in enumerate(zip(rows,signatures)):
        oi=row["outcomeIndex"]
        if row["asset"]!=tokens[oi]:
            raise ValueError(f"Token/index mismatch: {mid}:{index}")
        occurrences[key]+=1
        result.append(dict(source_capture_id=capture,trade_row_id=f"{mid}:{digest}:{index}",market_id=mid,
            condition_id=row["conditionId"],token_id=row["asset"],wallet_address=row["proxyWallet"].lower(),
            transaction_hash=row["transactionHash"].lower(),side=row["side"],outcome_label_raw=row["outcome"],
            outcome_label=names[oi],exact_signature_id=key,trade_time_utc=utc(row["timestamp"]),
            timestamp_epoch_seconds=row["timestamp"],outcome_index=oi,
            first_outcome_direction=1 if (row["side"]=="BUY")== (oi==0) else -1,
            duplicate_group_size=counts[key],duplicate_occurrence=occurrences[key],price=row["price"],size=row["size"],
            row_notional=row["price"]*row["size"],outcome_label_changed=row["outcome"]!=names[oi],
            duplicate_candidate=counts[key]>1,duplicate_excess=occurrences[key]>1,
            in_exact_signature_sensitivity=occurrences[key]==1,source_file=path,source_file_sha256=digest,source_row_index=index))
    return sorted(result,key=lambda r:(r["timestamp_epoch_seconds"],r["source_row_index"]))


def transform_prices(mid,rows,token,cutoff,capture,path,digest):
    result=[]; previous=None
    for index,row in sorted(enumerate(rows),key=lambda pair:(pair[1]["t"],pair[0])):
        gap=row["t"]-previous["t"] if previous is not None else None
        result.append(dict(source_capture_id=capture,price_row_id=f"{mid}:{digest}:{index}",market_id=mid,token_id=token,
            interval_status="first_observation" if gap is None else ("gap_over_90_minutes" if gap>5400 else "adjacent_within_90_minutes"),
            observation_time_utc=utc(row["t"]),timestamp_epoch_seconds=row["t"],probability=row["p"],
            hours_before_cutoff=(cutoff-row["t"])/3600,elapsed_seconds_since_previous=gap,
            observed_change_pp=None if previous is None else 100*(row["p"]-previous["p"]),
            gap_over_90_minutes=None if gap is None else gap>5400,gap_over_6_hours=None if gap is None else gap>21600,
            source_file=path,source_file_sha256=digest,source_row_index=index))
        previous=row
    return result


class TableWriter:
    def __init__(self,name):
        self.name=name; self.count=0
        self.schema=pa.schema([pa.field(k,TYPES[v["type"]],nullable=v["nullable"],
            metadata={"description":v["description"]}) for k,v in SPECS[name].items()])
        self.parquet=pq.ParquetWriter(DATA/f"{name}.parquet",self.schema,compression="zstd")
        self.raw=None; self.compressed=None
        if name=="markets":
            self.csv=(DATA/"markets.csv").open("w",encoding="utf-8",newline="")
        else:
            self.raw=(DATA/f"{name}.csv.gz").open("wb")
            self.compressed=gzip.GzipFile(filename="",mode="wb",fileobj=self.raw,mtime=0)
            self.csv=io.TextIOWrapper(self.compressed,encoding="utf-8",newline="")
        self.writer=csv.DictWriter(self.csv,fieldnames=list(SPECS[name]));self.writer.writeheader()

    def append(self,rows):
        for row in rows:
            if set(row)!=set(SPECS[self.name]):
                raise ValueError(f"Schema mismatch {self.name}: {set(row)^set(SPECS[self.name])}")
            for field,spec in SPECS[self.name].items():
                if row[field] is None and not spec["nullable"]:
                    raise ValueError(f"Unexpected null: {self.name}.{field}")
        table=pa.Table.from_pylist(rows,schema=self.schema)
        if rows:self.parquet.write_table(table)
        for row in rows:
            self.writer.writerow({k:(v.isoformat().replace("+00:00","Z") if isinstance(v,datetime) else v) for k,v in row.items()})
        self.count+=len(rows)

    def close(self):
        self.parquet.close();self.csv.close()
        if self.raw:self.raw.close()


def main():
    # Freeze the audit checkpoint. Refuse to build from silently changed sources.
    audited=json.loads((AUDIT/"input_manifest.json").read_text(encoding="utf-8"))["sha256"]
    for name,digest in audited.items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
            raise ValueError(f"Audited input changed: {name}. Re-audit and version the build.")
    reader=Audit()
    candidates=reader.csv(BASE/"active_candidates.csv","candidates")
    membership=reader.json(BASE/"cohort_membership.json")
    validate_membership(candidates,membership)
    def by_id(path):return {r["market_id"]:r for r in reader.csv(path,path.name)}
    coverage=by_id(BASE/"active_cohort_coverage.csv")
    register=by_id(BASE/"full_audit_20260915/cohort_audit_register.csv")
    options=by_id(BASE/"active_market_options.csv")
    for rows in (coverage,register,options):
        if set(rows)!=set(membership["active_market_ids"]):raise ValueError("Incomplete one-to-one metadata join")
    if (DATA/"manifest.json").exists():
        old=json.loads((DATA/"manifest.json").read_text(encoding="utf-8"))
        if old["audited_input_hashes"]!=audited:raise ValueError("Use a new build directory for changed inputs")
    DATA.mkdir(parents=True,exist_ok=True)
    writers={name:TableWriter(name) for name in SPECS}
    markets=[]
    try:
        for i,c in enumerate(sorted(candidates,key=lambda r:r["market_id"]),1):
            mid=c["market_id"];r=register[mid];o=options[mid]
            folder=(BASE/coverage[mid]["capture_path"]).parent
            result=reader.json(folder/"result.json"); metadata=reader.json(folder/"market.json.gz")
            original_trades=reader.json(folder/"trades_window.json.gz"); original_prices=reader.json(folder/"prices_window.json.gz")
            relative=lambda file:(folder/file).relative_to(ROOT).as_posix()
            capture=mid+":"+reader.inputs[relative("result.json")]
            tokens=json.loads(metadata["clobTokenIds"]); names=json.loads(metadata["outcomes"])
            lo,hi=result["window_start_timestamp"],result["cutoff_timestamp"]
            assert effective_cutoff(r["reviewed_anchor_utc"])==hi
            trades=transform_trades(mid,original_trades,tokens,names,capture,relative("trades_window.json.gz"),reader.inputs[relative("trades_window.json.gz")])
            prices=transform_prices(mid,original_prices,tokens[0],hi,capture,relative("prices_window.json.gz"),reader.inputs[relative("prices_window.json.gz")])
            sensitivity=[t for t in trades if t["in_exact_signature_sensitivity"]]
            ws=wallet_summary(trades);ss=wallet_summary(sensitivity)
            intervals=[p["elapsed_seconds_since_previous"] for p in prices if p["elapsed_seconds_since_previous"] is not None]
            steps=[abs(p["observed_change_pp"]) for p in prices if p["observed_change_pp"] is not None]
            probability=optional_number(c["event_inclusion_probability"])
            volume=optional_number(c["reported_volume"])
            timing=optional_number(r["timing_sensitivity_range_pp"])
            hours=(hi-lo)/3600
            m=dict(market_id=mid,condition_id=c["condition_id"],topic=c["topic"],question=c["question"],slug=c["slug"],
                event_id=o["event_id"],event_family_id=r["event_family_id"],outcome_0_token_id=tokens[0],outcome_1_token_id=tokens[1],
                outcome_0_name=names[0],outcome_1_name=names[1],event_month=r["reviewed_anchor_utc"][:7],
                event_time_utc=utc(r["reviewed_anchor_utc"]),reviewed_cutoff_utc=utc(r["reviewed_cutoff_utc"]),
                original_event_time_utc=utc(c["anchor"]),listing_time_utc=utc(c["start_date"]),closed_time_utc=utc(c["closed_time"]),
                forecast_cutoff_utc=utc(hi),window_start_utc=utc(lo),forecast_observation_utc=utc(hi-result["forecast_price_age_seconds"]),
                window_hours=hours,forecast_probability=result["forecast_probability"],
                cutoff_floor_difference_seconds=(utc(r["reviewed_cutoff_utc"])-utc(hi)).total_seconds(),
                forecast_age_seconds=result["forecast_price_age_seconds"],family_market_count=int(r["family_market_count"]),
                outcome_0_result=int(r["expected_outcome"]),forecast_price_source=result.get("cutoff_price_source") or "hourly",
                evidence_status=r["evidence_status"],boundary_type=r["boundary_type"],time_precision=r["time_precision"],
                event_source_urls=r["source_urls"],timing_sensitivity_status="reviewed_scenarios" if timing is not None else "not_evaluated_in_review",
                timing_sensitivity_range_pp=timing,short_window=hours<168,original_anchor_differs=utc(c["anchor"])!=utc(r["reviewed_anchor_utc"]),
                sampling_month_differs=c["sampling_month"]!=r["reviewed_anchor_utc"][:7],is_replacement=bool(c["replaces_market_id"]),
                collection_pilot=parse_bool(c["collection_pilot"]),sampling_month=c["sampling_month"],
                sampling_probability_status="recorded_original_design" if probability is not None else "unavailable_replacement_probability",
                replaces_market_id=c["replaces_market_id"] or None,event_inclusion_probability=probability,reported_lifetime_volume=volume,
                reported_volume_status="available_lifetime_metadata" if volume is not None else "missing_lifetime_metadata",
                event_structure=o["event_structure"],option_count_status=o["option_count_status"],
                option_count_at_cutoff=optional_number(o["option_count_at_cutoff"],True),
                listed_alternative_count_snapshot=optional_number(o["listed_alternative_count_snapshot"],True),
                alternatives_mutually_exclusive=parse_bool(o["alternatives_mutually_exclusive"]),
                contemporaneous_menu_verified=parse_bool(o["contemporaneous_menu_verified"]),trade_row_count=len(trades),
                transaction_count=len({t["transaction_hash"] for t in trades}),observed_wallet_count=ws["wallets"],
                exact_duplicate_excess=len(trades)-len(sensitivity),
                exact_duplicate_group_count=len({t["exact_signature_id"] for t in trades if t["duplicate_candidate"]}),
                sensitivity_trade_row_count=len(sensitivity),price_point_count=len(prices),price_interval_count=len(intervals),
                price_gaps_over_90_minutes=sum(g>5400 for g in intervals),price_gaps_over_6_hours=sum(g>21600 for g in intervals),
                gross_account_activity=ws["total"],sensitivity_account_activity=ss["total"],account_activity_per_observed_day=ws["total"]/(hours/24),
                mean_trade_row_size=math.fsum(t["size"] for t in trades)/len(trades) if trades else None,
                mean_trade_row_notional=ws["total"]/len(trades) if trades else None,
                top_wallet_activity_share=ws["top"],top_five_wallet_activity_share=ws["top5"],wallet_activity_hhi=ws["hhi"],
                sensitivity_top_wallet_share=ss["top"],sensitivity_wallet_hhi=ss["hhi"],
                duplicate_activity_difference_pct=100*(ws["total"]-ss["total"])/ws["total"] if ws["total"]>0 else None,
                zero_returned_trades=not trades,trade_collection_status=result["trade_status"],
                trade_summary_status="observed_rows" if trades else "no_returned_trades",
                price_path_status="observed_hourly_path" if intervals else ("single_hourly_observation" if prices else "no_hourly_observations"),
                max_price_gap_hours=max(intervals)/3600 if intervals else None,
                median_price_gap_seconds=distribution(intervals).get("median"),
                leading_price_gap_hours=(prices[0]["timestamp_epoch_seconds"]-lo)/3600 if prices else None,
                trailing_price_gap_hours=(hi-prices[-1]["timestamp_epoch_seconds"])/3600 if prices else None,
                max_observed_price_step_pp=max(steps) if steps else None,
                flat_hourly_series=len({p["probability"] for p in prices})==1 if intervals else None,
                observed_steps_ge_20pp=sum(s>=20 for s in steps) if intervals else None,
                source_capture_id=capture,source_capture_path=relative("result.json"),source_metadata_file=relative("market.json.gz"),
                source_trade_file=relative("trades_window.json.gz"),source_price_file=relative("prices_window.json.gz"),
                source_register_file=(BASE/"full_audit_20260915/cohort_audit_register.csv").relative_to(ROOT).as_posix(),
                captured_at_utc=utc(result["captured_at_utc"]))
            writers["trades"].append(trades);writers["price_history"].append(prices);markets.append(m)
            if i%100==0 or i==len(candidates):print(f"Built {i}/{len(candidates)} markets",flush=True)
        writers["markets"].append(markets)
    finally:
        for writer in writers.values():writer.close()
    (DATA/"schema.json").write_text(json.dumps(SPECS,indent=2)+"\n",encoding="utf-8")
    dictionary=["# EDA field dictionary","","Generated from the explicit builder schema. Parquet preserves types; CSV imports must use this schema.",
        "","Nulls are empty CSV cells, never a numeric zero. Times are UTC; probabilities use 0-1 units, activity uses observed price*shares.",
        "","`information_class` separates observed pre-cutoff values, derived summaries, sampling/audit annotations, later metadata, provenance and settled outcomes."]
    for table,fields in SPECS.items():
        dictionary.extend(["",f"## {table}","","| Field | Type | Null allowed | Meaning | Source / information class |","|---|---|---|---|---|"])
        dictionary.extend(f"| `{key}` | {s['type']} | {s['nullable']} | {s['description']} | {s['source']} / {s['information_class']} |" for key,s in fields.items())
    (DATA/"data_dictionary.md").write_text("\n".join(dictionary)+"\n",encoding="utf-8")
    for name,digest in audited.items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:raise ValueError("Source changed during build: "+name)
    manifest=dict(version=VERSION,built_at_utc=datetime.now(timezone.utc).isoformat(),
        row_counts={k:w.count for k,w in writers.items()},audited_input_hashes=audited,
        builder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        loader_sha256=hashlib.sha256((ROOT/"src/eda_tables.py").read_bytes()).hexdigest(),
        pyarrow_version=pa.__version__,csv_null="empty cell",primary_format="parquet",source_data_unchanged=True,
        output_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.iterdir() if p.suffix in (".parquet",".gz") or p.name in ("markets.csv","schema.json","data_dictionary.md")})
    (DATA/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(manifest["row_counts"]))


if __name__=="__main__":main()
