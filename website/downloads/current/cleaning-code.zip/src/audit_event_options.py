"""Capture full parent-event listings and describe alternatives for the audited cohort.

Current event metadata is retained as raw evidence. Historical counts must be
labeled as reconstructions, not contemporaneous snapshots of the trading menu.
"""
import argparse
import csv
import gzip
import hashlib
import json
import re
import shutil
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

from audit_cohort import GAMMA, fetch, stamp
from cohort_state import validate_membership
from prepare_sampling_plan import OUTPUT, ROOT, write_csv

RUN = OUTPUT / 'options_20260916_v2'

# Read against complete event and constituent contract rules. These bundles
# permit several Yes resolutions and must not be treated as one categorical bet.
NONEXCLUSIVE = {
    '563772': ('geographic_subquestions', 'Five separate boroughs; Mamdani can win several boroughs.'),
    '1849834': ('overlapping_thresholds', 'At least 300/400/500/600 seats are nested thresholds, not disjoint bins.'),
    '1737537': ('multiple_qualifiers', 'Each party is tested separately for entering parliament; several can qualify.'),
    '2325034': ('multiple_qualifiers', 'Each candidate is tested for advancing from a top-two primary; two can advance.'),
    '2662165': ('separate_ballot_questions', 'Two referendum proposals are separate Yes/No questions and can both pass.'),
    '1572667': ('multiple_qualifiers', 'Separate lists may qualify for the Paris second round; more than one can advance.'),
}

# Neg-risk is an exchange mechanism, not the only way to encode disjoint choices.
NON_NEGRISK_PARTITIONS = {
    '576090': 'Dissenting votes are exactly 0, 1, 2, 3, or 4+ in the same FOMC decision.',
    '1301189': 'Eurozone Q1 GDP uses disjoint ranges at the source\'s stated one-decimal precision.',
}


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as stream:
        return list(csv.DictReader(stream))


def save(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')


def array(value):
    return json.loads(value) if isinstance(value,str) else (value or [])


def setup():
    rows=read_csv(OUTPUT / 'active_candidates.csv')
    validate_membership(rows)
    RUN.mkdir(exist_ok=True)
    paths=[OUTPUT / 'active_candidates.csv',OUTPUT / 'cohort_membership.json',
           OUTPUT / 'full_audit_20260915/cohort_audit_register.csv']
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    manifest=RUN / 'input_manifest.json'
    if manifest.exists():
        assert read_json(manifest)['input_hashes']==hashes,'Cohort inputs changed; use a new run'
    else:
        save(manifest,dict(created_at_utc=datetime.now(timezone.utc).isoformat(),input_hashes=hashes,
            active_market_ids=[r['market_id'] for r in rows],
            purpose='Describe full event alternatives, with cutoff-aware reconstruction and explicit limitations.'))
    # Preserve earlier event snapshots and their original retrieval provenance.
    (RUN / 'raw').mkdir(exist_ok=True)
    for row in rows:
        for eid in row['event_ids'].split(';'):
            for suffix in ('.json.gz', '.request.json'):
                old = OUTPUT / 'options_20260916/raw' / ('event_' + eid + suffix)
                target = RUN / 'raw' / old.name
                if old.exists() and not target.exists():
                    shutil.copyfile(old, target)
    return rows


def fetch_event(eid):
    payload=fetch(RUN / 'raw','event_'+eid,GAMMA,'/events/'+eid)
    assert str(payload.get('id'))==eid
    assert isinstance(payload.get('markets'),list) and payload['markets'],eid
    return payload


def collect_events(rows,limit=None):
    ids=sorted({eid for row in rows for eid in row['event_ids'].split(';') if eid},key=int)
    if limit: ids=ids[:limit]
    results=[]
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures={pool.submit(fetch_event,eid):eid for eid in ids}
        for future in as_completed(futures):
            eid=futures[future]
            try:
                event=future.result()
                result=dict(event_id=eid,status='retrieved',title=event.get('title'),market_count=len(event['markets']))
            except Exception as error:
                result=dict(event_id=eid,status='error',error=str(error))
            results.append(result)
            if len(results)%25==0 or result['status']=='error' or len(results)==len(ids):
                print(f"Event listings: {len(results)}/{len(ids)}; errors: {sum(r['status']=='error' for r in results)}",flush=True)
    save(RUN / 'collection_results.json',results)


def slot_kind(market):
    """Count catch-all Other once; omit unnamed placeholders from named choices."""
    label=(market.get('groupItemTitle') or '').strip()
    question=market.get('question','').strip()
    if market.get('negRiskOther') or label.lower()=='other':
        return 'other'
    # Fullmatch prevents real names such as Party for Freedom being discarded.
    prefix=r'(?:candidate|person|party|coalition|option|outcome|placeholder)'
    if re.fullmatch(prefix+r'(?:\s+[A-Za-z]{1,2}|\s+\d+)?',label,re.I):
        return 'placeholder'
    if re.search(r'^Will\s+'+prefix+r'\s+[A-Z]{1,2}(?=\s|\?)',question,re.I):
        return 'placeholder'
    return 'named'


def availability(market,cutoff):
    """Use historical timestamp fields, never today's active/closed boolean."""
    values={k:stamp(market.get(k)) for k in ('createdAt','startDate','acceptingOrdersTimestamp','closedTime')}
    opening=[values[k] for k in ('startDate','acceptingOrdersTimestamp') if values[k]]
    if values['createdAt'] and values['createdAt']>cutoff:
        return 'created_after_cutoff'
    if opening and max(opening)>cutoff:
        return 'opened_after_cutoff'
    if values['closedTime'] and values['closedTime']<=cutoff:
        return 'closed_by_cutoff'
    if not opening:
        return 'opening_time_unknown'
    return 'timestamp_supported_open_at_cutoff'


def classify(row,event,target,relevant):
    mid=row['market_id']
    outcomes=array(target['outcomes'])
    if row['topic']=='Sports':
        if set(outcomes)!={'Yes','No'}:
            assert len(relevant)==1 and len(outcomes)==2,mid
            return 'sports_two_way',True,'One moneyline contract names both competitors; side bets excluded.'
        assert len(relevant)==3 and any('draw' in m['question'].lower() for m in relevant),mid
        assert all(set(array(m['outcomes']))=={'Yes','No'} for m in relevant),mid
        return 'sports_three_way',True,'Three moneyline alternatives: either competitor wins, or a draw; side bets excluded.'
    if mid in NONEXCLUSIVE:
        structure,evidence=NONEXCLUSIVE[mid]
        return structure,False,evidence
    if len(relevant)==1:
        return 'standalone_binary',True,'The event page contains one two-outcome proposition; no broader candidate-field size is inferred.'
    evidence=NON_NEGRISK_PARTITIONS.get(mid)
    if not event.get('negRisk') and not evidence:
        raise ValueError('Multi-market event needs a documented structural decision: '+mid)
    evidence=evidence or 'Same neg-risk group and event rules define one resolving alternative.'
    title=event['title'].lower()
    if row['topic']=='Economics':
        structure='policy_options' if re.search(r'decision|interest rates',title) else 'economic_ranges'
        if 'up/down' in title: structure='economic_direction'
    elif mid=='2261551':
        structure='candidate_pair_or_outright_winner'
        evidence='Three specified pairs, Other pair, or an outright first-round winner; these are exclusive configurations, not five candidates.'
    elif re.search(r'margin|turnout|%|vote share|# of|how many',title):
        structure='election_ranges'
    else:
        structure='candidate_or_party_options'
    return structure,True,evidence


def describe(row,audit,event):
    """Return market-level metadata and a ledger of every parent-event contract."""
    mid=row['market_id'];cutoff=stamp(audit['reviewed_cutoff_utc'])
    markets=event['markets'];ids=[str(m['id']) for m in markets]
    assert len(ids)==len(set(ids)),event['id']
    assert mid in ids,(mid,event['id'])
    target=next(m for m in markets if str(m['id'])==mid)
    assert target['conditionId']==row['condition_id'],mid
    assert array(target['clobTokenIds'])[0]==row['first_token_id'],mid
    assert len(array(target['outcomes']))==len(array(target['clobTokenIds']))==2,mid
    relevant=[m for m in markets if m.get('sportsMarketType')=='moneyline'] if row['topic']=='Sports' else markets
    assert target in relevant,mid
    if target.get('negRiskMarketID'):
        assert all(m.get('negRiskMarketID')==target['negRiskMarketID'] for m in relevant),mid
    structure,exclusive,evidence=classify(row,event,target,relevant)
    relevant_ids={str(m['id']) for m in relevant}
    ledger=[]
    for m in markets:
        label=m.get('groupItemTitle') or m['question']
        ledger.append(dict(sampled_market_id=mid,event_id=str(event['id']),market_id=str(m['id']),
            question=m['question'],option_label=label,kind=slot_kind(m),
            relevant_to_sampled_question=str(m['id']) in relevant_ids,
            sports_market_type=m.get('sportsMarketType',''),outcomes=json.dumps(array(m.get('outcomes')),ensure_ascii=False),
            created_at=m.get('createdAt',''),start_date=m.get('startDate',''),
            accepting_orders_timestamp=m.get('acceptingOrdersTimestamp',''),closed_time=m.get('closedTime',''),
            forecast_cutoff=audit['reviewed_cutoff_utc'],cutoff_availability=availability(m,cutoff),
            neg_risk_other=bool(m.get('negRiskOther')),neg_risk_group=m.get('negRiskMarketID',''),
            rules_sha256=hashlib.sha256(m.get('description','').encode()).hexdigest()))
    rel=[x for x in ledger if x['relevant_to_sampled_question']]
    named=[x for x in rel if x['kind']=='named'];other=[x for x in rel if x['kind']=='other']
    placeholders=[x for x in rel if x['kind']=='placeholder']
    substantive=named+other
    timed=[x for x in substantive if x['cutoff_availability']=='timestamp_supported_open_at_cutoff']
    unknown=[x for x in substantive if x['cutoff_availability']=='opening_time_unknown']
    later=[x for x in substantive if x['cutoff_availability'] in ('created_after_cutoff','opened_after_cutoff')]
    earlier=[x for x in substantive if x['cutoff_availability']=='closed_by_cutoff']
    simple=structure in ('sports_two_way','standalone_binary')
    observed=2 if simple else len(substantive) if exclusive else None
    # Timestamp reconstruction alone cannot establish when an augmented
    # placeholder acquired its current name. Do not silently use final names.
    flexible=bool(event.get('negRiskAugmented')) or bool(placeholders)
    issues=[]
    if flexible: issues.append('historical_placeholder_naming_not_verified')
    if unknown: issues.append('some_opening_timestamps_missing')
    if later: issues.append('options_added_after_cutoff_excluded')
    if earlier: issues.append('options_closed_before_cutoff_excluded')
    if not exclusive:
        count=None; status='not_applicable_nonexclusive_bundle'
    elif flexible or unknown:
        count=None;status='historical_count_unverified'
    else:
        count=2 if simple else len(timed)
        status='reconstructed_from_fixed_structure_and_timestamps'
    if simple and availability(target,cutoff)!='timestamp_supported_open_at_cutoff':
        count=None;status='historical_count_unverified';issues.append('sampled_contract_opening_unverified')
    result=dict(market_id=mid,topic=row['topic'],question=row['question'],event_id=str(event['id']),
        event_title=event['title'],event_family_id=audit['event_family_id'],forecast_cutoff=audit['reviewed_cutoff_utc'],
        contract_outcome_count=2,contract_outcome_names=json.dumps(array(target['outcomes']),ensure_ascii=False),
        event_structure=structure,alternatives_mutually_exclusive=exclusive,
        parent_event_contract_count=len(markets),relevant_contract_count=len(relevant),
        unrelated_side_bet_count=len(markets)-len(relevant),
        named_option_contracts_snapshot=len(named),other_option_contracts_snapshot=len(other),
        placeholder_contracts_snapshot=len(placeholders),
        listed_alternative_count_snapshot=observed,
        named_and_other_contracts_with_pre_cutoff_timestamps=len(timed),
        relevant_contracts_missing_opening_timestamp=sum(x['cutoff_availability']=='opening_time_unknown' for x in rel),
        options_added_after_cutoff=len(later),options_closed_before_cutoff=len(earlier),
        option_count_at_cutoff=count,option_count_status=status,
        count_is_historical_reconstruction=True if count is not None else False,
        contemporaneous_menu_verified=False,augmented_neg_risk=bool(event.get('negRiskAugmented')),
        structural_evidence=evidence,option_count_flags=';'.join(issues),
        option_count_scope='Alternative contracts within the same question/group; not number of real-world eligible candidates.',
        raw_source=str((RUN / 'raw' / ('event_'+str(event['id'])+'.json.gz')).relative_to(OUTPUT)),
        source_url=GAMMA+'/events/'+str(event['id']))
    return result,ledger


def analyze(rows):
    audit={r['market_id']:r for r in read_csv(OUTPUT / 'full_audit_20260915/cohort_audit_register.csv')}
    records,contracts=[],[]
    for row in rows:
        eid=row['event_ids'];assert ';' not in eid
        path=RUN / 'raw' / ('event_'+eid+'.json.gz')
        sidecar=read_json(path.with_name('event_'+eid+'.request.json'))
        body=gzip.decompress(path.read_bytes())
        assert hashlib.sha256(body).hexdigest()==sidecar['sha256'],eid
        event=json.loads(body);assert str(event['id'])==eid
        record,ledger=describe(row,audit[row['market_id']],event)
        record.update(retrieved_at_utc=sidecar['fetched_at_utc'],raw_response_sha256=sidecar['sha256'])
        records.append(record);contracts.extend(ledger)
    assert len(records)==len({r['market_id'] for r in records})==len(rows)
    write_csv(RUN / 'market_options.csv',records)
    write_csv(RUN / 'event_contracts.csv',contracts)
    # Stable, joinable current view; no changes to roster, labels or timing gates.
    write_csv(OUTPUT / 'active_market_options.csv',records)
    write_csv(RUN / 'historical_count_limits.csv',[r for r in records if r['option_count_status']=='historical_count_unverified'])
    write_csv(RUN / 'nonexclusive_bundles.csv',[r for r in records if not r['alternatives_mutually_exclusive']])
    save(RUN / 'structural_decisions.json',dict(nonexclusive=NONEXCLUSIVE,
        non_negrisk_partitions=NON_NEGRISK_PARTITIONS,
        taxonomy_note='Sports select moneyline markets only; standard neg-risk groups provide exclusive alternatives; numerical and exceptional groups checked against full event rules.'))
    summary=dict(markets_checked=len(records),event_responses_hashed=len(records),
        parent_event_contracts=len(contracts),relevant_contracts=sum(r['relevant_contract_count'] for r in records),
        unrelated_side_bets=sum(r['unrelated_side_bet_count'] for r in records),
        placeholder_contracts=sum(r['placeholder_contracts_snapshot'] for r in records),
        all_sampled_contracts_binary=all(r['contract_outcome_count']==2 for r in records),
        status_counts=dict(Counter(r['option_count_status'] for r in records)),
        structure_counts=dict(Counter(r['event_structure'] for r in records)),
        by_topic={t:dict(Counter(r['option_count_status'] for r in records if r['topic']==t)) for t in ('Sports','Politics','Economics')},
        alternative_count_distribution=dict(sorted(Counter(r['listed_alternative_count_snapshot'] for r in records if r['listed_alternative_count_snapshot'] is not None).items())),
        exact_historical_menu_verified=0,cohort_membership_changed=False,
        method_version=1)
    save(RUN / 'summary.json',summary)
    save(RUN / 'data_dictionary.json',{
        'market_id':'Unique sampled contract. Join to active_candidates.csv or checked_forecasts.csv; one row per retained market.',
        'event_id':'Parent Polymarket event listing. Distinct from audited event_family_id, which groups related real-world events.',
        'forecast_cutoff':'Previously approved forecast cutoff; this audit does not change it.',
        'contract_outcome_count':'Number of outcome tokens in the sampled contract. Two for every sampled contract.',
        'event_structure':'Reviewed type of proposition: two/three-way sport, standalone binary, candidate or party options, ranges, policy options, or a nonexclusive bundle.',
        'alternatives_mutually_exclusive':'Whether the relevant alternatives define a single resolving category. False for overlapping/multiple-question bundles.',
        'parent_event_contract_count':'All market objects returned in the event response, including unrelated side bets and placeholders. Never use this as the choice count.',
        'relevant_contract_count':'All contracts about the same sampled proposition; Sports restricts to moneyline, excluding totals, spreads and other side bets.',
        'named_option_contracts_snapshot':'Currently named relevant contracts, excluding catch-all Other and placeholder slots. For a two-way sports contract this is one contract encoding two alternatives.',
        'other_option_contracts_snapshot':'Explicit catch-all Other contracts, counted once per slot.',
        'placeholder_contracts_snapshot':'Unnamed slots, identified from full question text as well as groupItemTitle. Short real party abbreviations alone are not placeholders.',
        'listed_alternative_count_snapshot':'Alternatives represented by the retrieved listing: 2 for standalone binary/two-way sport; named plus Other for exclusive multi-contract groups; missing for nonexclusive bundles. Descriptive only, not automatically known before cutoff.',
        'option_count_at_cutoff':'Conservative retrospective count for fixed structures with usable opening/closing timestamps. Missing for flexible/placeholder groups or unknown opening times, and not applicable to nonexclusive bundles.',
        'option_count_status':'reconstructed_from_fixed_structure_and_timestamps; historical_count_unverified; or not_applicable_nonexclusive_bundle. Always retain this alongside the count.',
        'contemporaneous_menu_verified':'False for all rows. A current API response cannot prove a full historical menu or that no option was ever removed.',
        'named_and_other_contracts_with_pre_cutoff_timestamps':'Count of currently named/Other contracts whose timestamp fields place them open at cutoff. This alone cannot backdate a later name assignment.',
        'augmented_neg_risk':'API indicator that reserved slots can later be named. Placeholder detection also handles two events without this indicator.',
        'raw_source':'Cached JSON.GZ response, relative to data/cohort_audit/20260914_sample200. Companion request JSON records URL, retrieval timestamp and SHA-256.',
        'event_contracts.csv':'Full constituent-contract ledger including exclusion from relevant group, placeholder/Other/named classification and each timestamp comparison.',
        'interpretation_limit':'Counts describe listed forecast alternatives, not actual eligible candidate totals, event-wide volume, outcome probabilities or the number of sampled markets in an event family.'})
    print(json.dumps(summary,indent=2),flush=True)
    write_report(records,summary)


def write_report(records,summary):
    lines=['# Event structure and alternative-count audit','',
        f"**{summary['markets_checked']} / {summary['markets_checked']} contracts checked against their full parent-event listings.** All sampled contracts still have two outcomes. The cohort, labels and forecast cutoffs are unchanged.", '',
        '| Topic | Cutoff count reconstructed | Historical count unverified | Nonexclusive bundle |',
        '|---|---:|---:|---:|']
    for topic,c in summary['by_topic'].items():
        lines.append(f"| {topic} | {c.get('reconstructed_from_fixed_structure_and_timestamps',0)} | {c.get('historical_count_unverified',0)} | {c.get('not_applicable_nonexclusive_bundle',0)} |")
    lines += ['', '## What was counted','',
        f"Saved and hashed {summary['event_responses_hashed']} unfiltered event-detail responses containing {summary['parent_event_contracts']:,} contract records. All sampled market IDs, conditions and first outcome-token IDs match. Included {summary['relevant_contracts']:,} contracts relevant to the sampled propositions; {summary['unrelated_side_bets']:,} sports side bets were recorded separately. Excluded {summary['placeholder_contracts']:,} unnamed placeholder slots from named-choice counts. Explicit Other is counted once and separately identified.", '',
        '| Structure | Sampled contracts |','|---|---:|']
    for kind,n in summary['structure_counts'].items():lines.append(f'| {kind} | {n} |')
    lines += ['', '## Examples','', '| Market | Interpretation | Listed alternatives in retrieved snapshot | Cutoff count |', '|---|---|---:|---:|']
    for mid in ['1057753','586793','1335328','576090','1849834','2325034']:
        r=next(r for r in records if r['market_id']==mid)
        lines.append(f"| {mid}: {r['event_title']} | {r['event_structure']} | {r['listed_alternative_count_snapshot'] if r['listed_alternative_count_snapshot'] is not None else 'not applicable'} | {r['option_count_at_cutoff'] if r['option_count_at_cutoff'] is not None else r['option_count_status']} |")
    lines += ['', '## Historical limits and safe use','',
        'These are retrospective metadata reconstructions, not saved trading-menu snapshots from each forecast date. We check createdAt, startDate, acceptingOrdersTimestamp and closedTime against the audited cutoff. Current active/closed flags, final price, outcome and lifetime volume do not decide which alternatives enter a cutoff count.', '',
        'For fixed groups with usable timestamps, option_count_at_cutoff records the reconstructed count. For augmented groups or groups with placeholders, current names can have been assigned after the cutoff; the dated clarification history was not returned. Their historical count stays missing. The retrieved current count remains available for descriptive auditing only and must not be silently used as a pre-cutoff predictor. Missing opening timestamps are flagged separately. No exact historical-menu count is claimed.', '',
        'Polymarket documents named outcomes, unnamed placeholders and explicit Other for augmented negative-risk events. Placeholders may later be named; counting raw market rows would inflate the visible choice count. [Official explanation](https://docs.polymarket.com/concepts/negative-risk). The [event endpoint](https://docs.polymarket.com/api-reference/events/get-event-by-id) returns the current nested market listing. It does not establish that no contract was removed or renamed historically.', '',
        'A single binary threshold remains a two-outcome proposition even when its underlying election has many candidates. The listed candidate options are not an authoritative election participation roster. Bins are defined by the market rules, including rounding/tie provisions; this audit counts the advertised alternatives and does not claim every bin has equal probability.', '',
        'The nonexclusive bundles have no single categorical option count: borough wins, nested seat thresholds, party-entry questions, candidate advancement and separate referendum proposals may resolve Yes together. Their related-contract counts remain available, but should not be interpreted as mutually exclusive outcomes.', '',
        'These feature-level missing counts do not reopen market eligibility holds or remove audited forecasts. Use event_structure for all rows, and use option_count_at_cutoff with its provenance/missingness indicator. Candidate eligibility and full event-wide trading volume are separate concepts.', '',
        '## Files and reproduction','',
        '- [Current option metadata](market_options.csv)',
        '- [Every parent-event contract and timestamp decision](event_contracts.csv)',
        '- [Historical count limitations](historical_count_limits.csv)',
        '- [Nonexclusive bundles](nonexclusive_bundles.csv)',
        '- [Counts and integrity checks](summary.json)',
        '- [Structural review decisions](structural_decisions.json)', '',
        '- [Field definitions](data_dictionary.json)', '',
        'Join ../active_market_options.csv to the market analysis table on market_id. It has exactly one row for every active market.', '',
        '```powershell','python -B src/audit_event_options.py','```','',
        'This rebuilds the tables from the cached event responses offline and checks the original input hashes. --collect retrieves/resumes public event snapshots. A changed cohort or audit register requires a new run directory. No sibling trade histories were collected by this audit.', '']
    (RUN / 'report.md').write_text('\n'.join(lines),encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collect',action='store_true')
    parser.add_argument('--limit',type=int)
    args=parser.parse_args();rows=setup()
    if args.collect: collect_events(rows,args.limit)
    if not args.limit: analyze(rows)


if __name__=='__main__':
    main()
